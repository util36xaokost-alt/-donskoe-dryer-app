const CACHE='donskoe-chem-v6-1-3-offline-20260825';
const CORE=['./index.html','./styles.css','./app.js','./manifest.webmanifest','./icon-192.png','./icon-512.png','./apple-touch-icon.png','./logo.png'];
const OFFLINE_HTML='<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><style>body{font-family:-apple-system,BlinkMacSystemFont,Segoe UI,Arial,sans-serif;background:#f3f5f2;color:#173b32;padding:28px}</style><h2>Донское — Склад химии</h2><p>Локальная копия ещё не сохранена. Открой раздел один раз при наличии интернета.</p>';
async function refresh(request,key){const r=await fetch(request,{cache:'no-store'});if(r&&r.ok){const c=await caches.open(CACHE);await c.put(key||request,r.clone());}return r;}
self.addEventListener('install',e=>{e.waitUntil(caches.open(CACHE).then(c=>c.addAll(CORE)).then(()=>self.skipWaiting()));});
self.addEventListener('activate',e=>{e.waitUntil((async()=>{const keys=await caches.keys();await Promise.all(keys.filter(k=>k.startsWith('donskoe-chem-')&&k!==CACHE&&!k.startsWith('donskoe-chem-ocr-')).map(k=>caches.delete(k)));await self.clients.claim();})());});
self.addEventListener('fetch',e=>{
  if(e.request.method!=='GET')return;
  const url=new URL(e.request.url);if(url.origin!==self.location.origin)return;
  if(e.request.mode==='navigate'){
    e.respondWith((async()=>{const c=await caches.open(CACHE);const cached=await c.match('./index.html');if(cached){e.waitUntil(refresh(e.request,'./index.html').catch(()=>{}));return cached;}try{return await refresh(e.request,'./index.html');}catch(err){return new Response(OFFLINE_HTML,{status:200,headers:{'Content-Type':'text/html; charset=utf-8'}});}})());return;
  }
  e.respondWith((async()=>{const cached=await caches.match(e.request,{ignoreSearch:true});if(cached){e.waitUntil(refresh(e.request,e.request).catch(()=>{}));return cached;}try{return await refresh(e.request,e.request);}catch(err){return new Response('',{status:504,statusText:'Offline'});}})());
});
