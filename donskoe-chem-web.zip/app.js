(function(){
'use strict';

const CONFIG={
  supabaseUrl:'https://vschnaxezsceogewlmin.supabase.co',
  publishableKey:'sb_publishable_1SSHvNqBFudiE71JpzcyGQ_ZP-bNV9c',
  bucket:'chem-photos',
  version:'0.2.0-alpha'
};
const DB_NAME='donskoe_chem_offline_v1';
const DB_VERSION=1;
const SESSION_KEY='donskoe_chem_cloud_session_v1';
const EMAIL_KEY='donskoe_chem_cloud_email_v1';
const STORES=['chem_operators','chem_devices','chem_products','chem_batches','chem_movements','chem_opened_units','chem_photo_sessions','chem_photos','chem_ai_audits','chem_ai_findings','chem_inventory_sessions','chem_inventory_counts','pending','photo_blobs','settings'];
const CLOUD_TABLES=['chem_operators','chem_devices','chem_products','chem_batches','chem_movements','chem_opened_units','chem_photo_sessions','chem_photos','chem_ai_audits','chem_ai_findings','chem_inventory_sessions','chem_inventory_counts'];
const app=document.getElementById('app');
const toastEl=document.getElementById('toast');
let db=null;
let route='home';
let routeData={};
let session=readJSON(localStorage.getItem(SESSION_KEY));
let syncBusy=false;
let lastSyncAt=0;
let draftPhotos=[];
let cache={};

function uuid(){return crypto.randomUUID ? crypto.randomUUID() : 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g,c=>{const r=Math.random()*16|0,v=c==='x'?r:(r&3|8);return v.toString(16);});}
function iso(){return new Date().toISOString();}
function today(){const d=new Date();return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;}
function fmtQty(v){const n=Number(v||0);return n.toLocaleString('ru-RU',{maximumFractionDigits:3});}
function unitLabel(u){return u==='l'?'л':u==='kg'?'кг':'шт';}
function esc(v){return String(v??'').replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));}
function readJSON(v){try{return v?JSON.parse(v):null}catch(e){return null}}
function decodeJwt(token){try{return JSON.parse(atob(token.split('.')[1].replace(/-/g,'+').replace(/_/g,'/')))}catch(e){return {}}}
function sessionOwner(){return session?.user?.id || decodeJwt(session?.access_token||'').sub || null;}
function isOnline(){return navigator.onLine;}
function expiryState(date){if(!date)return {text:'срок не указан',cls:'warn'};const d=new Date(date+'T23:59:59'),now=new Date(),days=Math.ceil((d-now)/86400000);if(days<0)return {text:'просрочено',cls:'bad'};if(days<=90)return {text:`до ${formatDate(date)} · ${days} дн.`,cls:'warn'};return {text:`до ${formatDate(date)}`,cls:'ok'};}
function formatDate(v){if(!v)return '—';const a=String(v).slice(0,10).split('-');return a.length===3?`${a[2]}.${a[1]}.${a[0]}`:v;}
function formatDateTime(v){if(!v)return '—';try{return new Date(v).toLocaleString('ru-RU',{day:'2-digit',month:'2-digit',year:'2-digit',hour:'2-digit',minute:'2-digit'})}catch(e){return v}}
function packageLabel(t){return ({canister:'канистра',bag:'мешок',bigbag:'биг-бэг',bottle:'бутылка',drum:'бочка',pallet:'паллета',other:'другое'})[t]||'тара не указана';}
function showToast(text,ms=2800){toastEl.textContent=text;toastEl.classList.remove('hidden');clearTimeout(showToast.t);showToast.t=setTimeout(()=>toastEl.classList.add('hidden'),ms);}
function applyRoute(r,data={}){route=r;routeData=data||{};draftPhotos=[];render();window.scrollTo(0,0);}
function setRoute(r,data={},opts={}){applyRoute(r,data);try{const st={chemApp:true,route:r,data:data||{}};if(opts.replace)history.replaceState(st,'');else if(!opts.noHistory)history.pushState(st,'');}catch(e){}}

function openDb(){return new Promise((resolve,reject)=>{const req=indexedDB.open(DB_NAME,DB_VERSION);req.onupgradeneeded=()=>{const d=req.result;for(const s of STORES){if(!d.objectStoreNames.contains(s)){if(s==='settings')d.createObjectStore(s,{keyPath:'key'});else d.createObjectStore(s,{keyPath:'id'});}}};req.onsuccess=()=>resolve(req.result);req.onerror=()=>reject(req.error);});}
function tx(store,mode='readonly'){return db.transaction(store,mode).objectStore(store);}
function idbGet(store,id){return new Promise((res,rej)=>{const r=tx(store).get(id);r.onsuccess=()=>res(r.result||null);r.onerror=()=>rej(r.error);});}
function idbAll(store){return new Promise((res,rej)=>{const r=tx(store).getAll();r.onsuccess=()=>res(r.result||[]);r.onerror=()=>rej(r.error);});}
function idbPut(store,value){return new Promise((res,rej)=>{const r=tx(store,'readwrite').put(value);r.onsuccess=()=>res(value);r.onerror=()=>rej(r.error);});}
function idbDelete(store,id){return new Promise((res,rej)=>{const r=tx(store,'readwrite').delete(id);r.onsuccess=()=>res();r.onerror=()=>rej(r.error);});}
async function setting(key,fallback=null){const x=await idbGet('settings',key);return x?x.value:fallback;}
async function setSetting(key,value){await idbPut('settings',{key,value});return value;}
async function reloadCache(){for(const s of CLOUD_TABLES)cache[s]=await idbAll(s);cache.pending=await idbAll('pending');}
function rows(name){return (cache[name]||[]).filter(x=>!x.deleted_at);}
function byId(name,id){return rows(name).find(x=>x.id===id)||null;}
async function ownerId(){return sessionOwner() || await setting('last_owner_id',null);}
async function requireOwner(){const id=await ownerId();if(id)return id;showToast('Сначала один раз подключи облако в Настройках');setRoute('settings');throw new Error('NO_OWNER');}

async function queueUpsert(table,payload,conflict='id'){
  await idbPut(table,payload);
  await idbPut('pending',{id:`upsert:${table}:${payload.id}`,kind:'upsert',table,conflict,payload,created_at:iso()});
  await reloadCache();
}
async function queuePhotoUpload(photoId){await idbPut('pending',{id:`photo:${photoId}`,kind:'photoUpload',photoId,created_at:iso()});await reloadCache();}
async function savePhotoBlob(photoId,blob){await idbPut('photo_blobs',{id:photoId,blob,type:blob.type||'image/jpeg',size:blob.size||0});}

async function authRequest(path,opts={}){
  const h=Object.assign({'apikey':CONFIG.publishableKey,'Content-Type':'application/json'},opts.headers||{});
  const r=await fetch(CONFIG.supabaseUrl+path,Object.assign({},opts,{headers:h}));
  const t=await r.text();let j=null;try{j=t?JSON.parse(t):null}catch(e){}
  if(!r.ok)throw new Error(j?.message||j?.msg||j?.error_description||j?.error||t||`HTTP ${r.status}`);return j;
}
async function login(email,password){
  const j=await authRequest('/auth/v1/token?grant_type=password',{method:'POST',body:JSON.stringify({email,password})});
  if(!j?.access_token)throw new Error('Не удалось получить сессию');session=j;localStorage.setItem(SESSION_KEY,JSON.stringify(j));localStorage.setItem(EMAIL_KEY,email);const id=sessionOwner();if(id)await setSetting('last_owner_id',id);return j;
}
async function refreshSession(){
  if(!session?.refresh_token)throw new Error('Нужен повторный вход');
  const j=await authRequest('/auth/v1/token?grant_type=refresh_token',{method:'POST',body:JSON.stringify({refresh_token:session.refresh_token})});session=j;localStorage.setItem(SESSION_KEY,JSON.stringify(j));return j;
}
async function authedFetch(url,opts={},retry=true){
  if(!session?.access_token)throw new Error('Нужен вход в облако');
  const h=Object.assign({'apikey':CONFIG.publishableKey,'Authorization':'Bearer '+session.access_token},opts.headers||{});
  const r=await fetch(url,Object.assign({},opts,{headers:h}));
  if(r.status===401&&retry){await refreshSession();return authedFetch(url,opts,false);}return r;
}
async function rest(table,query='',opts={}){
  const url=`${CONFIG.supabaseUrl}/rest/v1/${table}${query?'?'+query:''}`;
  const h=Object.assign({'Content-Type':'application/json'},opts.headers||{});
  const r=await authedFetch(url,Object.assign({},opts,{headers:h}));const t=await r.text();let j=null;try{j=t?JSON.parse(t):null}catch(e){}
  if(!r.ok)throw new Error(j?.message||j?.hint||t||`HTTP ${r.status}`);return j;
}
async function storageUpload(photo){
  const blobRec=await idbGet('photo_blobs',photo.id);if(!blobRec?.blob)throw new Error('Локальный файл фото не найден');
  const owner=await ownerId();const ext=(blobRec.type||'image/jpeg').includes('png')?'png':(blobRec.type.includes('webp')?'webp':(blobRec.type.includes('heic')?'heic':'jpg'));
  const path=`${owner}/${photo.id}.${ext}`;
  const url=`${CONFIG.supabaseUrl}/storage/v1/object/${CONFIG.bucket}/${path}`;
  const r=await authedFetch(url,{method:'POST',headers:{'Content-Type':blobRec.type||'image/jpeg','x-upsert':'true'},body:blobRec.blob});
  if(!r.ok){const t=await r.text();throw new Error(t||`Ошибка загрузки фото ${r.status}`);}photo.storage_path=path;photo.uploaded_at=iso();photo.updated_at=iso();await idbPut('chem_photos',photo);return photo;
}
async function storageBlob(path){
  const url=`${CONFIG.supabaseUrl}/storage/v1/object/authenticated/${CONFIG.bucket}/${path}`;const r=await authedFetch(url);if(!r.ok)throw new Error('Не удалось загрузить фото');return r.blob();
}

async function pushPending(){
  const list=(await idbAll('pending')).sort((a,b)=>String(a.created_at).localeCompare(String(b.created_at)));
  for(const p of list){
    if(p.kind==='upsert'){
      const q=`on_conflict=${encodeURIComponent(p.conflict||'id')}`;
      await rest(p.table,q,{method:'POST',headers:{Prefer:'resolution=merge-duplicates,missing=default,return=minimal'},body:JSON.stringify(p.payload)});
    }else if(p.kind==='photoUpload'){
      const photo=await idbGet('chem_photos',p.photoId);if(photo){const updated=await storageUpload(photo);await rest('chem_photos','on_conflict=local_photo_id',{method:'POST',headers:{Prefer:'resolution=merge-duplicates,missing=default,return=minimal'},body:JSON.stringify(updated)});}
    }
    await idbDelete('pending',p.id);
  }
}
async function pullCloud(){
  for(const table of CLOUD_TABLES){
    const data=await rest(table,'select=*&limit=5000',{method:'GET'});if(!Array.isArray(data))continue;
    for(const remote of data){const local=await idbGet(table,remote.id);const rt=remote.updated_at||remote.created_at||'';const lt=local?.updated_at||local?.created_at||'';if(!local||rt>=lt)await idbPut(table,remote);}
  }
}
async function syncNow(silent=false){
  if(syncBusy||!isOnline()||!session?.access_token)return false;syncBusy=true;renderHeaderOnly();
  try{await pushPending();await pullCloud();lastSyncAt=Date.now();await setSetting('last_sync_at',new Date(lastSyncAt).toISOString());await reloadCache();if(!silent)showToast('Синхронизация завершена');render();return true;}
  catch(e){console.error(e);if(!silent)showToast('Синхронизация: '+e.message,4500);renderHeaderOnly();return false;}
  finally{syncBusy=false;renderHeaderOnly();}
}

function balanceByBatch(){const m={};for(const x of rows('chem_movements'))m[x.batch_id]=(m[x.batch_id]||0)+Number(x.quantity_delta||0);return m;}
function productStock(){const bm=balanceByBatch(),out={};for(const b of rows('chem_batches')){const q=bm[b.id]||0;const key=b.product_id||`tmp:${b.temporary_name}`;if(!out[key])out[key]={key,product:b.product_id?byId('chem_products',b.product_id):null,name:b.product_id?(byId('chem_products',b.product_id)?.name||b.temporary_name):b.temporary_name,unit:b.base_unit,total:0,batches:[]};out[key].total+=q;out[key].batches.push({batch:b,balance:q});}return Object.values(out).sort((a,b)=>a.name.localeCompare(b.name,'ru'));}
function openedForBatch(batchId){return rows('chem_opened_units').filter(x=>x.batch_id===batchId&&!x.closed_at).sort((a,b)=>String(a.opened_at).localeCompare(String(b.opened_at)));}
function productForBatch(batch){return batch?.product_id?byId('chem_products',batch.product_id):null;}
function currentOperator(){const id=cache._currentOperatorId;return id?byId('chem_operators',id):null;}
async function hydrateSettings(){cache._currentOperatorId=await setting('current_operator_id',null);cache._deviceId=await setting('device_id',null);cache._deviceLabel=await setting('device_label','Рабочее устройство');if(!cache._deviceId){cache._deviceId=uuid();await setSetting('device_id',cache._deviceId);}}
async function refreshAll(){await reloadCache();await hydrateSettings();}

function headerHtml(){
  const pending=(cache.pending||[]).length;const online=isOnline();
  let syncText='';if(syncBusy)syncText='синхронизация…';else if(!online)syncText=pending?`${pending} ждут отправки`:'работаем локально';else if(session?.access_token&&pending===0)syncText='синхронизировано';else if(session?.access_token)syncText=`${pending} ждут облака`;else syncText='облако не подключено';
  return `<div class="topbar"><div class="brandCard"><img class="brandLogo" src="logo.png" alt="Донское"><div class="brandText"><h1>Донское — Склад</h1><small>Учёт химии и складских остатков</small></div><div class="headerTools"><div class="netPill ${online?'online':'offline'}"><i></i><span>${online?'Онлайн':'Оффлайн'}</span></div><button class="iconBtn" data-route="settings" aria-label="Настройки">⚙️</button></div></div><div class="cloudLine">${esc(syncText)}${lastSyncAt&&online&&!syncBusy?` · ${new Date(lastSyncAt).toLocaleTimeString('ru-RU',{hour:'2-digit',minute:'2-digit'})}`:''}</div></div>`;
}
function renderHeaderOnly(){const h=document.querySelector('.topbar');if(h)h.outerHTML=headerHtml();bindGlobal();}
function shell(body){return `<div class="appShell">${headerHtml()}<main class="content">${body}</main></div>`;}
function backHead(title,sub=''){return `<div class="pageHead"><button class="back" data-back="1">← Назад</button><div><h2>${esc(title)}</h2>${sub?`<p>${esc(sub)}</p>`:''}</div></div>`;}

function render(){
  if(!db)return;
  let body='';
  if(route==='home')body=homeView();
  else if(route==='receipt')body=receiptView();
  else if(route==='issue')body=issueView();
  else if(route==='return')body=returnView();
  else if(route==='stocks')body=stocksView();
  else if(route==='product')body=productView(routeData.productKey);
  else if(route==='opened')body=openedView(routeData.batchId);
  else if(route==='warehousePhotos')body=warehousePhotosView();
  else if(route==='settings')body=settingsView();
  else body=homeView();
  app.innerHTML=shell(body);bindGlobal();bindRoute();
}
function bindGlobal(){
  document.querySelectorAll('[data-route]').forEach(b=>b.onclick=()=>setRoute(b.dataset.route));
  document.querySelectorAll('[data-back]').forEach(b=>b.onclick=()=>historyBack());
}
function fallbackBack(){if(route==='product')applyRoute('stocks');else if(route==='opened')applyRoute('product',{productKey:routeData.productKey});else if(route==='issue'&&routeData.fromProduct)applyRoute('product',{productKey:routeData.fromProduct});else applyRoute('home');}
function historyBack(){if(route==='home')return;try{if(history.length>1){history.back();return;}}catch(e){}fallbackBack();}

function homeView(){
  const stocks=productStock();const bm=balanceByBatch();
  const needs=rows('chem_batches').filter(b=>b.completeness==='needs_details'&&(bm[b.id]||0)>0).length;
  const expiring=rows('chem_batches').filter(b=>{if(!b.expires_on||(bm[b.id]||0)<=0)return false;const days=Math.ceil((new Date(b.expires_on+'T23:59:59')-new Date())/86400000);return days<=90;}).length;
  const totalPos=stocks.filter(s=>s.total>0).length;const opened=rows('chem_opened_units').filter(x=>!x.closed_at).length;const op=currentOperator();
  return `<section class="operatorBar"><div><span>Сейчас работает</span><b>${esc(op?.name||'Сотрудник не выбран')}</b></div><button class="btn compact" data-route="settings">${op?'Сменить':'Выбрать'}</button></section>
  <div class="actions2"><button class="bigAction primary" data-route="receipt"><span class="ico">＋</span><b>ПРИВЕЗЛИ</b><small>Принять химию на склад</small></button><button class="bigAction issueAction" data-route="issue"><span class="ico">−</span><b>ВЫДАТЬ</b><small>Выдать со склада</small></button></div>
  <div class="quick"><button data-route="return"><span class="qico">↩︎</span>Вернули</button><button data-route="stocks"><span class="qico">▦</span>Остатки</button><button data-route="warehousePhotos"><span class="qico">📷</span>Фото склада</button></div>
  <div class="sectionTitle">Сейчас</div>
  <section class="card"><div class="kpi"><div><b>${totalPos}</b><span>позиций</span></div><div><b>${opened}</b><span>вскрыто</span></div><div><b>${(cache.pending||[]).length}</b><span>ждут облака</span></div></div></section>
  ${needs?`<div class="alert"><span class="num">${needs}</span><div><b>Приход нужно уточнить</b><div class="small">Не указана партия или срок годности.</div></div><button data-route="stocks">Открыть</button></div>`:''}
  ${expiring?`<div class="alert ${expiring?'bad':''}"><span class="num">${expiring}</span><div><b>Проверь сроки годности</b><div class="small">Есть партии со сроком ≤90 дней или уже просроченные.</div></div><button data-route="stocks">Открыть</button></div>`:''}
  ${!needs&&!expiring?`<div class="alert ok"><span>✓</span><div><b>Критичных предупреждений нет</b><div class="small">По данным приложения.</div></div></div>`:''}`;
}

function receiptView(){
  return `${backHead('Привезли','Можно заполнить минимум и уточнить позже')}
  <form id="receiptForm">
    <section class="card"><h3>1. Что привезли?</h3>
      <div class="cameraBox"><div class="photoChoice"><label class="cameraBtn">📷 Сфотографировать<input id="receiptPhotoCamera" type="file" accept="image/*" capture="environment" multiple></label><label class="cameraBtn secondary">🖼 Загрузить фото<input id="receiptPhotoUpload" type="file" accept="image/*" multiple></label><button class="cameraBtn secondary" id="receiptManual" type="button">✍️ Ввести вручную</button></div><div class="small muted" style="margin-top:9px">Для большой партии достаточно общей фотографии и одной читаемой бирки. Каждую канистру фотографировать не нужно.</div><div id="receiptPhotos" class="photos"></div></div>
      <div class="field" style="margin-top:14px"><label>Название препарата *</label><input id="rName" autocomplete="off" placeholder="Например, Линтур" required></div>
      <div class="small muted">Распознавание по фото подключим отдельным модулем. Ручной ввод всегда останется доступен.</div>
    </section>
    <section class="card"><h3>2. Сколько?</h3>
      <div class="grid2"><div class="field"><label>Общее количество *</label><input id="rQty" type="number" min="0.001" step="0.001" inputmode="decimal" placeholder="2000" required></div><div class="field"><label>Единица *</label><select id="rUnit"><option value="kg">кг</option><option value="l">л</option><option value="pcs">шт</option></select></div></div>
      <div class="grid3"><div class="field"><label>Тара</label><select id="rPackType"><option value="">Не указана</option><option value="canister">Канистры</option><option value="bag">Мешки</option><option value="bigbag">Биг-бэги</option><option value="bottle">Бутылки</option><option value="drum">Бочки</option><option value="pallet">Паллеты</option><option value="other">Другое</option></select></div><div class="field"><label>В одной таре</label><input id="rPackSize" type="number" min="0" step="0.001" inputmode="decimal" placeholder="500"></div><div class="field"><label>Количество тары</label><input id="rPackCount" type="number" min="0" step="1" inputmode="numeric" placeholder="4"></div></div>
      <div id="rCalc" class="small muted"></div>
    </section>
    <section class="card"><h3>3. Партия и срок</h3>
      <div class="grid2"><div class="field"><label>Номер партии</label><input id="rBatch" autocomplete="off" placeholder="Можно заполнить позже"></div><div class="field"><label>Годен до</label><input id="rExpiry" type="date"></div></div>
      <div class="grid2"><div class="field"><label>Поставщик</label><input id="rSupplier" placeholder="Необязательно"></div><div class="field"><label>Накладная / УПД</label><input id="rDoc" placeholder="Необязательно"></div></div>
      <div class="field"><label>Заметка</label><textarea id="rNote" placeholder="Например: принять срочно, маркировку уточнить утром"></textarea></div>
    </section>
    <div class="stickySave"><button class="btn primary full" type="submit">ПРИНЯТЬ НА СКЛАД</button></div>
  </form>`;
}

function issueView(){
  const stocks=productStock().filter(s=>s.total>0.0001);const selected=routeData.productKey||'';const options=stocks.map(s=>`<option value="${esc(s.key)}" ${s.key===selected?'selected':''}>${esc(s.name)} — ${fmtQty(s.total)} ${unitLabel(s.unit)}</option>`).join('');
  return `${backHead('Выдать','Приложение само использует ближайшие сроки и вскрытую тару')}
  ${stocks.length?`<form id="issueForm"><section class="card"><div class="field"><label>Что выдаём? *</label><select id="iProduct"><option value="">Выбери препарат</option>${options}</select></div><div id="issueInfo"></div><div class="grid2"><div class="field"><label>Количество *</label><input id="iQty" type="number" min="0.001" step="0.001" inputmode="decimal" placeholder="0"></div><div class="field"><label>Единица</label><input id="iUnit" readonly></div></div><div class="field"><label>Заметка</label><textarea id="iNote" placeholder="Куда выдано / кому / поле — пока необязательно"></textarea></div></section><div class="stickySave"><button class="btn primary full" type="submit">ВЫДАТЬ</button></div></form>`:`<section class="card empty">На складе пока нет положительных остатков.<br><br><button class="btn primary" data-route="receipt">Оформить приход</button></section>`}`;
}

function returnView(){
  const bm=balanceByBatch();const opts=rows('chem_batches').filter(b=>(bm[b.id]||0)>=0).sort((a,b)=>a.temporary_name.localeCompare(b.temporary_name,'ru')).map(b=>`<option value="${b.id}">${esc(productForBatch(b)?.name||b.temporary_name)} · ${esc(b.batch_no||'партия не указана')} · сейчас ${fmtQty(bm[b.id]||0)} ${unitLabel(b.base_unit)}</option>`).join('');
  return `${backHead('Вернули на склад','Возврат увеличивает фактический остаток')}
  <form id="returnForm"><section class="card"><div class="field"><label>Препарат / партия *</label><select id="retBatch"><option value="">Выбери</option>${opts}</select></div><div class="grid2"><div class="field"><label>Количество *</label><input id="retQty" type="number" min="0.001" step="0.001" inputmode="decimal"></div><div class="field"><label>Единица</label><input id="retUnit" readonly></div></div><div class="field"><label>Куда вернуть?</label><select id="retOpened"><option value="">В общий остаток партии</option></select></div><div class="field"><label>Заметка</label><textarea id="retNote" placeholder="Например: остаток после обработки поля 14"></textarea></div></section><div class="stickySave"><button class="btn primary full" type="submit">ВЕРНУТЬ НА СКЛАД</button></div></form>`;
}

function stocksView(){
  const stocks=productStock().filter(s=>s.total>0.0001||s.batches.some(x=>x.batch.completeness==='needs_details'));
  return `${backHead('Остатки','По препаратам, внутри — партии и вскрытая тара')}<div class="field search"><input id="stockSearch" placeholder="Поиск по названию"></div><div id="stockList">${stockCards(stocks)}</div>`;
}
function stockCards(stocks){
  if(!stocks.length)return `<section class="card empty">Остатков пока нет.</section>`;
  return stocks.map(s=>{const active=s.batches.filter(x=>x.balance>0.0001);const opened=active.reduce((n,x)=>n+openedForBatch(x.batch.id).length,0);const soon=active.map(x=>x.batch.expires_on).filter(Boolean).sort()[0];const ex=soon?expiryState(soon):null;return `<section class="card stockCard" data-name="${esc(s.name.toLowerCase())}"><div class="stockTop"><div class="name">${esc(s.name)}</div><div class="qty">${fmtQty(s.total)} ${unitLabel(s.unit)}</div></div><div class="chips"><span class="chip">${active.length} парт.</span>${opened?`<span class="chip open">вскрыто: ${opened}</span>`:''}${ex?`<span class="chip ${ex.cls==='bad'||ex.cls==='warn'?'warn':''}">${esc(ex.text)}</span>`:''}</div><div class="stockActions"><button class="btn" data-product="${esc(s.key)}">Подробнее</button><button class="btn primary" data-issue-product="${esc(s.key)}">Выдать</button></div></section>`;}).join('');
}

function productView(key){
  const s=productStock().find(x=>x.key===key);if(!s)return `${backHead('Остатки')}<section class="card empty">Позиция не найдена.</section>`;
  const active=s.batches.slice().sort((a,b)=>(a.batch.expires_on||'9999').localeCompare(b.batch.expires_on||'9999'));
  return `${backHead(s.name,`Всего ${fmtQty(s.total)} ${unitLabel(s.unit)}`)}<div class="btnRow" style="margin-bottom:12px"><button class="btn primary" data-issue-product="${esc(s.key)}">− Выдать</button><button class="btn" data-route="warehousePhotos">📷 Фото</button></div><section class="card"><h3>Партии</h3>${active.map(x=>batchHtml(x.batch,x.balance,s.key)).join('')||'<div class="empty">Нет партий</div>'}</section>`;
}
function batchHtml(b,balance,key){const ex=expiryState(b.expires_on),opened=openedForBatch(b.id),pack=b.package_size?`${fmtQty(b.package_size)} ${unitLabel(b.base_unit)} · ${packageLabel(b.package_type)}`:packageLabel(b.package_type);return `<div class="batch"><div class="batchLine"><strong>${esc(b.batch_no||'Партия не указана')}</strong><span class="badge ${ex.cls}">${esc(ex.text)}</span></div><div class="small muted" style="margin-top:5px">Остаток: <b>${fmtQty(balance)} ${unitLabel(b.base_unit)}</b> · ${esc(pack)}</div>${b.completeness==='needs_details'?`<div class="small warnText" style="margin-top:5px">⚠ Нужно уточнить данные прихода</div>`:''}${opened.length?`<div class="chips">${opened.map(o=>`<span class="chip open">Вскрыто ${formatDateTime(o.opened_at)} · ${o.remaining_estimate==null?'остаток ?':fmtQty(o.remaining_estimate)+' '+unitLabel(b.base_unit)}</span>`).join('')}</div>`:''}<div class="btnRow" style="margin-top:10px"><button class="btn" data-open-batch="${b.id}" data-product-key="${esc(key)}">Вскрыто</button><button class="btn" data-batch-history="${b.id}">История</button></div></div>`;}

function openedView(batchId){
  const b=byId('chem_batches',batchId);if(!b)return `${backHead('Вскрытая тара')}<section class="card empty">Партия не найдена.</section>`;const p=productForBatch(b);const opened=openedForBatch(batchId);const def=b.package_size||'';
  return `${backHead('Отметить «вскрыто»',`${p?.name||b.temporary_name} · ${b.batch_no||'партия не указана'}`)}
  ${opened.length?`<section class="card"><h3>Уже вскрыто</h3>${opened.map(o=>`<div class="batch"><div class="batchLine"><strong>${esc(o.label||'Вскрытая тара')}</strong><span class="badge">${formatDateTime(o.opened_at)}</span></div><div class="small muted">Остаток: ${o.remaining_estimate==null?'не указан':fmtQty(o.remaining_estimate)+' '+unitLabel(b.base_unit)}</div><div class="btnRow" style="margin-top:8px"><button class="btn" data-adjust-opened="${o.id}">Уточнить остаток</button></div></div>`).join('')}</section>`:''}
  <form id="openedForm"><section class="card"><h3>Новая вскрытая тара</h3><div class="grid2"><div class="field"><label>Размер тары</label><input id="oInitial" type="number" min="0.001" step="0.001" inputmode="decimal" value="${esc(def)}" placeholder="Например, 500"></div><div class="field"><label>Остаток сейчас</label><input id="oRemaining" type="number" min="0" step="0.001" inputmode="decimal" value="${esc(def)}"></div></div><div class="field"><label>Название / метка</label><input id="oLabel" placeholder="Например: Биг-бэг №1"></div><div class="field"><label>Заметка</label><textarea id="oNote" placeholder="Необязательно"></textarea></div><div class="cameraBox"><div class="photoChoice"><label class="cameraBtn">📷 Сделать фото<input id="openedPhotoCamera" type="file" accept="image/*" capture="environment"></label><label class="cameraBtn secondary">🖼 Загрузить фото<input id="openedPhotoUpload" type="file" accept="image/*"></label></div><div id="openedPhotos" class="photos"></div></div></section><div class="stickySave"><button class="btn primary full" type="submit">ОТМЕТИТЬ ВСКРЫТОЙ</button></div></form>`;
}

function warehousePhotosView(){
  const sessions=rows('chem_photo_sessions').filter(s=>s.session_type==='warehouse_checkpoint').sort((a,b)=>String(b.occurred_at).localeCompare(String(a.occurred_at))).slice(0,6);
  return `${backHead('Фото склада','Общий вид для сравнения состояния во времени')}
  <form id="warehousePhotoForm"><section class="card"><div class="field"><label>Точка / ракурс</label><input id="wCheckpoint" placeholder="Например: Общий вид 1 / зона биг-бэгов"></div><div class="cameraBox"><div class="photoChoice"><label class="cameraBtn">📷 Сделать фото<input id="warehousePhotoCamera" type="file" accept="image/*" capture="environment" multiple></label><label class="cameraBtn secondary">🖼 Загрузить фото<input id="warehousePhotoUpload" type="file" accept="image/*" multiple></label></div><div class="small muted" style="margin-top:9px">Старайся повторять один и тот же ракурс. Тогда будущая AI-проверка сможет лучше сравнивать изменения.</div><div id="warehousePhotos" class="photos"></div></div><div class="field" style="margin-top:12px"><label>Комментарий</label><textarea id="wNote" placeholder="Например: после прихода, зона 2"></textarea></div></section><div class="stickySave"><button class="btn primary full" type="submit">СОХРАНИТЬ ФОТОФИКСАЦИЮ</button></div></form>
  ${sessions.length?`<div class="sectionTitle">Последние фиксации</div>${sessions.map(s=>`<section class="card"><b>${formatDateTime(s.occurred_at)}</b><div class="small muted" style="margin-top:4px">${esc(s.title||'Фото склада')} · ${esc(s.note||'без комментария')}</div></section>`).join('')}`:''}`;
}

function settingsView(){
  const ops=rows('chem_operators').filter(o=>o.is_active!==false);const cur=currentOperator();const email=localStorage.getItem(EMAIL_KEY)||'';const pending=(cache.pending||[]).length;const photoCount=rows('chem_photos').length;const batchCount=rows('chem_batches').length;const movementCount=rows('chem_movements').length;
  return `${backHead('Настройки','Сотрудник, устройство, синхронизация и AI-аудит')}
  <section class="card"><h3>Кто сейчас работает</h3><div class="operatorList">${ops.map(o=>`<button class="operatorItem" data-select-operator="${o.id}" type="button"><span class="avatar">${esc((o.name||'?').trim().charAt(0).toUpperCase())}</span><span class="meta"><b>${esc(o.name)}</b><small>${esc(o.position||'сотрудник')}</small></span>${o.id===cur?.id?'<span class="badge ok">Сейчас</span>':''}</button>`).join('')}</div><div class="divider"></div><form id="operatorForm"><div class="grid2"><div class="field"><label>Новый сотрудник</label><input id="opName" placeholder="ФИО или имя"></div><div class="field"><label>Должность</label><input id="opPosition" placeholder="Зав. складом / механизатор"></div></div><button class="btn" type="submit">Добавить и выбрать</button></form></section>
  <section class="card"><h3>Рабочее устройство</h3><div class="field"><label>Название</label><input id="deviceLabel" value="${esc(cache._deviceLabel||'Рабочее устройство')}" placeholder="Планшет склада"></div><button id="saveDevice" class="btn">Сохранить</button></section>
  <section class="card"><h3>Общая база</h3><div class="small muted" style="margin-bottom:10px">URL и безопасный Publishable key уже встроены. Пароль в приложение не вшивается.</div><div class="field"><label>Email</label><input id="cloudEmail" type="email" autocomplete="username" value="${esc(email)}"></div><div class="field"><label>Пароль</label><input id="cloudPassword" type="password" autocomplete="current-password" placeholder="Вводится только для входа"></div><div class="btnRow"><button id="cloudLogin" class="btn primary" type="button">Подключить</button><button id="manualSync" class="btn" type="button">Синхронизировать</button></div><div class="small muted" style="margin-top:10px">В очереди: ${pending}. При плохой связи приложение продолжает работать локально.</div></section>
  <section class="card"><h3>🤖 AI-инвентаризация</h3><div class="kpi"><div><b>${photoCount}</b><span>фото</span></div><div><b>${batchCount}</b><span>партий</span></div><div><b>${movementCount}</b><span>движений</span></div></div><div class="alert" style="margin-top:12px"><div><b>Модуль подготовлен архитектурно</b><div class="small">Подключение OpenAI сделаем после обкатки складских операций. AI не будет менять остатки сам — только выдавать замечания и доказательства.</div></div></div><button id="aiReadiness" class="btn full">Проверить готовность к AI-аудиту</button></section>
  <section class="card"><div class="small muted">Версия ${CONFIG.version} · база offline-first · фото хранятся локально до подтверждённой загрузки.</div></section>`;
}

function bindRoute(){
  if(route==='receipt')bindReceipt();
  else if(route==='issue')bindIssue();
  else if(route==='return')bindReturn();
  else if(route==='stocks')bindStocks();
  else if(route==='product')bindProduct();
  else if(route==='opened')bindOpened();
  else if(route==='warehousePhotos')bindWarehousePhotos();
  else if(route==='settings')bindSettings();
}

function previewDraft(containerId){
  const box=document.getElementById(containerId);if(!box)return;box.innerHTML=draftPhotos.map((p,i)=>`<div class="photoThumb"><img src="${p.url}" alt="Фото"><button type="button" data-remove-photo="${i}">×</button></div>`).join('');
  box.querySelectorAll('[data-remove-photo]').forEach(b=>b.onclick=()=>{const i=Number(b.dataset.removePhoto);URL.revokeObjectURL(draftPhotos[i].url);draftPhotos.splice(i,1);previewDraft(containerId);});
}
function addDraftFiles(files,containerId){for(const f of Array.from(files||[])){if(!f.type.startsWith('image/'))continue;draftPhotos.push({id:uuid(),file:f,url:URL.createObjectURL(f)});}previewDraft(containerId);}
async function createPhotoRecords({owner,batchId=null,openedUnitId=null,sessionType='general',title='',note='',purpose='general',checkpointLabel=null}){
  if(!draftPhotos.length)return [];
  const op=currentOperator();const sessionRec={id:uuid(),owner_id:owner,session_type:sessionType,title:title||null,operator_id:op?.id||null,occurred_at:iso(),note:note||null,created_at:iso(),updated_at:iso()};
  await queueUpsert('chem_photo_sessions',sessionRec);
  const out=[];let ix=0;
  for(const dp of draftPhotos){
    const rec={id:dp.id,owner_id:owner,local_photo_id:dp.id,session_id:sessionRec.id,batch_id:batchId,opened_unit_id:openedUnitId,purpose:ix===0&&purpose==='label'?'label':purpose,checkpoint_label:checkpointLabel||null,storage_path:null,captured_at:iso(),uploaded_at:null,width_px:null,height_px:null,sha256:null,note:null,created_at:iso(),updated_at:iso(),deleted_at:null};
    await savePhotoBlob(dp.id,dp.file);await queueUpsert('chem_photos',rec,'local_photo_id');await queuePhotoUpload(dp.id);out.push(rec);ix++;
  }
  draftPhotos.forEach(p=>URL.revokeObjectURL(p.url));draftPhotos=[];return out;
}
async function findOrCreateProduct(name,unit,owner){
  const norm=name.trim().toLocaleLowerCase('ru-RU');let p=rows('chem_products').find(x=>String(x.name||'').trim().toLocaleLowerCase('ru-RU')===norm);
  if(p)return p;
  p={id:uuid(),owner_id:owner,name:name.trim(),manufacturer:null,active_ingredient:null,concentration:null,formulation:null,category:null,default_unit:unit,notes:null,created_at:iso(),updated_at:iso(),deleted_at:null};await queueUpsert('chem_products',p);return p;
}
function movementRecord({owner,batchId,type,delta,note='',openedUnitId=null}){const id=uuid();return {id,owner_id:owner,client_mutation_id:id,batch_id:batchId,movement_type:type,quantity_delta:Number(delta),operator_id:currentOperator()?.id||null,device_id:cache._deviceId||null,occurred_at:iso(),note:note||null,reverses_movement_id:null,opened_unit_id:openedUnitId,created_at:iso()};}

function bindReceipt(){
  for(const id of ['receiptPhotoCamera','receiptPhotoUpload']){const el=document.getElementById(id);if(el)el.onchange=e=>addDraftFiles(e.target.files,'receiptPhotos');}const manual=document.getElementById('receiptManual');if(manual)manual.onclick=()=>{const x=document.getElementById('rName');x?.focus();x?.scrollIntoView({behavior:'smooth',block:'center'});};
  const ps=document.getElementById('rPackSize'),pc=document.getElementById('rPackCount'),qty=document.getElementById('rQty'),unit=document.getElementById('rUnit'),calc=document.getElementById('rCalc');
  function updateCalc(){const a=Number(ps.value||0),b=Number(pc.value||0);if(a>0&&b>0){const total=a*b;calc.innerHTML=`По таре: <b>${fmtQty(total)} ${unitLabel(unit.value)}</b> <button type="button" id="useCalc" class="btn" style="min-height:30px;padding:4px 8px;margin-left:6px">Подставить</button>`;document.getElementById('useCalc').onclick=()=>{qty.value=total;};}else calc.textContent='';}
  [ps,pc,unit].forEach(x=>x.addEventListener('input',updateCalc));updateCalc();
  document.getElementById('receiptForm').onsubmit=async e=>{
    e.preventDefault();try{
      const owner=await requireOwner();const name=document.getElementById('rName').value.trim();const q=Number(document.getElementById('rQty').value);const u=document.getElementById('rUnit').value;if(!name||!(q>0))throw new Error('Укажи название и количество');
      const product=await findOrCreateProduct(name,u,owner);const batchNo=document.getElementById('rBatch').value.trim();const exp=document.getElementById('rExpiry').value||null;
      const batch={id:uuid(),owner_id:owner,product_id:product.id,temporary_name:name,batch_no:batchNo||null,manufactured_on:null,expires_on:exp,base_unit:u,package_type:document.getElementById('rPackType').value||null,package_size:Number(document.getElementById('rPackSize').value)||null,package_count:Number(document.getElementById('rPackCount').value)||null,supplier:document.getElementById('rSupplier').value.trim()||null,document_no:document.getElementById('rDoc').value.trim()||null,storage_location:'Основной склад',completeness:(batchNo&&exp)?'complete':'needs_details',notes:document.getElementById('rNote').value.trim()||null,created_at:iso(),updated_at:iso(),deleted_at:null};
      await queueUpsert('chem_batches',batch);await queueUpsert('chem_movements',movementRecord({owner,batchId:batch.id,type:'receipt',delta:q,note:batch.notes||'Приход'}),'client_mutation_id');
      await createPhotoRecords({owner,batchId:batch.id,sessionType:'receipt',title:`Приход · ${name}`,note:batch.notes||'',purpose:'label'});
      await refreshAll();showToast(`Принято: ${fmtQty(q)} ${unitLabel(u)} · ${name}`);setRoute('home');syncNow(true);
    }catch(err){if(err.message!=='NO_OWNER')showToast(err.message,4200);}
  };
}

function stockByKey(key){return productStock().find(s=>s.key===key)||null;}
function batchesForKey(key){const s=stockByKey(key);return s?s.batches:[];}
function bindIssue(){
  const sel=document.getElementById('iProduct'),info=document.getElementById('issueInfo'),unit=document.getElementById('iUnit');if(!sel)return;
  function update(){const s=stockByKey(sel.value);if(!s){unit.value='';info.innerHTML='';return;}unit.value=unitLabel(s.unit);const pos=s.batches.filter(x=>x.balance>0).sort((a,b)=>(a.batch.expires_on||'9999').localeCompare(b.batch.expires_on||'9999'));info.innerHTML=`<div class="alert ok"><div><b>Доступно ${fmtQty(s.total)} ${unitLabel(s.unit)}</b><div class="small">Сначала используем вскрытую тару, затем партии с ближайшим сроком.</div></div></div><div class="chips">${pos.slice(0,4).map(x=>`<span class="chip">${esc(x.batch.batch_no||'без №')} · ${fmtQty(x.balance)} ${unitLabel(x.batch.base_unit)}</span>`).join('')}</div>`;}
  sel.onchange=update;update();
  document.getElementById('issueForm').onsubmit=async e=>{e.preventDefault();try{const owner=await requireOwner();const key=sel.value,s=stockByKey(key),qty=Number(document.getElementById('iQty').value),note=document.getElementById('iNote').value.trim();if(!s||!(qty>0))throw new Error('Выбери препарат и количество');if(qty>s.total+0.00001)throw new Error(`По учёту доступно только ${fmtQty(s.total)} ${unitLabel(s.unit)}. Сначала уточни остаток.`);const after=s.total-qty;if(!confirm(`Выдать ${fmtQty(qty)} ${unitLabel(s.unit)} · ${s.name}?\nПосле операции останется ${fmtQty(after)} ${unitLabel(s.unit)}.`))return;await allocateIssue(owner,key,qty,note);await refreshAll();showToast(`Выдано ${fmtQty(qty)} ${unitLabel(s.unit)} · ${s.name}`);setRoute('home');syncNow(true);}catch(err){if(err.message!=='NO_OWNER')showToast(err.message,4500);}};
}
async function allocateIssue(owner,key,qty,note){
  let remaining=qty;const bm=balanceByBatch();const batches=batchesForKey(key).filter(x=>x.balance>0.000001).sort((a,b)=>(a.batch.expires_on||'9999-12-31').localeCompare(b.batch.expires_on||'9999-12-31')||String(a.batch.created_at).localeCompare(String(b.batch.created_at)));
  for(const bx of batches){if(remaining<=0.000001)break;const b=bx.batch;let take=Math.min(remaining,bm[b.id]||0);if(take<=0)continue;const opens=openedForBatch(b.id);let openTotal=opens.reduce((s,o)=>s+Number(o.remaining_estimate||0),0);
    for(const o of opens){if(take<=0.000001)break;const avail=Number(o.remaining_estimate||0);if(avail<=0)continue;const q=Math.min(take,avail);await queueUpsert('chem_movements',movementRecord({owner,batchId:b.id,type:'issue',delta:-q,note:note||'Выдача',openedUnitId:o.id}),'client_mutation_id');o.remaining_estimate=Math.max(0,avail-q);o.estimate_kind='exact';if(o.remaining_estimate<=0.000001)o.closed_at=iso();o.updated_at=iso();await queueUpsert('chem_opened_units',o);take-=q;remaining-=q;openTotal-=q;}
    if(take<=0.000001)continue;
    const closedAvailable=Math.max(0,(bm[b.id]||0)-opens.reduce((s,o)=>s+Number(o.remaining_estimate||0),0));const pack=Number(b.package_size||0);
    if(pack>0&&closedAvailable>0){const maxFull=Math.floor(Math.min(take,closedAvailable)/pack);if(maxFull>0){const q=maxFull*pack;await queueUpsert('chem_movements',movementRecord({owner,batchId:b.id,type:'issue',delta:-q,note:note||'Выдача целой тары'}),'client_mutation_id');take-=q;remaining-=q;}
      if(take>0.000001&&closedAvailable>=pack-0.000001){const q=Math.min(take,pack);const ou={id:uuid(),owner_id:owner,batch_id:b.id,label:`Вскрыто автоматически ${new Date().toLocaleDateString('ru-RU')}`,initial_quantity:pack,remaining_estimate:Math.max(0,pack-q),estimate_kind:'exact',opened_at:iso(),opened_by_operator_id:currentOperator()?.id||null,closed_at:q>=pack-0.000001?iso():null,note:'Создано при выдаче неполной тары',created_at:iso(),updated_at:iso(),deleted_at:null};await queueUpsert('chem_opened_units',ou);await queueUpsert('chem_movements',movementRecord({owner,batchId:b.id,type:'issue',delta:-q,note:note||'Выдача из новой вскрытой тары',openedUnitId:ou.id}),'client_mutation_id');take-=q;remaining-=q;}
    }
    if(take>0.000001){await queueUpsert('chem_movements',movementRecord({owner,batchId:b.id,type:'issue',delta:-take,note:note||'Выдача'}),'client_mutation_id');remaining-=take;take=0;}
  }
  if(remaining>0.0001)throw new Error('Не удалось распределить расход по партиям');
}

function bindReturn(){
  const sel=document.getElementById('retBatch'),unit=document.getElementById('retUnit'),openSel=document.getElementById('retOpened');
  function update(){const b=byId('chem_batches',sel.value);unit.value=b?unitLabel(b.base_unit):'';const os=b?openedForBatch(b.id):[];openSel.innerHTML='<option value="">В общий остаток партии</option>'+os.map(o=>`<option value="${o.id}">${esc(o.label||'Вскрытая тара')} · сейчас ${o.remaining_estimate==null?'?':fmtQty(o.remaining_estimate)} ${b?unitLabel(b.base_unit):''}</option>`).join('');}
  sel.onchange=update;update();
  document.getElementById('returnForm').onsubmit=async e=>{e.preventDefault();try{const owner=await requireOwner();const b=byId('chem_batches',sel.value),q=Number(document.getElementById('retQty').value),openedId=openSel.value,note=document.getElementById('retNote').value.trim();if(!b||!(q>0))throw new Error('Выбери партию и количество');if(openedId){const o=byId('chem_opened_units',openedId);if(o&&o.remaining_estimate!=null&&Number(o.remaining_estimate)+q>Number(o.initial_quantity)+0.0001)throw new Error('В выбранную вскрытую тару столько не помещается. Верни в общий остаток партии.');if(o){o.remaining_estimate=Number(o.remaining_estimate||0)+q;o.closed_at=null;o.updated_at=iso();await queueUpsert('chem_opened_units',o);}}await queueUpsert('chem_movements',movementRecord({owner,batchId:b.id,type:'return',delta:q,note:note||'Возврат на склад',openedUnitId:openedId||null}),'client_mutation_id');await refreshAll();showToast(`Возвращено ${fmtQty(q)} ${unitLabel(b.base_unit)}`);setRoute('home');syncNow(true);}catch(err){if(err.message!=='NO_OWNER')showToast(err.message,4200);}};
}

function bindStocks(){
  const search=document.getElementById('stockSearch');if(search)search.oninput=()=>{const q=search.value.trim().toLowerCase();document.querySelectorAll('#stockList .stockCard').forEach(c=>c.classList.toggle('hidden',q&&!c.dataset.name.includes(q)));};
  document.querySelectorAll('[data-product]').forEach(b=>b.onclick=()=>setRoute('product',{productKey:b.dataset.product}));
  document.querySelectorAll('[data-issue-product]').forEach(b=>b.onclick=()=>setRoute('issue',{productKey:b.dataset.issueProduct,fromProduct:b.dataset.issueProduct}));
}
function bindProduct(){
  document.querySelectorAll('[data-issue-product]').forEach(b=>b.onclick=()=>setRoute('issue',{productKey:b.dataset.issueProduct,fromProduct:b.dataset.issueProduct}));
  document.querySelectorAll('[data-open-batch]').forEach(b=>b.onclick=()=>setRoute('opened',{batchId:b.dataset.openBatch,productKey:b.dataset.productKey}));
  document.querySelectorAll('[data-batch-history]').forEach(b=>b.onclick=()=>showBatchHistory(b.dataset.batchHistory));
}
function showBatchHistory(batchId){
  const b=byId('chem_batches',batchId),p=productForBatch(b),ms=rows('chem_movements').filter(m=>m.batch_id===batchId).sort((a,b)=>String(b.occurred_at).localeCompare(String(a.occurred_at))).slice(0,100);const typeName={receipt:'Приход',issue:'Выдача',return:'Возврат',adjustment:'Корректировка',writeoff:'Списание'};
  const html=`<div class="modalShade" id="modal"><div class="sheet"><h2>${esc(p?.name||b?.temporary_name||'История')}</h2><div class="small muted" style="margin-bottom:12px">Партия ${esc(b?.batch_no||'не указана')}</div>${ms.length?ms.map(m=>`<div class="batch"><div class="batchLine"><strong>${esc(typeName[m.movement_type]||m.movement_type)}</strong><b class="${Number(m.quantity_delta)<0?'dangerText':'okText'}">${Number(m.quantity_delta)>0?'+':''}${fmtQty(m.quantity_delta)} ${unitLabel(b.base_unit)}</b></div><div class="small muted">${formatDateTime(m.occurred_at)} · ${esc(m.note||'без заметки')}</div></div>`).join(''):'<div class="empty">Движений нет</div>'}<button class="btn full" id="closeModal">Закрыть</button></div></div>`;document.body.insertAdjacentHTML('beforeend',html);document.getElementById('closeModal').onclick=()=>document.getElementById('modal').remove();document.getElementById('modal').onclick=e=>{if(e.target.id==='modal')e.currentTarget.remove();};
}

function bindOpened(){
  for(const id of ['openedPhotoCamera','openedPhotoUpload']){const el=document.getElementById(id);if(el)el.onchange=e=>addDraftFiles(e.target.files,'openedPhotos');}
  const ini=document.getElementById('oInitial'),rem=document.getElementById('oRemaining');if(ini&&rem)ini.oninput=()=>{if(!rem.dataset.touched)rem.value=ini.value;};if(rem)rem.oninput=()=>rem.dataset.touched='1';
  document.querySelectorAll('[data-adjust-opened]').forEach(b=>b.onclick=()=>showAdjustOpened(b.dataset.adjustOpened));
  document.getElementById('openedForm').onsubmit=async e=>{e.preventDefault();try{const owner=await requireOwner();const b=byId('chem_batches',routeData.batchId),bm=balanceByBatch();const initial=Number(ini.value),remaining=Number(rem.value);if(!b||!(initial>0)||remaining<0||remaining>initial)throw new Error('Проверь размер тары и текущий остаток');if(initial>(bm[b.id]||0)+0.0001)throw new Error(`По базе в партии только ${fmtQty(bm[b.id]||0)} ${unitLabel(b.base_unit)}. Размер вскрываемой тары больше остатка.`);const ou={id:uuid(),owner_id:owner,batch_id:b.id,label:document.getElementById('oLabel').value.trim()||null,initial_quantity:initial,remaining_estimate:remaining,estimate_kind:'exact',opened_at:iso(),opened_by_operator_id:currentOperator()?.id||null,closed_at:remaining<=0.000001?iso():null,note:document.getElementById('oNote').value.trim()||null,created_at:iso(),updated_at:iso(),deleted_at:null};await queueUpsert('chem_opened_units',ou);const consumed=initial-remaining;if(consumed>0.000001)await queueUpsert('chem_movements',movementRecord({owner,batchId:b.id,type:'issue',delta:-consumed,note:'Расход при фиксации вскрытой тары',openedUnitId:ou.id}),'client_mutation_id');await createPhotoRecords({owner,batchId:b.id,openedUnitId:ou.id,sessionType:'opened',title:`Вскрыто · ${productForBatch(b)?.name||b.temporary_name}`,note:ou.note||'',purpose:'opened'});await refreshAll();showToast('Вскрытая тара сохранена');setRoute('product',{productKey:routeData.productKey});syncNow(true);}catch(err){if(err.message!=='NO_OWNER')showToast(err.message,4300);}};
}
function showAdjustOpened(openedId){
  const o=byId('chem_opened_units',openedId),b=byId('chem_batches',o?.batch_id);if(!o||!b)return;const html=`<div class="modalShade" id="adjustModal"><div class="sheet"><h2>Уточнить остаток</h2><div class="small muted" style="margin-bottom:12px">${esc(o.label||'Вскрытая тара')} · было ${o.remaining_estimate==null?'неизвестно':fmtQty(o.remaining_estimate)+' '+unitLabel(b.base_unit)}</div><div class="field"><label>Фактически сейчас</label><input id="adjValue" type="number" min="0" max="${o.initial_quantity}" step="0.001" value="${o.remaining_estimate??''}" inputmode="decimal"></div><div class="field"><label>Заметка</label><input id="adjNote" placeholder="Например: проверено по весам"></div><div class="btnRow"><button class="btn" id="adjCancel">Отмена</button><button class="btn primary" id="adjSave">Сохранить</button></div></div></div>`;document.body.insertAdjacentHTML('beforeend',html);document.getElementById('adjCancel').onclick=()=>document.getElementById('adjustModal').remove();document.getElementById('adjSave').onclick=async()=>{try{const owner=await requireOwner();const nv=Number(document.getElementById('adjValue').value);if(nv<0||nv>Number(o.initial_quantity))throw new Error('Некорректный остаток');const old=o.remaining_estimate==null?null:Number(o.remaining_estimate);const delta=old==null?0:nv-old;o.remaining_estimate=nv;o.estimate_kind='exact';o.closed_at=nv<=0.000001?iso():null;o.note=document.getElementById('adjNote').value.trim()||o.note;o.updated_at=iso();await queueUpsert('chem_opened_units',o);if(Math.abs(delta)>0.000001)await queueUpsert('chem_movements',movementRecord({owner,batchId:b.id,type:'adjustment',delta:delta,note:document.getElementById('adjNote').value.trim()||'Уточнение фактического остатка вскрытой тары',openedUnitId:o.id}),'client_mutation_id');await refreshAll();document.getElementById('adjustModal').remove();showToast('Фактический остаток обновлён');render();syncNow(true);}catch(err){showToast(err.message,4000);}};
}

function bindWarehousePhotos(){
  for(const id of ['warehousePhotoCamera','warehousePhotoUpload']){const el=document.getElementById(id);if(el)el.onchange=e=>addDraftFiles(e.target.files,'warehousePhotos');}
  document.getElementById('warehousePhotoForm').onsubmit=async e=>{e.preventDefault();try{const owner=await requireOwner();if(!draftPhotos.length)throw new Error('Сделай хотя бы одну фотографию');const cp=document.getElementById('wCheckpoint').value.trim()||'Общий вид';const note=document.getElementById('wNote').value.trim();await createPhotoRecords({owner,sessionType:'warehouse_checkpoint',title:cp,note,purpose:'warehouse',checkpointLabel:cp});await refreshAll();showToast('Фото склада сохранены');setRoute('home');syncNow(true);}catch(err){if(err.message!=='NO_OWNER')showToast(err.message,4200);}};
}

async function updateDevice(){
  const owner=await ownerId();if(!owner)return;const rec={id:cache._deviceId,owner_id:owner,label:cache._deviceLabel||'Рабочее устройство',platform:navigator.userAgent,current_operator_id:cache._currentOperatorId||null,last_seen_at:iso(),last_sync_at:lastSyncAt?new Date(lastSyncAt).toISOString():null,created_at:(byId('chem_devices',cache._deviceId)?.created_at||iso()),updated_at:iso()};await queueUpsert('chem_devices',rec);
}
function bindSettings(){
  document.querySelectorAll('[data-select-operator]').forEach(b=>b.onclick=async()=>{await setSetting('current_operator_id',b.dataset.selectOperator);await refreshAll();await updateDevice();await refreshAll();showToast('Сотрудник выбран');render();syncNow(true);});
  document.getElementById('operatorForm').onsubmit=async e=>{e.preventDefault();try{const owner=await requireOwner();const name=document.getElementById('opName').value.trim();if(!name)throw new Error('Укажи имя сотрудника');const rec={id:uuid(),owner_id:owner,name,position:document.getElementById('opPosition').value.trim()||null,is_active:true,created_at:iso(),updated_at:iso(),deleted_at:null};await queueUpsert('chem_operators',rec);await setSetting('current_operator_id',rec.id);await refreshAll();await updateDevice();await refreshAll();showToast('Сотрудник добавлен');render();syncNow(true);}catch(err){if(err.message!=='NO_OWNER')showToast(err.message,4200);}};
  document.getElementById('saveDevice').onclick=async()=>{cache._deviceLabel=document.getElementById('deviceLabel').value.trim()||'Рабочее устройство';await setSetting('device_label',cache._deviceLabel);await updateDevice();await refreshAll();showToast('Название устройства сохранено');render();syncNow(true);};
  document.getElementById('cloudLogin').onclick=async()=>{try{if(!isOnline())throw new Error('Для первого входа нужен интернет');const email=document.getElementById('cloudEmail').value.trim(),pass=document.getElementById('cloudPassword').value;await login(email,pass);await refreshAll();await updateDevice();showToast('Облако подключено. Синхронизирую…');await syncNow(false);}catch(err){showToast('Вход: '+err.message,5200);}};
  document.getElementById('manualSync').onclick=async()=>{if(!session?.access_token){showToast('Сначала подключи облако');return;}if(!isOnline()){showToast('Сейчас нет интернета');return;}await syncNow(false);};
  document.getElementById('aiReadiness').onclick=()=>{const photos=rows('chem_photos').length,batches=rows('chem_batches').length,moves=rows('chem_movements').length,warehouse=rows('chem_photos').filter(p=>p.purpose==='warehouse').length,needs=rows('chem_batches').filter(b=>b.completeness==='needs_details').length;const issues=[];if(photos<5)issues.push('пока мало фотографий');if(warehouse<2)issues.push('нужно накопить фото склада с повторяемых ракурсов');if(needs)issues.push(`${needs} приход(а) требуют уточнения`);const text=`Для будущего AI-аудита уже есть: ${photos} фото, ${batches} партий, ${moves} движений. ${issues.length?'Нужно улучшить: '+issues.join('; ')+'.':'Набор данных уже пригоден для тестового аудита.'}`;showToast(text,7500);};
}

function syncPriority(table){return ({chem_operators:10,chem_products:10,chem_devices:20,chem_batches:30,chem_opened_units:40,chem_photo_sessions:40,chem_inventory_sessions:40,chem_movements:50,chem_inventory_counts:55,chem_photos:60,chem_ai_audits:70,chem_ai_findings:80})[table]||50;}
const _queueUpsert=queueUpsert;
queueUpsert=async function(table,payload,conflict='id'){
  await idbPut(table,payload);
  await idbPut('pending',{id:`upsert:${table}:${payload.id}`,kind:'upsert',table,conflict,payload,priority:syncPriority(table),created_at:iso()});
  await reloadCache();
};
const _pushPending=pushPending;
pushPending=async function(){
  const list=(await idbAll('pending')).sort((a,b)=>(Number(a.priority||70)-Number(b.priority||70))||String(a.created_at).localeCompare(String(b.created_at)));
  for(const p of list){
    if(p.kind==='upsert')await rest(p.table,`on_conflict=${encodeURIComponent(p.conflict||'id')}`,{method:'POST',headers:{Prefer:'resolution=merge-duplicates,missing=default,return=minimal'},body:JSON.stringify(p.payload)});
    else if(p.kind==='photoUpload'){const photo=await idbGet('chem_photos',p.photoId);if(photo){const updated=await storageUpload(photo);await rest('chem_photos','on_conflict=local_photo_id',{method:'POST',headers:{Prefer:'resolution=merge-duplicates,missing=default,return=minimal'},body:JSON.stringify(updated)});}}
    await idbDelete('pending',p.id);
  }
};

function installNavigation(){
  const st=history.state;if(st?.chemApp){route=st.route||'home';routeData=st.data||{};}else{try{history.replaceState({chemApp:true,route:'home',data:{}},'');}catch(e){}}
  window.addEventListener('popstate',e=>{const x=e.state;if(x?.chemApp)applyRoute(x.route||'home',x.data||{});else applyRoute('home');});
  const standalone=(window.matchMedia&&window.matchMedia('(display-mode: standalone)').matches)||window.navigator.standalone===true;let sx=0,sy=0,armed=false;
  if(standalone){document.addEventListener('touchstart',e=>{const t=e.touches?.[0];if(!t)return;sx=t.clientX;sy=t.clientY;armed=route!=='home'&&sx<=28;},{passive:true});document.addEventListener('touchend',e=>{if(!armed)return;armed=false;const t=e.changedTouches?.[0];if(!t)return;const dx=t.clientX-sx,dy=Math.abs(t.clientY-sy);if(dx>=75&&dy<=60)historyBack();},{passive:true});}
}
async function boot(){
  db=await openDb();await refreshAll();installNavigation();const ls=await setting('last_sync_at',null);if(ls)lastSyncAt=new Date(ls).getTime();render();
  if(session?.access_token&&isOnline())syncNow(true);
  setInterval(()=>{if(session?.access_token&&isOnline())syncNow(true);},30000);
  window.addEventListener('online',()=>{renderHeaderOnly();syncNow(true);});window.addEventListener('offline',renderHeaderOnly);
  document.addEventListener('visibilitychange',()=>{if(document.visibilityState==='visible'&&session?.access_token&&isOnline())syncNow(true);});
  if('serviceWorker' in navigator)window.addEventListener('load',()=>navigator.serviceWorker.register('./sw.js',{updateViaCache:'none'}).then(r=>r.update()).catch(console.warn));
}
boot().catch(e=>{console.error(e);app.innerHTML=`<div class="content"><section class="card"><h3>Не удалось открыть локальную базу</h3><div class="dangerText">${esc(e.message)}</div></section></div>`;});

})();
