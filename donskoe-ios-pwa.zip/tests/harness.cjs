const fs=require('fs'),path=require('path'),{JSDOM,ResourceLoader,VirtualConsole}=require('jsdom'),{IDBFactory,IDBKeyRange}=require('fake-indexeddb');
const ROOT=path.resolve(__dirname,'..');
class MemoryStorage{
 constructor(seed={}){this.map=new Map(Object.entries(seed));this.fail=null;}
 get length(){return this.map.size;}key(i){return [...this.map.keys()][i]??null;}
 getItem(k){return this.map.has(k)?this.map.get(k):null;}
 setItem(k,v){if(this.fail?.(k,v))throw new Error('QuotaExceededError');this.map.set(k,String(v));}
 removeItem(k){if(this.fail?.(k,null))throw new Error('QuotaExceededError');this.map.delete(k);}
 clear(){this.map.clear();}
}
const hooks={
 connisseur:"window.qa={get state(){return state},get pending(){return pending},sm4Prediction,workSetup,createBag,nextBagNo,bagActiveSec,runActiveSec,processedSeedKg,cloudSync,flushPending,queueRecord,deleteBagRecord,setBagLearning,showPage,saveState,saveWorkDraft,restoreWorkDraft,renderWork,renderHistory,openBagWeight,currentRun,currentBag,pauseLine,resumeLine,stopLineHere,protectMutation};",
 chem:"window.qa={get cache(){return cache},get db(){return db},get draftPhotos(){return draftPhotos},set draftPhotos(v){draftPhotos=v},get route(){return route},get busy(){return mutationBusy},get operationContext(){return operationContext},setRoute,render,refreshAll,idbAll,idbGet,idbPut,queueUpsert,queueReceiptEntries,allocateIssue,runWarehouseMutation,commitWarehouse,createPhotoRecords,balanceByBatch,productStock,openedForBatch,syncNow,pushPending,settlePending,guardWarehouseControls,persistChemPhotos,restoreChemForm,captureChemDraft,showAdjustOpened};",
 dryer:"window.qa={get state(){return state},get cloud(){return cloud},get activePlan(){return activePlan},collect,saveDraft,restoreDraft,resetCurrent,loadCycleForEdit,nextCycleNumber,cycleLedger,validateCycle,cloudSync,cloudFlushPending,cloudUpsert,showPage,dryerHistoryBack,get currentPage(){return currentPage},saveHistory,photoPut,photoAll,deletePhoto};"
};
function instrument(code,module){const index=code.lastIndexOf('})();');if(index<0)return code;return code.slice(0,index)+hooks[module]+'\n'+code.slice(index);}
async function load(module,options={}){
 const storage=options.storage||new MemoryStorage(),indexedDB=options.indexedDB||new IDBFactory(),logs=[],alerts=[],net={online:false,fetch:null},clock=options.clock||{now:Date.now()};
 class Loader extends ResourceLoader{fetch(url){const u=new URL(url),rel=decodeURIComponent(u.pathname).replace(/^\//,'');let file=path.join(ROOT,rel);if(fs.existsSync(file)&&fs.statSync(file).isFile()){let content=fs.readFileSync(file);if(rel===module+'/app.js')content=Buffer.from(instrument(content.toString(),module));return Promise.resolve(content);}return null;}}
 let html=fs.readFileSync(path.join(ROOT,module==='root'?'index.html':module+'/index.html'),'utf8');
 if(module==='dryer')html=html.replace(/<script>([\s\S]*?)<\/script>/,(all,c)=>'<script>'+instrument(c,module)+'</script>');
 const vc=new VirtualConsole();vc.on('jsdomError',e=>logs.push(e));vc.on('error',e=>logs.push(e));
 const dom=new JSDOM(html,{url:'https://donskoe.test/'+(module==='root'?'':module+'/'),resources:new Loader(),runScripts:'dangerously',pretendToBeVisual:true,virtualConsole:vc,beforeParse(w){
   const NativeDate=w.Date;w.Date=class extends NativeDate{constructor(...args){super(...(args.length?args:[clock.now]));}static now(){return clock.now;}};
   Object.defineProperty(w,'localStorage',{value:storage});if(options.sessionStorage)Object.defineProperty(w,'sessionStorage',{value:options.sessionStorage});w.indexedDB=indexedDB;w.IDBKeyRange=IDBKeyRange;w.structuredClone=structuredClone;
   w.crypto.randomUUID=require('crypto').randomUUID;w.fetch=(...args)=>net.fetch?net.fetch(...args):Promise.reject(new Error('Failed to fetch'));
   Object.defineProperty(w.navigator,'onLine',{get:()=>net.online});w.navigator.serviceWorker={getRegistrations:async()=>[],register:async()=>({update:async()=>{},addEventListener(){},waiting:null}),addEventListener(){},ready:Promise.resolve({showNotification:async()=>{}})};
   w.matchMedia=()=>({matches:!!options.standalone,addEventListener(){},removeEventListener(){}});w.scrollTo=()=>{};w.alert=m=>alerts.push(String(m));w.confirm=()=>true;w.prompt=()=>null;w.URL.createObjectURL=()=> 'blob:test';w.URL.revokeObjectURL=()=>{};w.setInterval=()=>0;w.Notification={permission:'denied',requestPermission:async()=> 'denied'};
   w.Blob=Blob;w.File=File;w.FileReader=class{readAsDataURL(b){b.arrayBuffer().then(x=>{this.result='data:'+b.type+';base64,'+Buffer.from(x).toString('base64');this.onload?.();}).catch(e=>this.onerror?.(e));}};
 }});
 await new Promise(resolve=>dom.window.addEventListener('load',resolve,{once:true}));await tick(60);
 return {dom,w:dom.window,q:dom.window.qa,storage,indexedDB,logs,alerts,net,clock,close:()=>dom.window.close()};
}
function tick(ms=20){return new Promise(r=>setTimeout(r,ms));}
function input(app,id,value){const e=app.w.document.getElementById(id);if(!e)throw Error('Input missing '+id);e.value=String(value);e.dispatchEvent(new app.w.Event('input',{bubbles:true}));return e;}
async function click(app,id){const el=app.w.document.getElementById(id);if(!el)throw Error('Button missing '+id);el.click();await tick(40);}
async function submit(app,id){const e=app.w.document.getElementById(id);e.dispatchEvent(new app.w.Event('submit',{bubbles:true,cancelable:true}));await tick(60);}
module.exports={load,MemoryStorage,tick,input,click,submit};
if(require.main===module)(async()=>{for(const m of ['root','connisseur','dryer','chem']){try{const a=await load(m);console.log(m,!!a.q,a.logs.map(e=>e.message),a.w.document.body.textContent.slice(-80));a.close();}catch(e){console.error(m,e);process.exitCode=1;}}})();
