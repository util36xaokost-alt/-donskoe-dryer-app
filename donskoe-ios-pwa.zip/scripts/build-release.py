from pathlib import Path
import json
root=Path(__file__).resolve().parents[1]
release=json.loads((root/'release.json').read_text())
version=release['version']
package_path=root/'package.json'
if package_path.exists():
 package=json.loads(package_path.read_text());package['version']=version;package_path.write_text(json.dumps(package,ensure_ascii=False,indent=2)+chr(10))
(root/'shared/release.js').write_text('// Generated from release.json. Edit release.json, then run scripts/build-release.py.\n'+'globalThis.DONSKOE_RELEASE='+json.dumps(release,ensure_ascii=False)+';\n')
core=['./index.html','./attention.html','./styles.css','./app.js','./attention.js','./manifest.webmanifest','./logo.png','./apple-touch-icon.png','./icon-192.png','./icon-512.png','./header-hero.png','./dryer-module.png','./warehouse-module.png','./connisseur-module.png','./fields-module.png','./shared/release.js','./shared/core.js','./shared/theme.css','./shared/ui.js']
shared=['../shared/release.js','../shared/core.js','../shared/theme.css','../shared/ui.js']
modules={}
for module in ['dryer','chem','connisseur','fields']:
 modules[module]=['./index.html','./manifest.webmanifest','./logo.png','./icon-192.png','./icon-512.png']+shared
 if module!='dryer':modules[module]+=['./app.js','./styles.css']
 if module=='connisseur':modules[module]+=['./connisseur-logo.png']
 elif module=='fields':modules[module]+=['./fields-data.js','./apple-touch-icon.png']
 else:modules[module]+=['./apple-touch-icon.png']
template=r"""
// Immutable shell cache for one release. User journals and photos live separately.
const CACHE=__CACHE__, PREFIX=__PREFIX__, CORE=__CORE__, OPTIONAL=__OPTIONAL__;
const OFFLINE='<!doctype html><html lang="ru"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><style>body{font:16px/1.6 system-ui;background:#f1f3f2;color:#182f2c;padding:30px}main{max-width:480px;margin:40px auto}a{color:#126a51}</style><main><h1>Донское</h1><p>Не удалось открыть страницу из локального кэша.</p><p>Вернитесь на главный экран и нажмите Refresh при наличии интернета.</p><a href="__HOME__">На главный экран</a></main></html>';
self.addEventListener('install',event=>event.waitUntil((async()=>{
 const cache=await caches.open(CACHE);
 try{await cache.addAll(CORE);}catch(e){await caches.delete(CACHE);throw e;}
 await Promise.allSettled(OPTIONAL.map(group=>cache.addAll(group)));
 // Existing workers continue until windows close or the operator accepts the update.
})()));
self.addEventListener('message',event=>{if(event.data?.type==='ACTIVATE_UPDATE')self.skipWaiting();});
self.addEventListener('activate',event=>event.waitUntil((async()=>{
 const names=await caches.keys();
 await Promise.all(names.filter(n=>n.startsWith(PREFIX)&&n!==CACHE).map(n=>caches.delete(n)));
 await self.clients.claim();
})()));
self.addEventListener('fetch',event=>{
 if(event.request.method!=='GET')return;
 const url=new URL(event.request.url),scope=new URL(self.registration.scope);
 if(url.origin!==scope.origin)return;
 // Never cache authenticated API calls or arbitrary same-origin responses.
 const pathname=url.pathname;
 let key;
 if(event.request.mode==='navigate'){
  let relative=pathname.startsWith(scope.pathname)?pathname.slice(scope.pathname.length):'';
  if(!relative||relative==='index.html')relative='index.html';
  else if(__MASTER__){const mod=relative.split('/')[0];if(['dryer','chem','connisseur','fields'].includes(mod))relative=mod+'/index.html';}
  key=new URL(relative,scope).href;
 }else{
  const clean=new URL(url);clean.search='';clean.hash='';key=clean.href;
 }
 const known=[...CORE,...OPTIONAL.flat()].some(p=>new URL(p,scope).href===key);
 if(!known)return;
 event.respondWith((async()=>{
  const cache=await caches.open(CACHE),cached=await cache.match(key);
  if(cached)return cached;
  try{
   const ctrl=new AbortController(),timer=setTimeout(()=>ctrl.abort(),10000);
   try{const response=await fetch(event.request,{signal:ctrl.signal,cache:'no-store'});if(!response.ok)throw new Error('HTTP '+response.status);return response;}finally{clearTimeout(timer);}
  }catch(e){return event.request.mode==='navigate'?new Response(OFFLINE,{status:503,headers:{'Content-Type':'text/html;charset=utf-8'}}):new Response('',{status:504});}
 })());
});
"""
for module in ['master','dryer','chem','connisseur','fields']:
 prefix={'master':'donskoe-master-','dryer':'donskoe-dryer-module-','chem':'donskoe-chem-','connisseur':'donskoe-connisseur-','fields':'donskoe-fields-'}[module]
 optional=[]
 if module=='master':
  master_core=list(core)
  for name,assets in modules.items():
   master_core += ['./'+name+'/'+asset[2:] for asset in assets if asset.startswith('./')]
  # One atomic app shell: a release is not installed unless every module asset is cached.
  # This guarantees first-launch offline use and prevents missing module logos/images.
  selected_core=list(dict.fromkeys(master_core))
 else:
  selected_core=modules[module]
 code=template.replace('__CACHE__',json.dumps(prefix+version+'-'+release['build'])).replace('__PREFIX__',json.dumps(prefix)).replace('__CORE__',json.dumps(selected_core)).replace('__OPTIONAL__',json.dumps(optional)).replace('__MASTER__','true' if module=='master' else 'false').replace('__HOME__','./index.html' if module=='master' else '../index.html')
 (root/('sw.js' if module=='master' else module+'/sw.js')).write_text(code)
for module in ['master','dryer','chem','connisseur','fields']:
 p=root/('manifest.webmanifest' if module=='master' else module+'/manifest.webmanifest')
 manifest=json.loads(p.read_text())
 manifest.update(version=version,theme_color='#182f2c',background_color='#f1f3f2')
 p.write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
# Deployment verifies the exact runtime files shipped in the ZIP.
import hashlib
assets={}
for folder in ['', 'shared', 'dryer', 'chem', 'connisseur', 'fields']:
 for p in (root/folder).iterdir():
  if p.is_file() and p.suffix in ('.html','.js','.css','.webmanifest','.png'):
   assets[p.relative_to(root).as_posix()]=hashlib.sha256(p.read_bytes()).hexdigest()
for name in ['release.json','package.json']:
 assets[name]=hashlib.sha256((root/name).read_bytes()).hexdigest()
(root/'asset-integrity.json').write_text(json.dumps(assets,indent=2)+chr(10))
