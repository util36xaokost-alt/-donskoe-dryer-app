from pathlib import Path
import sys,json,re,hashlib
root=Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).resolve().parents[1]
v=json.loads((root/'release.json').read_text())['version']
assert json.loads((root/'package.json').read_text())['version']==v
for module in ['', 'dryer/', 'chem/', 'connisseur/', 'fields/']:
 assert json.loads((root/(module+'manifest.webmanifest')).read_text())['version']==v,module
 html=(root/(module+'index.html')).read_text()
 assert 'shared/release.js' in html
 assert not re.search(r'Web\s+\d+\.\d+\.\d+',html), 'Old hard-coded footer: '+module
 assert v in (root/(module+'sw.js')).read_text(),module
assert '"version": "'+v+'"' in (root/'shared/release.js').read_text()
# Fields are release data, not an online dependency. Keep the production field base complete and immutable in the shell.
fields_js=(root/'fields/fields-data.js').read_text()
assert fields_js.startswith('globalThis.DONSKOE_FIELDS_DATA=')
payload=fields_js.split('=',1)[1].strip()
if payload.endswith(';'): payload=payload[:-1]
fields=json.loads(payload)
assert len(fields.get('fields',[]))==39, 'Expected 39 production field contours'
assert len({f['id'] for f in fields['fields']})==39, 'Duplicate field ids'
assert all(f.get('name') and len(f.get('coordinates',[]))>=3 and float(f.get('areaHa',0))>0 for f in fields['fields']), 'Broken field geometry'
assert len(fields.get('points',[]))==1 and fields['points'][0].get('name')=='Антена', 'Infrastructure point dedupe failed'
master_sw=(root/'sw.js').read_text()
for required in ['./fields/index.html','./fields/app.js','./fields/styles.css','./fields/fields-data.js','./fields-module.png']:
 assert required in master_sw,'Fields asset missing from atomic offline shell: '+required
# The fields module must remain self-contained/offline: no external scripts, styles or tile URLs in its HTML.
fields_html=(root/'fields/index.html').read_text()
assert not re.search(r'(?:src|href)=["\']https?://',fields_html,re.I), 'External dependency in fields module'
if (root/'asset-integrity.json').exists():
 for path,sha in json.loads((root/'asset-integrity.json').read_text()).items():
  assert hashlib.sha256((root/path).read_bytes()).hexdigest()==sha,'Mixed or damaged release: '+path
print('Verified Donskoe '+v+'; root and all four modules match; 39 field contours are offline-ready.')
