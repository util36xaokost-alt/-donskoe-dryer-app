from pathlib import Path
import sys,json,re,hashlib
root=Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).resolve().parents[1]
v=json.loads((root/'release.json').read_text())['version']
assert json.loads((root/'package.json').read_text())['version']==v
for module in ['', 'dryer/', 'chem/', 'connisseur/', 'fields/']:
 assert json.loads((root/(module+'manifest.webmanifest')).read_text())['version']==v,module
 html=(root/(module+'index.html')).read_text()
 assert 'shared/release.js' in html
 assert not re.search(r'Web\s+\d+\.\d+\.\d+',html), 'Old hard-coded footer: '+module
 assert v in (root/(module+'sw.js')).read_text(),module
assert '"version": "'+v+'"' in (root/'shared/release.js').read_text()
if (root/'asset-integrity.json').exists():
 for path,sha in json.loads((root/'asset-integrity.json').read_text()).items():
  assert hashlib.sha256((root/path).read_bytes()).hexdigest()==sha,'Mixed or damaged release: '+path
print('Verified Donskoe '+v+'; root and all four modules match.')
