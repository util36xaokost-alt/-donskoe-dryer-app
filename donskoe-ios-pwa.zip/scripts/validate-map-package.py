#!/usr/bin/env python3
from pathlib import Path
import hashlib, json, sys

manifest_path=Path(sys.argv[1]) if len(sys.argv)>1 else Path('manifest.json')
m=json.loads(manifest_path.read_text(encoding='utf-8'))
assert int(m.get('schema',1))==1
assert m.get('id') and m.get('version') and isinstance(m.get('blocks'),list) and m['blocks']
base=manifest_path.parent
size=0
for i,b in enumerate(m['blocks'],1):
    assert b.get('id') and (b.get('file') or b.get('url')), f'block {i}: missing id/file'
    bounds=b.get('bounds') or {}
    for k in ('minLon','minLat','maxLon','maxLat'): assert isinstance(bounds.get(k),(int,float)), f'block {i}: {k}'
    if b.get('file'):
        p=base/b['file']; assert p.is_file(), f'missing {p}'
        raw=p.read_bytes(); size+=len(raw)
        if b.get('bytes'): assert len(raw)==int(b['bytes']), f'bad size {p}'
        if b.get('sha256'): assert hashlib.sha256(raw).hexdigest().lower()==b['sha256'].lower(), f'bad sha256 {p}'
print(f"Map package OK: {m['id']} {m['version']} · {len(m['blocks'])} blocks · {size/1024/1024:.1f} MiB")
