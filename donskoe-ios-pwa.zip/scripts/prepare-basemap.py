#!/usr/bin/env python3
"""Legacy entry point retained for compatibility.

Since 7.4.12 the application deploy NEVER downloads map imagery. Map imagery is
prepared as a separate versioned package and published independently. Use
validate-map-package.py to validate a prepared package manifest.
"""
raise SystemExit("7.4.12+: basemap is an independent package; do not prepare it during app deploy")
