#!/usr/bin/env python3
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed
import json, math, os, re, sys, time, urllib.request, urllib.error

root = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(__file__).resolve().parents[1]
data_text = (root/'fields/data.js').read_text(encoding='utf-8')
m = re.search(r'window\.DONSKOE_FIELDS_DATA=(\{.*\});\s*$', data_text, re.S)
if not m:
    raise SystemExit('Cannot parse fields/data.js')
data = json.loads(m.group(1))
fields = data['fields']
zooms = (15,16)
buffer_m = 500
lat0 = (data['bounds']['minLat']+data['bounds']['maxLat'])/2
coslat = math.cos(math.radians(lat0))
buf_lat = buffer_m/110540
buf_lon = buffer_m/(111320*coslat)

def tile_xy(lon,lat,z):
    n=2**z
    x=(lon+180)/360*n
    y=(1-math.asinh(math.tan(math.radians(lat)))/math.pi)/2*n
    return x,y

tiles=set()
for f in fields:
    lons=[c[0] for c in f['coords']]; lats=[c[1] for c in f['coords']]
    for z in zooms:
        a=tile_xy(min(lons)-buf_lon,max(lats)+buf_lat,z)
        b=tile_xy(max(lons)+buf_lon,min(lats)-buf_lat,z)
        x0,x1=sorted((math.floor(a[0]),math.floor(b[0])))
        y0,y1=sorted((math.floor(a[1]),math.floor(b[1])))
        for x in range(x0,x1+1):
            for y in range(y0,y1+1): tiles.add((z,x,y))

tiles=sorted(tiles)
outdir=root/'fields/basemap/tiles'
outdir.mkdir(parents=True,exist_ok=True)
# Primary source is the NSPD main orthophoto layer (ЕЭКО ортофото).
# It expects the NSPD map referer, which a browser hosted on GitHub Pages cannot provide.
# Therefore tiles are fetched once during the GitHub Pages build and served same-origin.
SOURCES=[
    ('https://nspd.gov.ru/cgk/map/39/tms/{z}/{x}/{y}.png','https://nspd.gov.ru/map?baseLayerId=36346'),
    ('https://nspd.gov.ru/api/aeggis/v2/36344/wmts/{z}/{x}/{y}.png','https://nspd.gov.ru/map?baseLayerId=36344'),
]

def looks_image(data,ctype=''):
    return len(data)>500 and (data.startswith(b'\x89PNG\r\n\x1a\n') or data.startswith(b'\xff\xd8\xff') or 'image/' in ctype.lower())

def fetch_one(t):
    z,x,y=t; dest=outdir/str(z)/str(x)/(str(y)+'.png')
    if dest.exists() and dest.stat().st_size>500:
        return t,'cached',dest.stat().st_size
    dest.parent.mkdir(parents=True,exist_ok=True)
    last=''
    for template,referer in SOURCES:
        url=template.format(z=z,x=x,y=y)
        for attempt in range(4):
            try:
                req=urllib.request.Request(url,headers={
                    'User-Agent':'Mozilla/5.0 DonskoeMap/7.4.11',
                    'Referer':referer,
                    'Accept':'image/avif,image/webp,image/apng,image/*,*/*;q=0.8'
                })
                with urllib.request.urlopen(req,timeout=25) as r:
                    raw=r.read(); ctype=r.headers.get('Content-Type','')
                if not looks_image(raw,ctype):
                    raise RuntimeError(f'not an image ({ctype}, {len(raw)} bytes)')
                tmp=dest.with_suffix('.tmp'); tmp.write_bytes(raw); tmp.replace(dest)
                return t,'ok',len(raw)
            except Exception as e:
                last=f'{type(e).__name__}: {e}'
                time.sleep(.7*(attempt+1))
    return t,'failed',last

print(f'Preparing Donskoe orthophoto basemap: {len(tiles)} tiles (z15+z16)')
ok=fail=0; bytes_total=0
workers=min(8,(os.cpu_count() or 4)*2)
with ThreadPoolExecutor(max_workers=workers) as ex:
    futs=[ex.submit(fetch_one,t) for t in tiles]
    for i,fut in enumerate(as_completed(futs),1):
        t,status,extra=fut.result()
        if status=='failed':
            fail+=1
            print(f'WARN tile {t} failed: {extra}',file=sys.stderr)
        else:
            ok+=1; bytes_total+=int(extra)
        if i%50==0 or i==len(tiles): print(f'  {i}/{len(tiles)} ready; failures={fail}')

manifest={
    'version':'eek-ortho-local-v2','zooms':list(zooms),'tilesTotal':len(tiles),
    'tilesReady':ok,'tilesFailed':fail,'bytes':bytes_total,
    'source':'НСПД / Росреестр · ЕЭКО, ортофото'
}
(root/'fields/basemap/manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
# A few missing edge tiles are tolerable, but a broken source must stop publication.
if ok < max(1,int(len(tiles)*0.90)):
    raise SystemExit(f'Basemap preparation failed: only {ok}/{len(tiles)} tiles downloaded')
print(f'Basemap ready: {ok}/{len(tiles)} tiles, {bytes_total/1024/1024:.1f} MiB')
