window.DONSKOE_FIELDS_BASEMAP={
  version:"eek-ortho-local-v2",
  available:true,
  mode:"xyz",
  zooms:[15,16],
  overviewZoom:15,
  detailZoom:16,
  coverageBufferM:500,
  template:"./basemap/tiles/{z}/{x}/{y}.png",
  cacheName:"donskoe-fields-basemap-local-v2",
  bounds:{minLon:38.58376006216383,minLat:51.44232587275732,maxLon:39.08443645576712,maxLat:51.63252409612505},
  nominalResolutionM:1.5,
  attribution:"НСПД / Росреестр · ЕЭКО, ортофото",
  note:"Ортофотоподложка готовится при публикации приложения и затем работает как локальный слой сайта."
};
