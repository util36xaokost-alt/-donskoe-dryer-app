window.DONSKOE_FIELDS_BASEMAP={
  version:"nspd-ortho-2000-v1",
  available:true,
  mode:"xyz",
  zooms:[15,16],
  overviewZoom:15,
  detailZoom:16,
  coverageBufferM:500,
  template:"https://nspd.gov.ru/api/aeggis/v2/36344/wmts/{z}/{x}/{y}.png",
  cacheName:"donskoe-fields-basemap-nspd-v1",
  bounds:{minLon:38.58376006216383,minLat:51.44232587275732,maxLon:39.08443645576712,maxLat:51.63252409612505},
  nominalResolutionM:1.5,
  attribution:"НСПД / Росреестр · Ортофотопланы 2000",
  note:"Фотоподложка загружается из НСПД. Для гарантированной работы без связи один раз нажмите «Скачать офлайн»."
};
