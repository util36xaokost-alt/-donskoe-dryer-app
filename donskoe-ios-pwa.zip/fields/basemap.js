window.DONSKOE_FIELDS_BASEMAP={
  loaderVersion:"map-package-v1",
  packageId:"donskoe-map",
  packageName:"Карта Донского",
  catalogUrl:"https://util36xaokost-alt.github.io/donskoe-map-assets/manifest.json",
  cachePrefix:"donskoe-map-package-",
  defaultOpacity:0.55,
  detailViewWidthM:9000,
  note:"Фотокарта хранится отдельным пакетом и не входит в релиз приложения. Обновление «Донского» больше не скачивает снимки заново."
};
