(function(){
'use strict';
const C=window.DonskoeCore,U=window.DonskoeUI,D=window.DONSKOE_FIELDS_DATA,$=id=>document.getElementById(id);
if(!D||!Array.isArray(D.fields))throw new Error('База полей не загружена');
document.querySelectorAll('[data-app-version]').forEach(el=>el.textContent=C.VERSION);
$('fieldCount').textContent=D.fields.length;
$('masterHome').onclick=()=>location.href='../index.html?skipSplash=1';
const META_KEY='donskoe_fields_meta_v1',COMBO_KEY='donskoe_fields_combinations_v1';
let meta=C.read(META_KEY,{})||{}, combos=C.read(COMBO_KEY,[])||[];
let route='home',currentFieldId=D.fields[0]?.id||null;
const selectedByContext={map:currentFieldId,measure:currentFieldId,quick:currentFieldId,plan:currentFieldId};
const pages={home:$('page-home'),map:$('page-map'),measure:$('page-measure'),quick:$('page-quick'),plan:$('page-plan')};
const titles={home:'Поля',map:'Карта полей',measure:'Замер поля',quick:'Быстрый план',plan:'Расчёт проходов техники'};
const maps={};
const R=6371008.8, RAD=Math.PI/180, lat0=(D.bounds.south+D.bounds.north)/2, cos0=Math.cos(lat0*RAD);
const X0=D.bounds.west, Y0=D.bounds.north;
function project(lng,lat){return {x:(lng-X0)*RAD*R*cos0,y:(Y0-lat)*RAD*R};}
function unproject(x,y){return {lng:X0+x/(RAD*R*cos0),lat:Y0-y/(RAD*R)};}
function fieldById(id){return D.fields.find(f=>f.id===id)||D.fields[0];}
function polyXY(f){return f.coordinates.map(([lng,lat])=>project(lng,lat));}
function fmt(n,d=1){return Number(n||0).toLocaleString('ru-RU',{maximumFractionDigits:d,minimumFractionDigits:d});}
function esc(s){return String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
function clamp(v,a,b){return Math.max(a,Math.min(b,v));}
function dist(a,b){return Math.hypot(b.x-a.x,b.y-a.y);}
function polygonArea(poly){let s=0;for(let i=0;i<poly.length;i++){const a=poly[i],b=poly[(i+1)%poly.length];s+=a.x*b.y-b.x*a.y;}return Math.abs(s)/2;}
function centroid(poly){let x=0,y=0;for(const p of poly){x+=p.x;y+=p.y;}return {x:x/poly.length,y:y/poly.length};}
function bbox(poly){const xs=poly.map(p=>p.x),ys=poly.map(p=>p.y);return {x:Math.min(...xs),y:Math.min(...ys),w:Math.max(...xs)-Math.min(...xs),h:Math.max(...ys)-Math.min(...ys)};}
function pathD(poly){return poly.map((p,i)=>(i?'L':'M')+p.x.toFixed(2)+' '+p.y.toFixed(2)).join(' ')+' Z';}
function routePath(seg){return `M${seg.a.x.toFixed(2)} ${seg.a.y.toFixed(2)} L${seg.b.x.toFixed(2)} ${seg.b.y.toFixed(2)}`;}
function toast(msg,ms=3000){if(U&&U.toast)U.toast(msg,ms);}
function saveMeta(){C.write(META_KEY,meta);}
function saveCombos(){C.write(COMBO_KEY,combos);}

class FarmMap{
 constructor(el,{interactive=false,onTap=null,onField=null}={}){
  this.el=el;this.interactive=interactive;this.onTap=onTap;this.onField=onField;this.selectedId=null;this.routes=[];this.measure=null;this.pointers=new Map();this.moved=false;this.drag=null;this.pinch=null;
  const all=[];for(const f of D.fields)all.push(...polyXY(f));this.allBox=bbox(all);const m=1200;this.home={x:this.allBox.x-m,y:this.allBox.y-m,w:this.allBox.w+2*m,h:this.allBox.h+2*m};this.view={...this.home};
  this.render();this.bind();
 }
 svg(){return this.el.querySelector('svg');}
 bind(){
  this.el.addEventListener('click',e=>{const p=e.target.closest?.('[data-field-id]');if(p&&!this.moved&&this.onField)this.onField(p.dataset.fieldId);});
  this.el.addEventListener('pointerdown',e=>{const svg=this.svg();if(!svg)return;svg.setPointerCapture?.(e.pointerId);this.pointers.set(e.pointerId,{x:e.clientX,y:e.clientY});this.moved=false;if(this.pointers.size===1)this.drag={x:e.clientX,y:e.clientY,view:{...this.view}};if(this.pointers.size===2){const a=[...this.pointers.values()];this.pinch={d:Math.hypot(a[1].x-a[0].x,a[1].y-a[0].y),view:{...this.view}};} });
  this.el.addEventListener('pointermove',e=>{if(!this.pointers.has(e.pointerId))return;const prev=this.pointers.get(e.pointerId);if(Math.hypot(e.clientX-prev.x,e.clientY-prev.y)>2)this.moved=true;this.pointers.set(e.pointerId,{x:e.clientX,y:e.clientY});const rect=this.el.getBoundingClientRect();if(this.pointers.size===2&&this.pinch){const a=[...this.pointers.values()],d=Math.max(20,Math.hypot(a[1].x-a[0].x,a[1].y-a[0].y)),scale=this.pinch.d/d;const nw=clamp(this.pinch.view.w*scale,300,this.home.w*2),nh=nw*(rect.height/rect.width);const cx=this.pinch.view.x+this.pinch.view.w/2,cy=this.pinch.view.y+this.pinch.view.h/2;this.view={x:cx-nw/2,y:cy-nh/2,w:nw,h:nh};this.updateView();return;}if(this.pointers.size===1&&this.drag){const dx=(e.clientX-this.drag.x)*this.drag.view.w/rect.width,dy=(e.clientY-this.drag.y)*this.drag.view.h/rect.height;this.view={...this.drag.view,x:this.drag.view.x-dx,y:this.drag.view.y-dy};this.updateView();}});
  const end=e=>{const had=this.pointers.has(e.pointerId);const point=this.pointers.get(e.pointerId);this.pointers.delete(e.pointerId);if(this.pointers.size<2)this.pinch=null;if(this.pointers.size===0){if(had&&!this.moved&&this.interactive&&this.onTap&&point){const rect=this.el.getBoundingClientRect(),mx=this.view.x+(point.x-rect.left)/rect.width*this.view.w,my=this.view.y+(point.y-rect.top)/rect.height*this.view.h;this.onTap(unproject(mx,my));}this.drag=null;setTimeout(()=>{this.moved=false;},0);}};
  this.el.addEventListener('pointerup',end);this.el.addEventListener('pointercancel',end);
  this.el.addEventListener('wheel',e=>{e.preventDefault();this.zoom(e.deltaY>0?1.2:.82);},{passive:false});
 }
 updateView(){const s=this.svg();if(s)s.setAttribute('viewBox',`${this.view.x} ${this.view.y} ${this.view.w} ${this.view.h}`);}
 zoom(f){const nw=clamp(this.view.w*f,300,this.home.w*2),nh=this.view.h*(nw/this.view.w),cx=this.view.x+this.view.w/2,cy=this.view.y+this.view.h/2;this.view={x:cx-nw/2,y:cy-nh/2,w:nw,h:nh};this.updateView();}
 fitAll(){this.view={...this.home};this.updateView();}
 fitField(id){const f=fieldById(id);if(!f)return;const b=bbox(polyXY(f)),m=Math.max(350,Math.max(b.w,b.h)*.14);const ratio=this.el.clientHeight/Math.max(1,this.el.clientWidth);let w=b.w+2*m,h=b.h+2*m;if(h/w<ratio)h=w*ratio;else w=h/ratio;this.view={x:b.x+b.w/2-w/2,y:b.y+b.h/2-h/2,w,h};this.updateView();}
 select(id,fit=false){this.selectedId=id;this.render();if(fit)this.fitField(id);}
 setRoutes(routes){this.routes=routes||[];this.render();}
 setMeasure(measure){this.measure=measure;this.render();}
 render(){
  const labels=this.view?.w<26000;
  const fields=D.fields.map(f=>{const poly=polyXY(f),c=centroid(poly);return `<path class="fieldPolygon${f.id===this.selectedId?' selected':''}" data-field-id="${f.id}" d="${pathD(poly)}"></path>${labels?`<text class="fieldLabel" x="${c.x.toFixed(1)}" y="${c.y.toFixed(1)}" text-anchor="middle">${esc(f.name)}</text>`:''}`;}).join('');
  const pois=(D.points||[]).map(p=>{const q=project(p.lng,p.lat);return `<circle class="poiMark" cx="${q.x}" cy="${q.y}" r="8"></circle><text class="poiLabel" x="${q.x+12}" y="${q.y-10}">${esc(p.name)}</text>`;}).join('');
  const routes=this.routes.map((r,i)=>`<path class="routeLine${i%2?' alt':''}" d="${routePath(r)}"></path>`).join('');
  let measure='';if(this.measure?.points?.length){const pts=this.measure.points.map(p=>project(p.lng,p.lat));if(this.measure.tool==='area'&&pts.length>=2)measure+=`<path class="measureArea" d="${pts.map((p,i)=>(i?'L':'M')+p.x+' '+p.y).join(' ')}${pts.length>=3?' Z':''}"></path>`;else if(pts.length>=2)measure+=`<path class="measureLine" d="${pts.map((p,i)=>(i?'L':'M')+p.x+' '+p.y).join(' ')}"></path>`;measure+=pts.map(p=>`<circle class="measurePoint" cx="${p.x}" cy="${p.y}" r="7"></circle>`).join('');}
  const v=this.view||this.home;
  this.el.innerHTML=`<svg viewBox="${v.x} ${v.y} ${v.w} ${v.h}" preserveAspectRatio="xMidYMid meet" role="img"><g>${fields}${pois}${routes}${measure}</g></svg><div class="mapZoom"><button data-z="in" type="button">+</button><button data-z="out" type="button">−</button><button data-z="home" type="button">⌂</button></div>`;
  this.el.querySelector('[data-z="in"]')?.addEventListener('click',e=>{e.stopPropagation();this.zoom(.72);});this.el.querySelector('[data-z="out"]')?.addEventListener('click',e=>{e.stopPropagation();this.zoom(1.35);});this.el.querySelector('[data-z="home"]')?.addEventListener('click',e=>{e.stopPropagation();this.fitAll();});
 }
}

function initPicker(el){
 const ctx=el.dataset.picker;el.innerHTML='<div class="pickerTop"><button class="pickerButton" type="button"></button></div><div class="pickerPanel" hidden></div>';
 const btn=el.querySelector('.pickerButton'),panel=el.querySelector('.pickerPanel');
 function draw(){const id=selectedByContext[ctx],f=fieldById(id);btn.innerHTML=`<span><small>Поле</small>${esc(f?.name||'Выберите поле')}</span><span class="pickerChevron">⌄</span>`;panel.innerHTML=D.fields.map(x=>`<div class="pickerRow"><button class="pickerSelect" data-select="${x.id}" type="button"><b>${esc(x.name)}</b><small>${fmt(x.areaHa,2)} га</small></button><button class="pickerEdit" data-edit="${x.id}" type="button" aria-label="Редактировать карточку ${esc(x.name)}">✎</button></div>`).join('');}
 draw();btn.onclick=()=>{panel.hidden=!panel.hidden;};panel.onclick=e=>{const s=e.target.closest('[data-select]'),ed=e.target.closest('[data-edit]');if(ed){e.stopPropagation();openFieldDialog(ed.dataset.edit);return;}if(s){selectedByContext[ctx]=s.dataset.select;currentFieldId=s.dataset.select;panel.hidden=true;draw();pickerChanged(ctx,s.dataset.select);}};
 document.addEventListener('click',e=>{if(!el.contains(e.target))panel.hidden=true;});el._pickerDraw=draw;
}
document.querySelectorAll('.fieldPicker').forEach(initPicker);
function redrawPickers(){document.querySelectorAll('.fieldPicker').forEach(el=>el._pickerDraw?.());}
function pickerChanged(ctx,id){if(ctx==='map'){maps.map.select(id,true);renderMapInfo(id);}if(ctx==='measure'){maps.measure.select(id,true);clearMeasure();renderMeasure();}if(ctx==='quick'&&maps.quick)maps.quick.select(id,true);if(ctx==='plan'&&maps.plan)maps.plan.select(id,true);}

function showRoute(next,push=true){
 route=next;Object.entries(pages).forEach(([k,v])=>v.classList.toggle('active',k===next));$('subbar').classList.toggle('hidden',next==='home');$('pageTitle').textContent=titles[next]||'Поля';if(push)history.pushState({fieldsRoute:next},'',next==='home'?'./index.html':'#'+next);requestAnimationFrame(()=>ensurePage(next));window.scrollTo({top:0,behavior:'instant'});
}
document.querySelectorAll('[data-route]').forEach(b=>b.onclick=()=>showRoute(b.dataset.route));$('pageBack').onclick=()=>{if(history.state?.fieldsRoute&&route!=='home')history.back();else showRoute('home',false);};
window.addEventListener('popstate',()=>{const h=location.hash.slice(1);showRoute(pages[h]?h:'home',false);});

function ensurePage(name){
 if(name==='map'&&!maps.map){maps.map=new FarmMap($('mapOverview'),{onField:id=>{selectedByContext.map=id;currentFieldId=id;redrawPickers();maps.map.select(id,true);renderMapInfo(id);}});maps.map.select(selectedByContext.map,false);renderMapInfo(selectedByContext.map);}
 if(name==='measure'&&!maps.measure){maps.measure=new FarmMap($('measureMap'),{interactive:true,onTap:p=>addMeasurePoint(p)});maps.measure.select(selectedByContext.measure,true);renderMeasure();}
 if(name==='quick'&&maps.quick)maps.quick.select(selectedByContext.quick,false);
 if(name==='plan'&&maps.plan)maps.plan.select(selectedByContext.plan,false);
}

document.querySelectorAll('[data-fit="all"]').forEach(b=>b.onclick=()=>maps.map?.fitAll());$('mapEdit').onclick=()=>openFieldDialog(selectedByContext.map);
function renderMapInfo(id){const f=fieldById(id),m=meta[id]||{};if(!f)return;$('mapInfo').innerHTML=`<h2>${esc(f.name)}</h2><div class="fieldInfoGrid"><div class="fieldMetric"><span>Площадь по контуру</span><b>${fmt(f.areaHa,2)} га</b></div><div class="fieldMetric"><span>Периметр</span><b>${fmt(f.perimeterKm,2)} км</b></div><div class="fieldMetric"><span>Культура</span><b>${esc(m.crop||'—')}</b></div></div><div class="fieldMetaLines"><div><b>Сезон:</b> ${esc(m.season||'—')}</div><div><b>Севооборот:</b> ${esc(m.rotation||'—')}</div><div><b>Работы:</b> ${esc(m.works||'—')}</div>${m.note?`<div><b>Примечание:</b> ${esc(m.note)}</div>`:''}</div>`;}

function openFieldDialog(id){const f=fieldById(id),m=meta[id]||{};$('fieldEditId').value=id;$('fieldDialogTitle').textContent=f.name;$('fieldCrop').value=m.crop||'';$('fieldSeason').value=m.season||'';$('fieldRotation').value=m.rotation||'';$('fieldWorks').value=m.works||'';$('fieldNote').value=m.note||'';$('fieldDialog').showModal();}
$('fieldSave').onclick=()=>{const id=$('fieldEditId').value;meta[id]={crop:$('fieldCrop').value.trim(),season:$('fieldSeason').value.trim(),rotation:$('fieldRotation').value.trim(),works:$('fieldWorks').value.trim(),note:$('fieldNote').value.trim(),updatedAt:new Date().toISOString()};saveMeta();$('fieldDialog').close();renderMapInfo(selectedByContext.map);toast('Карточка поля сохранена');};

const measure={tool:'distance',points:[]};
function addMeasurePoint(p){measure.points.push(p);renderMeasure();}
function clearMeasure(){measure.points=[];renderMeasure();}
function renderMeasure(){maps.measure?.setMeasure({tool:measure.tool,points:measure.points});$('measureUndo').disabled=!measure.points.length;document.querySelectorAll('[data-measure-tool]').forEach(b=>b.classList.toggle('active',b.dataset.measureTool===measure.tool));const f=fieldById(selectedByContext.measure);if(!measure.points.length){$('measureResult').innerHTML=`<div class="emptyState">${esc(f.name)} · ${fmt(f.areaHa,2)} га. Поставьте точки на карте.</div>`;return;}const pts=measure.points.map(p=>project(p.lng,p.lat));if(measure.tool==='distance'){let total=0;for(let i=1;i<pts.length;i++)total+=dist(pts[i-1],pts[i]);$('measureResult').innerHTML=`<div class="measureNumbers"><div class="measureBig"><span>Точек</span><b>${pts.length}</b></div><div class="measureBig"><span>Общее расстояние</span><b>${total>=1000?fmt(total/1000,2)+' км':fmt(total,0)+' м'}</b></div></div>`;}else{const area=pts.length>=3?polygonArea(pts)/10000:0;$('measureResult').innerHTML=`<div class="measureNumbers"><div class="measureBig"><span>Точек</span><b>${pts.length}</b></div><div class="measureBig"><span>Площадь</span><b>${pts.length>=3?fmt(area,2)+' га':'—'}</b></div></div>${pts.length>=3?`<div class="variantNote">${fmt(area/f.areaHa*100,1)}% площади выбранного поля.</div>`:''}`;}}
document.querySelectorAll('[data-measure-tool]').forEach(b=>b.onclick=()=>{measure.tool=b.dataset.measureTool;clearMeasure();});$('measureUndo').onclick=()=>{if(measure.points.length){measure.points.pop();renderMeasure();}};$('measureClear').onclick=clearMeasure;

function longestAngle(poly){let best=0,ang=0;for(let i=0;i<poly.length;i++){const a=poly[i],b=poly[(i+1)%poly.length],l=dist(a,b);if(l>best){best=l;ang=Math.atan2(b.y-a.y,b.x-a.x)*180/Math.PI;}}ang=((ang%180)+180)%180;return ang;}
function lineIntersections(poly,t,dv,nv){const values=[];for(let i=0;i<poly.length;i++){const a=poly[i],b=poly[(i+1)%poly.length],va=a.x*nv.x+a.y*nv.y-t,vb=b.x*nv.x+b.y*nv.y-t;if(Math.abs(va)<1e-7)values.push(a.x*dv.x+a.y*dv.y);if((va<0&&vb>0)||(va>0&&vb<0)){const u=va/(va-vb),x=a.x+(b.x-a.x)*u,y=a.y+(b.y-a.y)*u;values.push(x*dv.x+y*dv.y);}}
 values.sort((a,b)=>a-b);const out=[];for(const v of values)if(!out.length||Math.abs(v-out[out.length-1])>.25)out.push(v);return out;}
function buildPasses(poly,width,angle){width=Math.max(1,Number(width)||1);const a=angle*Math.PI/180,dv={x:Math.cos(a),y:Math.sin(a)},nv={x:-Math.sin(a),y:Math.cos(a)},ns=poly.map(p=>p.x*nv.x+p.y*nv.y),min=Math.min(...ns),max=Math.max(...ns),segments=[];let row=0;for(let t=min+width/2;t<=max+width/2;t+=width){const xs=lineIntersections(poly,t,dv,nv);for(let i=0;i+1<xs.length;i+=2){let s1=xs[i],s2=xs[i+1];if(s2-s1<1)continue;let p1={x:dv.x*s1+nv.x*t,y:dv.y*s1+nv.y*t},p2={x:dv.x*s2+nv.x*t,y:dv.y*s2+nv.y*t};if(row%2){const z=p1;p1=p2;p2=z;}segments.push({a:p1,b:p2,row});}row++;}let total=0;for(const s of segments)total+=dist(s.a,s.b);return {angle,segments,totalLength:total,passes:segments.length};}
function variantsFor(field,width){const poly=polyXY(field),base=longestAngle(poly),raw=[{label:'Вдоль длинной стороны',angle:base},{label:'Поперёк',angle:(base+90)%180},{label:'Смещение +15°',angle:(base+15)%180},{label:'Смещение −15°',angle:(base+165)%180}],seen=new Set(),out=[];for(const v of raw){const key=Math.round(v.angle*10);if(seen.has(key))continue;seen.add(key);const r=buildPasses(poly,width,v.angle);out.push({...v,...r});}return out;}
function variantStats(field,v,width,rate,capacity,unit){const totalResource=field.areaHa*rate,loads=capacity>0&&totalResource>0?Math.ceil(totalResource/capacity):0,perLoadHa=rate>0&&capacity>0?capacity/rate:0,perLoadKm=perLoadHa>0?perLoadHa*10000/width/1000:0;return {totalResource,loads,perLoadHa,perLoadKm,workingKm:v.totalLength/1000,coverageHa:v.totalLength*width/10000,unit};}
function renderVariantSet(kind,variants,index,field,width,rate,capacity,unit){const tabs=$(kind+'Tabs'),mapId=kind+'Map',stats=$(kind+'Stats');tabs.innerHTML=variants.map((v,i)=>`<button class="variantBtn${i===index?' active':''}" data-i="${i}" type="button">Вариант ${i+1}</button>`).join('');if(!maps[kind])maps[kind]=new FarmMap($(mapId));maps[kind].selectedId=field.id;maps[kind].setRoutes(variants[index].segments);maps[kind].fitField(field.id);const v=variants[index],s=variantStats(field,v,width,rate,capacity,unit);const finalLoad=s.loads?Math.max(0,s.totalResource-capacity*(s.loads-1)):0;stats.innerHTML=`<h2>${esc(v.label)}</h2><div class="statsGrid"><div class="statBox"><span>Проходов</span><b>${v.passes}</b></div><div class="statBox"><span>Рабочий путь</span><b>${fmt(s.workingKm,2)} км</b></div><div class="statBox"><span>Нужно ресурса</span><b>${fmt(s.totalResource,0)} ${esc(unit)}</b></div><div class="statBox"><span>Полных циклов загрузки</span><b>${s.loads||'—'}</b></div><div class="statBox"><span>На одной загрузке</span><b>${s.perLoadHa?fmt(s.perLoadHa,2)+' га':'—'}</b></div><div class="statBox"><span>Рабочий путь на загрузке</span><b>${s.perLoadKm?fmt(s.perLoadKm,2)+' км':'—'}</b></div></div>${s.loads?`<div class="variantNote">Последняя расчётная загрузка: ${fmt(finalLoad,0)} ${esc(unit)}. Ширина ${fmt(width,1)} м применяется только к этому расчёту и может быть изменена.</div>`:''}`;tabs.querySelectorAll('[data-i]').forEach(b=>b.onclick=()=>renderVariantSet(kind,variants,Number(b.dataset.i),field,width,rate,capacity,unit));}
$('quickCalc').onclick=()=>{const f=fieldById(selectedByContext.quick),width=Number($('quickWidth').value),rate=Number($('quickRate').value),capacity=Number($('quickCapacity').value),unit=$('quickUnit').value;if(!(width>0))return toast('Укажите рабочую ширину');const vars=variantsFor(f,width);$('quickResult').classList.remove('hidden');renderVariantSet('quick',vars,0,f,width,rate,capacity,unit);};

function renderComboList(){if(!combos.length){$('comboList').innerHTML='<div class="emptyState">Сохранённых комбинаций пока нет.</div>';return;}$('comboList').innerHTML=combos.map(c=>`<div class="comboRow"><div><b>${esc(c.name)}</b><small>${fmt(c.defaultWidth,1)} м · загрузка ${fmt(c.defaultCapacity,0)}</small></div><button data-combo-edit="${c.id}" type="button">Изм.</button><button data-combo-del="${c.id}" type="button">×</button></div>`).join('');$('comboList').querySelectorAll('[data-combo-edit]').forEach(b=>b.onclick=()=>loadComboEditor(b.dataset.comboEdit));$('comboList').querySelectorAll('[data-combo-del]').forEach(b=>b.onclick=()=>{combos=combos.filter(c=>c.id!==b.dataset.comboDel);saveCombos();renderComboList();renderPlanUnits();});}
function resetComboEditor(){$('comboEditId').value='';$('comboName').value='';$('comboWidth').value='24';$('comboCapacity').value='2000';}
function loadComboEditor(id){const c=combos.find(x=>x.id===id);if(!c)return;$('comboEditId').value=c.id;$('comboName').value=c.name;$('comboWidth').value=c.defaultWidth;$('comboCapacity').value=c.defaultCapacity;}
$('comboOpen').onclick=()=>{renderComboList();resetComboEditor();$('comboDialog').showModal();};$('comboClose').onclick=()=>$('comboDialog').close();$('comboReset').onclick=resetComboEditor;$('comboSave').onclick=()=>{const id=$('comboEditId').value||('combo-'+Date.now().toString(36)),name=$('comboName').value.trim(),w=Number($('comboWidth').value),cap=Number($('comboCapacity').value);if(!name)return toast('Введите название комбинации');const row={id,name,defaultWidth:w>0?w:1,defaultCapacity:cap>=0?cap:0,updatedAt:new Date().toISOString()};const i=combos.findIndex(c=>c.id===id);if(i>=0)combos[i]=row;else combos.push(row);saveCombos();renderComboList();renderPlanUnits();resetComboEditor();toast('Комбинация сохранена');};
let planUnits=[];
function addPlanUnit(){if(!combos.length){$('comboDialog').showModal();renderComboList();resetComboEditor();toast('Сначала сохраните комбинацию техники');return;}const c=combos[0];planUnits.push({id:'unit-'+Date.now().toString(36)+Math.random().toString(16).slice(2,5),comboId:c.id,width:c.defaultWidth,rate:0,capacity:c.defaultCapacity});renderPlanUnits();}
function renderPlanUnits(){if(!planUnits.length){$('planUnits').innerHTML='<div class="emptyState">Добавьте одну или несколько рабочих единиц.</div>';return;}$('planUnits').innerHTML=planUnits.map(u=>`<div class="planUnit" data-unit="${u.id}"><label><span>Комбинация</span><select data-k="comboId">${combos.map(c=>`<option value="${c.id}"${c.id===u.comboId?' selected':''}>${esc(c.name)}</option>`).join('')}</select></label><label><span>Ширина, м</span><input data-k="width" type="number" inputmode="decimal" min="1" step="0.5" value="${u.width}"></label><label><span>Норма / га</span><input data-k="rate" type="number" inputmode="decimal" min="0" step="0.1" value="${u.rate}"></label><label><span>Полная загрузка</span><input data-k="capacity" type="number" inputmode="decimal" min="0" step="1" value="${u.capacity}"></label><button class="planUnitRemove" type="button" data-remove="${u.id}">×</button></div>`).join('');$('planUnits').querySelectorAll('[data-unit]').forEach(row=>{const u=planUnits.find(x=>x.id===row.dataset.unit);row.querySelectorAll('[data-k]').forEach(inp=>inp.onchange=()=>{const k=inp.dataset.k;if(k==='comboId'){u.comboId=inp.value;const c=combos.find(x=>x.id===u.comboId);u.width=c.defaultWidth;u.capacity=c.defaultCapacity;renderPlanUnits();}else u[k]=Number(inp.value);});});$('planUnits').querySelectorAll('[data-remove]').forEach(b=>b.onclick=()=>{planUnits=planUnits.filter(u=>u.id!==b.dataset.remove);renderPlanUnits();});}
$('planAddUnit').onclick=addPlanUnit;renderPlanUnits();
$('planCalc').onclick=()=>{if(!planUnits.length)return toast('Добавьте рабочую единицу');const lead=planUnits[0],f=fieldById(selectedByContext.plan);if(!(lead.width>0))return toast('Укажите рабочую ширину');const vars=variantsFor(f,lead.width);$('planResult').classList.remove('hidden');renderVariantSet('plan',vars,0,f,lead.width,lead.rate,lead.capacity,$('planWork').value==='Опрыскивание'?'л':'кг');if(planUnits.length>1)toast('Сейчас схема показана по ведущей единице. Групповое деление подключим следующим этапом.',5200);};

// Seed no machinery facts: the micro-base is explicitly user-controlled.
if(location.hash&&pages[location.hash.slice(1)])showRoute(location.hash.slice(1),false);else history.replaceState({fieldsRoute:'home'},'',location.pathname);
})();
