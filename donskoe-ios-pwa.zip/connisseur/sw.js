
// Immutable shell cache for one release. User journals and photos live separately.
const CACHE="donskoe-connisseur-7.4.6-20260913-fields-measure-fixes", PREFIX="donskoe-connisseur-", CORE=["./index.html", "./manifest.webmanifest", "./logo.png", "./icon-192.png", "./icon-512.png", "../shared/release.js", "../shared/core.js", "../shared/theme.css", "../shared/ui.js", "./app.js", "./styles.css", "./connisseur-logo.png"], OPTIONAL=[];
const OFFLINE='<!doctype html><html lang="ru"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><style>body{font:16px/1.6 system-ui;background:#f1f3f2;color:#182f2c;padding:30px}main{max-width:480px;margin:40px auto}a{color:#126a51}</style><main><h1>Донское</h1><p>Не удалось открыть страницу из локального кэша.</p><p>Вернитесь на главный экран и нажмите Refresh при наличии интернета.</p><a href="../index.html">На главный экран</a></main></html>';
self.addEventListener('install',event=>event.waitUntil((async()=>{
 const cache=await caches.open(CACHE);
 try{await cache.addAll(CORE);}catch(e){await caches.delete(CACHE);throw e;}
 await Promise.allSettled(OPTIONAL.map(group=>cache.addAll(group)));
 // Existing workers continue until windows close or the operator accepts the update.
})()));
self.addEventListener('message',event=>{if(event.data?.type==='ACTIVATE_UPDATE')self.skipWaiting();});
self.addEventListener('activate',event=>event.waitUntil((async()=>{
 const names=await caches.keys();
 await Promise.all(names.filter(n=>n.startsWith(PREFIX)&&n!==CACHE).map(n=>caches.delete(n)));
 await self.clients.claim();
})()));
self.addEventListener('fetch',event=>{
 if(event.request.method!=='GET')return;
 const url=new URL(event.request.url),scope=new URL(self.registration.scope);
 if(url.origin!==scope.origin)return;
 // Never cache authenticated API calls or arbitrary same-origin responses.
 const pathname=url.pathname;
 let key;
 if(event.request.mode==='navigate'){
  let relative=pathname.startsWith(scope.pathname)?pathname.slice(scope.pathname.length):'';
  if(!relative||relative==='index.html')relative='index.html';
  else if(false){const mod=relative.split('/')[0];if(['dryer','chem','connisseur','fields'].includes(mod))relative=mod+'/index.html';}
  key=new URL(relative,scope).href;
 }else{
  const clean=new URL(url);clean.search='';clean.hash='';key=clean.href;
 }
 const known=[...CORE,...OPTIONAL.flat()].some(p=>new URL(p,scope).href===key);
 if(!known)return;
 event.respondWith((async()=>{
  const cache=await caches.open(CACHE),cached=await cache.match(key);
  if(cached)return cached;
  try{
   const ctrl=new AbortController(),timer=setTimeout(()=>ctrl.abort(),10000);
   try{const response=await fetch(event.request,{signal:ctrl.signal,cache:'no-store'});if(!response.ok)throw new Error('HTTP '+response.status);return response;}finally{clearTimeout(timer);}
  }catch(e){return event.request.mode==='navigate'?new Response(OFFLINE,{status:503,headers:{'Content-Type':'text/html;charset=utf-8'}}):new Response('',{status:504});}
 })());
});
