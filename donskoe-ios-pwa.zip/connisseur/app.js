(function(){
'use strict';
const $=id=>document.getElementById(id);
const qsa=s=>Array.from(document.querySelectorAll(s));
const STATE_KEY='donskoe_connisseur_state_v1';
const PENDING_KEY='donskoe_connisseur_cloud_pending_v1';
const CLOUD_CONFIG_KEY='donskoe_dryer_cloud_config_v1';
const SHARED_SESSION_KEY='donskoe_cloud_session_shared_v1';
const DRYER_SESSION_KEY='donskoe_dryer_cloud_session_v1';
const CHEM_SESSION_KEY='donskoe_chem_cloud_session_v1';
const DEFAULT_CLOUD={url:'https://vschnaxezsceogewlmin.supabase.co',key:'sb_publishable_1SSHvNqBFudiE71JpzcyGQ_ZP-bNV9c'};
const TABLES={batches:'connisseur_batches',calibrations:'connisseur_calibrations',runs:'connisseur_runs',bags:'connisseur_bag_cycles'};
let routeStack=['home'];
let draftComponents=[{name:'',qty:'',unit:'л'}];
let pendingCalResult=null;
let historyTab='batches';
let cloudBusy=false;
let cloudText='Локальная история.';
let sm4ManualEdit=false;

function readJSON(key,fallback){try{const v=JSON.parse(localStorage.getItem(key)||'null');return v===null?fallback:v;}catch(e){return fallback;}}
function writeJSON(key,val){try{localStorage.setItem(key,JSON.stringify(val));}catch(e){}}
function uuid(){return (crypto&&crypto.randomUUID)?crypto.randomUUID():'c-'+Date.now().toString(36)+'-'+Math.random().toString(36).slice(2,10);}
function iso(){return new Date().toISOString();}
function fmt(v,d=1){if(v===null||v===undefined||!isFinite(Number(v)))return '—';return Number(v).toFixed(d).replace('.',',');}
function fmtInt(v){if(v===null||v===undefined||!isFinite(Number(v)))return '—';return new Intl.NumberFormat('ru-RU',{maximumFractionDigits:0}).format(Math.round(Number(v)));}
function fmtG(g){return fmtInt(g)+' г';}
function fmtMl(ml){return ml>=1000?fmt(ml/1000,3)+' л':fmt(ml,0)+' мл';}
function modeOf(x){return x&&x.measurementMode==='volume'?'volume':'mass';}
function flowUnit(mode){return mode==='volume'?'мл/мин':'г/мин';}
function measureUnit(mode){return mode==='volume'?'мл':'г';}
function flowValue(x){return modeOf(x)==='volume'?Number(x.actualFlowMlMin):Number(x.actualFlowGMin);}
function requiredFlow(x){return modeOf(x)==='volume'?Number(x.requiredFlowMlMin):Number(x.requiredFlowGMin);}
function calibratedFlow(x){return modeOf(x)==='volume'?Number(x.calibratedFlowMlMin):Number(x.calibratedFlowGMin);}
function primaryTotal(b){return modeOf(b)==='volume'?Number(b.totalVolumeMl):Number(b.totalMassG);}
function primaryDose(b){return modeOf(b)==='volume'?Number(b.doseMlPerT):Number(b.doseGPerT);}
function totalLabel(b){return modeOf(b)==='volume'?fmt(Number(b.totalVolumeMl)/1000,3)+' л':fmtG(b.totalMassG);}
function doseLabel(b){return modeOf(b)==='volume'?fmt(Number(b.doseMlPerT)/1000,3)+' л/т':fmtInt(b.doseGPerT)+' г/т';}
function amountLabel(mode,v){return mode==='volume'?fmtMl(v):fmtG(v);}
function nullableNum(v){return v===null||v===undefined||v===''?null:Number(v);}
function clamp(v,a,b){return Math.max(a,Math.min(b,v));}
function esc(v){return String(v??'').replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));}
function duration(min){if(!isFinite(min))return '—';const m=Math.max(0,Math.round(min));return Math.floor(m/60)+' ч '+String(m%60).padStart(2,'0')+' мин';}
function normalize(s){return String(s||'').trim().toLowerCase().replace(/ё/g,'е').replace(/\s+/g,' ');}
function hashString(s){let h=2166136261;for(let i=0;i<s.length;i++){h^=s.charCodeAt(i);h=Math.imul(h,16777619);}return (h>>>0).toString(16).padStart(8,'0');}
function recipeKey(batchLike){
  const t=Number(batchLike.seedTonnage||batchLike.seed_tonnage||1)||1;
  const comps=(batchLike.components||[]).filter(x=>x&&normalize(x.name)).map(x=>({n:normalize(x.name),u:normalize(x.unit),p:(Number(x.qty)||0)/t})).sort((a,b)=>(a.n+a.u).localeCompare(b.n+b.u));
  const mode=modeOf(batchLike);
  if(mode==='mass'){
    const dose=Number(batchLike.doseGPerT||batchLike.dose_g_per_t||0)||0;
    const raw=[normalize(batchLike.recipeName||batchLike.recipe_name),normalize(batchLike.crop),Math.round(dose),...comps.map(x=>x.n+':'+x.u+':'+x.p.toFixed(5))].join('|');
    return 'r-'+hashString(raw);
  }
  const doseMl=Number(batchLike.doseMlPerT||batchLike.dose_ml_per_t||0)||0;
  const raw=['volume',normalize(batchLike.recipeName||batchLike.recipe_name),normalize(batchLike.crop),Math.round(doseMl),...comps.map(x=>x.n+':'+x.u+':'+x.p.toFixed(5))].join('|');
  return 'rv-'+hashString(raw);
}
function initialState(){return{batches:[],calibrations:[],runs:[],bags:[],activeBatchId:null,activeRunId:null,activeBagId:null,activeCal:null,settings:{sm4Points:[{hz:29,minPerT:37},{hz:30,minPerT:36},{hz:31,minPerT:35},{hz:32,minPerT:34}]}};}
let state=Object.assign(initialState(),readJSON(STATE_KEY,{}));
state.batches=Array.isArray(state.batches)?state.batches:[];
state.calibrations=Array.isArray(state.calibrations)?state.calibrations:[];
state.runs=Array.isArray(state.runs)?state.runs:[];
state.bags=Array.isArray(state.bags)?state.bags:[];
state.batches.forEach(b=>{if(!b.measurementMode)b.measurementMode='mass';if(b.measurementMode==='volume'&&!b.doseMlPerT&&b.totalVolumeMl&&b.seedTonnage)b.doseMlPerT=Number(b.totalVolumeMl)/Number(b.seedTonnage);});
state.calibrations.forEach(c=>{if(!c.measurementMode)c.measurementMode='mass';});
state.runs.forEach(r=>{if(!r.measurementMode)r.measurementMode='mass';});
state.bags.forEach(b=>{if(!b.learningStatus)b.learningStatus=b.actualNetKg>0?'accepted':'pending_weight';if(!b.status)b.status=b.endedAt?'completed':'running';});
if(state.activeCal&&!state.activeCal.measurementMode){state.activeCal.measurementMode='mass';if(state.activeCal.massBeforeG===undefined&&state.activeCal.massBeforeKg!==undefined)state.activeCal.massBeforeG=Number(state.activeCal.massBeforeKg)*1000;if(state.activeCal.requiredFlow===undefined&&state.activeCal.requiredFlowGMin!==undefined)state.activeCal.requiredFlow=Number(state.activeCal.requiredFlowGMin);}
state.settings=state.settings||initialState().settings;
function saveState(){writeJSON(STATE_KEY,state);}
function touch(o){o.updatedAt=iso();return o;}
function activeBatch(){return state.batches.find(x=>x.clientId===state.activeBatchId&&!x.deletedAt)||null;}
function latestBatch(){return state.batches.filter(x=>!x.deletedAt).sort((a,b)=>String(b.createdAt).localeCompare(String(a.createdAt)))[0]||null;}
function ensureActiveBatch(){if(!activeBatch()){const b=latestBatch();state.activeBatchId=b?b.clientId:null;saveState();}return activeBatch();}
function acceptedForBatch(batch){if(!batch)return null;const mode=modeOf(batch);return state.calibrations.filter(c=>!c.deletedAt&&c.accepted&&c.batchClientId===batch.clientId&&modeOf(c)===mode&&c.recipeKey===batch.recipeKey).sort((a,b)=>String(b.occurredAt).localeCompare(String(a.occurredAt)))[0]||null;}
function currentRun(){return state.runs.find(r=>r.clientId===state.activeRunId&&r.status==='running'&&!r.deletedAt)||null;}
function currentBag(){return state.bags.find(b=>b.clientId===state.activeBagId&&b.status==='running'&&!b.deletedAt)||null;}
function bagsForRun(runId){return state.bags.filter(b=>!b.deletedAt&&b.runClientId===runId).sort((a,b)=>Number(a.bagNo)-Number(b.bagNo));}
function acceptedSm4Bags(crop){return state.bags.filter(b=>!b.deletedAt&&b.status==='completed'&&b.learningStatus==='accepted'&&Number(b.actualNetKg)>0&&Number(b.activeDurationSec)>0&&String(b.crop||'Соя')===String(crop||'Соя'));}


function setNetwork(){const online=navigator.onLine!==false,p=$('networkPill');p.classList.toggle('online',online);p.classList.toggle('offline',!online);$('networkText').textContent=online?'Online':'Offline';}
window.addEventListener('online',()=>{setNetwork();cloudSync(true);});window.addEventListener('offline',setNetwork);setNetwork();
$('masterHome').addEventListener('click',()=>location.href='../index.html?skipSplash=1');

const titles={home:'ConNiSseur',mix:'Приготовить смесь',cal:'Калибровка',work:'Работа',history:'История'};
function showPage(name,push=true){
  if(!titles[name])name='home';
  qsa('.page').forEach(p=>p.classList.toggle('active',p.id==='page-'+name));
  $('subbar').classList.toggle('hidden',name==='home');$('pageTitle').textContent=titles[name];
  if(push&&routeStack[routeStack.length-1]!==name)routeStack.push(name);
  if(name==='mix')renderMix();if(name==='cal')renderCalibration();if(name==='work')renderWork();if(name==='history')renderHistory();
  window.scrollTo({top:0,behavior:'auto'});
}
function goBack(){if(routeStack.length>1){routeStack.pop();showPage(routeStack[routeStack.length-1],false);}else location.href='../index.html?skipSplash=1';}
$('backBtn').addEventListener('click',goBack);
qsa('[data-route]').forEach(b=>b.addEventListener('click',()=>showPage(b.dataset.route)));
let sx=0,sy=0,tracking=false;document.addEventListener('touchstart',e=>{const t=e.touches[0];if(t.clientX<28){sx=t.clientX;sy=t.clientY;tracking=true;}},{passive:true});document.addEventListener('touchend',e=>{if(!tracking)return;tracking=false;const t=e.changedTouches[0];if(t.clientX-sx>75&&Math.abs(t.clientY-sy)<70)goBack();},{passive:true});

function metric(label,value,sub=''){return `<div class="metric"><span>${esc(label)}</span><b>${esc(value)}</b>${sub?`<small>${esc(sub)}</small>`:''}</div>`;}

let mixMode='mass';
function setMixMode(mode){
  mixMode=mode==='volume'?'volume':'mass';
  $('modeMass').classList.toggle('active',mixMode==='mass');$('modeVolume').classList.toggle('active',mixMode==='volume');
  $('mixMassLabel').textContent=mixMode==='mass'?'Фактическая масса смеси, г — основной параметр':'Фактическая масса смеси, г — если известна';
  $('mixVolumeLabel').textContent=mixMode==='volume'?'Общий объём, л — основной параметр':'Общий объём, л — справочно';
  $('mixModeHint').className='hint '+(mixMode==='mass'?'good':'warn');
  $('mixModeHint').textContent=mixMode==='mass'?'Точный режим: расчёт по массе, все показания весов вводятся в граммах.':'Резервный режим: расчёт по объёму. Калибровка — по мерному стакану в мл; рабочие остатки — в литрах.';
  renderMixResult();
}
$('modeMass').onclick=()=>setMixMode('mass');$('modeVolume').onclick=()=>setMixMode('volume');
function renderComponents(){
  const host=$('componentsList');host.innerHTML='';
  if(!draftComponents.length)draftComponents=[{name:'',qty:'',unit:'л'}];
  draftComponents.forEach((c,i)=>{
    const row=document.createElement('div');row.className='componentRow';
    row.innerHTML=`<input data-cname="${i}" type="text" placeholder="Препарат / компонент" value="${esc(c.name)}"><input data-cqty="${i}" type="number" inputmode="decimal" step="0.001" min="0" placeholder="Кол-во" value="${esc(c.qty)}"><select data-cunit="${i}"><option>л</option><option>мл</option><option>кг</option><option>г</option></select><button data-cremove="${i}" class="removeComp" type="button">×</button>`;
    host.appendChild(row);row.querySelector('[data-cunit]').value=c.unit||'л';
  });
  host.querySelectorAll('[data-cname]').forEach(x=>x.oninput=()=>{draftComponents[+x.dataset.cname].name=x.value;renderMixResult();});
  host.querySelectorAll('[data-cqty]').forEach(x=>x.oninput=()=>{draftComponents[+x.dataset.cqty].qty=x.value;renderMixResult();});
  host.querySelectorAll('[data-cunit]').forEach(x=>x.onchange=()=>{draftComponents[+x.dataset.cunit].unit=x.value;renderMixResult();});
  host.querySelectorAll('[data-cremove]').forEach(x=>x.onclick=()=>{draftComponents.splice(+x.dataset.cremove,1);renderComponents();renderMixResult();});
}
$('addComponent').onclick=()=>{draftComponents.push({name:'',qty:'',unit:'л'});renderComponents();};
['mixTonnage','mixMassG','mixVolumeL','mixName','mixCrop'].forEach(id=>$(id).addEventListener('input',renderMixResult));
function renderMix(){renderComponents();setMixMode(mixMode);renderMixResult();}
function renderMixResult(){
  const t=Number($('mixTonnage').value),massG=Number($('mixMassG').value),volL=Number($('mixVolumeL').value),box=$('mixResult');
  const primary=mixMode==='volume'?volL*1000:massG;
  if(!(t>0&&primary>0)){box.classList.add('hidden');return;}
  const totalMin30=t*(66-30),flow30=primary/totalMin30;
  const dose=mixMode==='volume'?primary/t:massG/t;
  box.className='resultCard';box.innerHTML=`<div class="resultTitle">Расчёт ${mixMode==='volume'?'по объёму':'по массе'}</div><div class="resultBig">${mixMode==='volume'?fmt(dose/1000,3)+' л/т':fmtInt(dose)+' г/т'}</div><div class="metrics">${metric(mixMode==='volume'?'Объём смеси':'Масса смеси',mixMode==='volume'?fmt(volL,3)+' л':fmtG(massG))}${metric('Тоннаж',fmt(t,2)+' т')}${metric('При СМ-4 30 Гц',fmt(flow30,0)+' '+flowUnit(mixMode),'ориентир до калибровки')}${metric('Время партии при 30 Гц',duration(totalMin30))}</div>`;
}
$('saveBatch').onclick=()=>{
  const crop=$('mixCrop').value,t=Number($('mixTonnage').value),massG=Number($('mixMassG').value)||null,volL=Number($('mixVolumeL').value)||null;
  if(!(t>0))return alert('Укажите тоннаж семян.');
  if(mixMode==='mass'&&!(massG>0))return alert('Укажите фактическую массу готовой смеси в граммах.');
  if(mixMode==='volume'&&!(volL>0))return alert('Укажите фактический объём готовой смеси в литрах.');
  const components=draftComponents.filter(c=>normalize(c.name)&&Number(c.qty)>0).map(c=>({name:String(c.name).trim(),qty:Number(c.qty),unit:c.unit||'л'}));
  const recipeName=String($('mixName').value||'').trim()||(crop+' — рабочий состав');
  const b={clientId:uuid(),crop,recipeName,measurementMode:mixMode,seedTonnage:t,totalMassG:massG,totalVolumeMl:volL?volL*1000:null,doseGPerT:massG?massG/t:null,doseMlPerT:volL?volL*1000/t:null,components,status:'prepared',notes:String($('mixNote').value||'').trim(),createdAt:iso(),updatedAt:iso()};b.recipeKey=recipeKey(b);
  state.batches.push(b);state.activeBatchId=b.clientId;$('pumpHz').value='';$('calBeforeMeasure').value='';$('calAfterMeasure').value='';saveState();queueRecord('batches',b);cloudSync(true);
  $('mixMassG').value='';$('mixVolumeL').value='';$('mixNote').value='';draftComponents=[{name:'',qty:'',unit:'л'}];renderComponents();renderMixResult();showPage('cal');
};

function sm4Minutes(hz){return 66-Number(hz);}
function sm4Prediction(hz,crop='Соя'){
  hz=Number(hz);const baseline=sm4Minutes(hz),inBase=hz>=29&&hz<=32;
  const all=acceptedSm4Bags(crop).filter(b=>Number(b.actualMinPerT)>0&&Number(b.sm4Hz)>0&&Number(b.actualMinPerT)>=15&&Number(b.actualMinPerT)<=70);
  const nearby=all.map(b=>({b,d:Math.abs(Number(b.sm4Hz)-hz),m:Number(b.actualMinPerT)})).filter(x=>x.d<=1.25);
  const exact=nearby.filter(x=>x.d<=0.15);
  let sw=0,sm=0;
  if(isFinite(baseline)&&baseline>0){const bw=inBase?0.7:0.18;sw+=bw;sm+=baseline*bw;}
  nearby.forEach(x=>{const w=2.5/(0.18+x.d*x.d);sw+=w;sm+=x.m*w;});
  let minPerT=sw>0?sm/sw:baseline;
  if(!(minPerT>0))minPerT=36;
  let confidence='Низкая',cls='bad';
  if(exact.length>=3){
    const vals=exact.map(x=>x.m),avgv=vals.reduce((a,b)=>a+b,0)/vals.length;
    const spread=Math.max(...vals)-Math.min(...vals);
    if(spread/avgv<=.05){confidence='Высокая';cls='good';}
    else{confidence='Средняя';cls='warn';}
  }else if(exact.length>=1||nearby.length>=2){confidence='Средняя';cls='warn';}
  else if(inBase){confidence='Стартовая';cls='warn';}
  const source=nearby.length?`${nearby.length} взвешиван${nearby.length===1?'ие':nearby.length<5?'ия':'ий'} биг-бэга + базовая кривая 2026`:(inBase?'базовая кривая 2026':'экстраполяция базовой кривой');
  let text;
  if(nearby.length)text=`Прогноз СМ‑4: ${fmt(minPerT,2)} мин/т (${fmt(1000/minPerT,2)} кг/мин). В модели ${source}.`;
  else if(inBase)text=`Стартовая опора: ${fmt(hz,1)} Гц → ${fmt(baseline,1)} мин/т. Это подтверждённая ручная калибровка 2026, но реальных взвешиваний биг-бэгов при этой частоте ещё нет.`;
  else text=`Частота ${fmt(hz,1)} Гц вне исходного диапазона 29–32 Гц. Расчёт ${fmt(minPerT,2)} мин/т является слабой экстраполяцией до появления фактических взвешиваний.`;
  return{hz,minPerT,kgMin:1000/minPerT,confidence,cls,realPoints:nearby.length,exactPoints:exact.length,source,text};
}
function sm4LearningCurve(crop='Соя'){
  return [29,30,31,32].map(h=>({hz:h,...sm4Prediction(h,crop)}));
}

function renderCalibration(){
  const b=ensureActiveBatch();$('calNoBatch').classList.toggle('hidden',!!b);$('calBody').classList.toggle('hidden',!b);if(!b)return;
  const mode=modeOf(b);$('calBatchName').textContent=`${b.recipeName} · ${fmt(b.seedTonnage,2)} т`;
  $('calBatchMetrics').innerHTML=metric(mode==='volume'?'Объём смеси':'Масса смеси',totalLabel(b))+metric('Доза',doseLabel(b))+metric('Режим',mode==='volume'?'по объёму':'по массе')+metric('Статус',statusRu(b.status));
  $('calModeMass').classList.toggle('active',mode==='mass');$('calModeVolume').classList.toggle('active',mode==='volume');
  $('calModeSwitchHint').className='hint '+(mode==='volume'?'warn':'good');$('calModeSwitchHint').textContent=mode==='volume'?'Резервный объёмный режим. Массовые калибровки не смешиваются с объёмными.':'Основной массовый режим. Если весы отказали, можно переключить эту же партию на объём и заново откалибровать насос мерным стаканом.';
  $('calBeforeField').classList.toggle('hidden',mode==='volume');
  $('calAfterLabel').textContent=mode==='volume'?'Объём, набранный в мерный стакан за тест, мл':'Показание весов после теста, г';
  $('calAfterMeasure').step=mode==='volume'?'1':'1';$('calAfterMeasure').placeholder=mode==='volume'?'Например 1350':'Например 50350';
  $('calMeasureHint').className='hint '+(mode==='volume'?'warn':'good');
  $('calMeasureHint').textContent=mode==='volume'?'Объёмный резерв: перед запуском направьте выход насоса в мерный стакан. После остановки внесите весь набранный объём в мл.':'Массовый режим: внесите показание весов до теста в граммах. После теста приложение посчитает фактическую потерю массы.';
  if(!$('sm4Hz').value)$('sm4Hz').value='30';if(!sm4ManualEdit&&!state.activeCal)$('sm4MinPerT').value=sm4Prediction($('sm4Hz').value,b.crop).minPerT.toFixed(2);
  renderCalPlan();renderCalState();
}
function switchBatchMode(mode){
  const b=activeBatch();if(!b)return;if(currentRun()&&currentRun().batchClientId===b.clientId)return alert('Во время активной работы способ контроля менять нельзя. Завершите текущую работу.');if(state.activeCal&&state.activeCal.batchClientId===b.clientId)return alert('Сначала завершите текущую калибровку.');mode=mode==='volume'?'volume':'mass';if(mode===modeOf(b))return;
  if(mode==='volume'&&!(Number(b.totalVolumeMl)>0)){const raw=prompt('Введите общий объём этой партии рабочего состава, л.');if(raw===null)return;const v=Number(String(raw).replace(',','.'));if(!(v>0))return alert('Объём должен быть больше нуля.');b.totalVolumeMl=v*1000;b.doseMlPerT=b.totalVolumeMl/b.seedTonnage;}
  if(mode==='mass'&&!(Number(b.totalMassG)>0)){const raw=prompt('Введите фактическую массу этой партии, г.');if(raw===null)return;const g=Number(String(raw).replace(',','.'));if(!(g>0))return alert('Масса должна быть больше нуля.');b.totalMassG=g;b.doseGPerT=g/b.seedTonnage;}
  b.measurementMode=mode;b.recipeKey=recipeKey(b);if(!['running','completed'].includes(b.status))b.status='prepared';touch(b);state.activeCal=null;pendingCalResult=null;$('pumpHz').value='';$('calBeforeMeasure').value='';$('calAfterMeasure').value='';saveState();queueRecord('batches',b);cloudSync(true);renderCalibration();renderWork();
}
$('calModeMass').onclick=()=>switchBatchMode('mass');$('calModeVolume').onclick=()=>switchBatchMode('volume');
$('sm4Hz').addEventListener('input',()=>{const h=Number($('sm4Hz').value),b=activeBatch();sm4ManualEdit=false;if(isFinite(h))$('sm4MinPerT').value=sm4Prediction(h,b?b.crop:'Соя').minPerT.toFixed(2);renderCalPlan();});
$('sm4MinPerT').addEventListener('input',()=>{sm4ManualEdit=true;renderCalPlan();});
function estimatePumpHz(target,recipeKeyValue,mode){
  const pts=state.calibrations.filter(c=>!c.deletedAt&&c.accepted&&c.recipeKey===recipeKeyValue&&modeOf(c)===mode&&flowValue(c)>0&&c.pumpHz>0).sort((a,b)=>flowValue(a)-flowValue(b));
  const unit=flowUnit(mode);
  if(!pts.length)return{hz:null,confidence:'Нет данных',points:0,text:`Первую частоту насоса задаёт оператор. После подтверждённых калибровок в ${unit} приложение начнёт предлагать стартовую частоту.`};
  if(pts.length===1){const p=pts[0],pv=flowValue(p),ratio=target/pv,hz=p.pumpHz*ratio,conf=(ratio>=.8&&ratio<=1.2)?'Средняя':'Низкая';return{hz,confidence:conf,points:1,text:`По одной подтверждённой точке: ${fmt(p.pumpHz,1)} Гц → ${fmt(pv,0)} ${unit}. Новую частоту обязательно перепроверить ${mode==='volume'?'мерным стаканом':'на весах'}.`};}
  let lo=null,hi=null;for(let i=0;i<pts.length-1;i++){const a=flowValue(pts[i]),b=flowValue(pts[i+1]);if(target>=a&&target<=b){lo=pts[i];hi=pts[i+1];break;}}
  let conf='Высокая';if(!lo){const near=[...pts].sort((a,b)=>Math.abs(flowValue(a)-target)-Math.abs(flowValue(b)-target)).slice(0,2).sort((a,b)=>flowValue(a)-flowValue(b));lo=near[0];hi=near[1];const edge=target<flowValue(pts[0])?flowValue(pts[0]):flowValue(pts[pts.length-1]);conf=Math.abs(target-edge)/Math.max(edge,1)<=.2?'Средняя':'Низкая';}
  const lov=flowValue(lo),hiv=flowValue(hi),dy=hiv-lov;let hz;if(Math.abs(dy)<.0001)hz=(lo.pumpHz+hi.pumpHz)/2;else hz=lo.pumpHz+(target-lov)*(hi.pumpHz-lo.pumpHz)/dy;
  return{hz,confidence:conf,points:pts.length,text:`Использовано ${pts.length} подтверждённых калибровок этого рецепта в режиме «${mode==='volume'?'объём':'масса'}». ${conf==='Высокая'?'Цель находится между фактическими точками.':'Расчёт выходит за фактически измеренный диапазон — обязательна контрольная калибровка.'}`};
}
function calPlan(){const b=activeBatch();if(!b)return null;const hz=Number($('sm4Hz').value),mpt=Number($('sm4MinPerT').value);if(!(mpt>0))return null;const totalMin=b.seedTonnage*mpt,mode=modeOf(b),total=primaryTotal(b);if(!(total>0))return null;const target=total/totalMin;return{batch:b,mode,hz,mpt,totalMin,target,learn:estimatePumpHz(target,b.recipeKey,mode)};}
function renderCalPlan(){
  const p=calPlan();if(!p)return;
  const model=sm4Prediction(p.hz,p.batch.crop),diff=Math.abs(p.mpt-model.minPerT),manual=diff>0.25;
  $('sm4Hint').className='hint '+(manual?'warn':model.cls);
  $('sm4Hint').innerHTML=manual
    ?`<b>Ручное значение: ${fmt(p.mpt,2)} мин/т.</b><br>Самообучение СМ‑4 сейчас прогнозирует ${fmt(model.minPerT,2)} мин/т. Для расчёта насоса будет использовано введённое вручную значение; после взвешивания биг-бэга модель сможет уточниться.`
    :`<b>${esc(model.confidence)} опора СМ‑4 · ${fmt(model.minPerT,2)} мин/т · ${fmt(model.kgMin,2)} кг/мин</b><br>${esc(model.text)}`;
  $('flowMetrics').innerHTML=metric('Требуемая подача',fmt(p.target,0)+' '+flowUnit(p.mode))+metric('Время партии',duration(p.totalMin))+metric('СМ‑4',fmt(p.hz,1)+' Гц')+metric('Производительность',fmt(1000/p.mpt,2)+' кг/мин');
  const l=p.learn;$('learningHint').className='hint '+(l.confidence==='Высокая'?'good':l.confidence==='Нет данных'?'':l.confidence==='Средняя'?'warn':'bad');$('learningHint').innerHTML=`<b>${esc(l.confidence==='Нет данных'?'Стартовая частота пока не рассчитана':`Подсказка: ${fmt(l.hz,1)} Гц · ${l.confidence} опора`)}</b><br>${esc(l.text)}`;
  if(l.hz!==null&&!$('pumpHz').value)$('pumpHz').value=(Math.round(l.hz*10)/10).toFixed(1);
}
$('changeBatchCal').onclick=openBatchPicker;
function openBatchPicker(){const list=$('batchPickerList'),rows=state.batches.filter(b=>!b.deletedAt).sort((a,b)=>String(b.createdAt).localeCompare(String(a.createdAt)));list.innerHTML=rows.length?'':'<div class="empty">Нет сохранённых партий.</div>';rows.forEach(b=>{const btn=document.createElement('button');btn.className='batchPick';btn.innerHTML=`<b>${esc(b.recipeName)}</b><small>${esc(b.crop)} · ${fmt(b.seedTonnage,2)} т · ${esc(totalLabel(b))} · ${modeOf(b)==='volume'?'объём':'масса'} · ${esc(statusRu(b.status))}</small>`;btn.onclick=()=>{state.activeBatchId=b.clientId;sm4ManualEdit=false;$('pumpHz').value='';$('calBeforeMeasure').value='';$('calAfterMeasure').value='';saveState();closeBatchPicker();renderCalibration();renderWork();};list.appendChild(btn);});$('batchPickerShade').classList.remove('hidden');}
function closeBatchPicker(){$('batchPickerShade').classList.add('hidden');}$('closeBatchPicker').onclick=closeBatchPicker;$('batchPickerShade').onclick=e=>{if(e.target===$('batchPickerShade'))closeBatchPicker();};
function renderCalState(){
  const a=state.activeCal;if(!a||a.batchClientId!==state.activeBatchId){$('calRunning').classList.add('hidden');$('calIdleButtons').classList.remove('hidden');$('calFinish').classList.add('hidden');return;}
  $('calIdleButtons').classList.add('hidden');if(!a.stoppedAt){$('calRunning').classList.remove('hidden');$('calFinish').classList.add('hidden');}else{$('calRunning').classList.add('hidden');$('calFinish').classList.remove('hidden');}updateCalTimer();
}
$('startCal').onclick=()=>{
  const p=calPlan(),pump=Number($('pumpHz').value),before=Number($('calBeforeMeasure').value);if(!p)return alert('Проверьте режим СМ‑4.');if(!(pump>0))return alert('Укажите частоту насоса.');if(p.mode==='mass'&&!(before>0))return alert('Введите показание весов перед тестом в граммах.');
  state.activeCal={batchClientId:p.batch.clientId,measurementMode:p.mode,startedAt:Date.now(),stoppedAt:null,pumpHz:pump,massBeforeG:p.mode==='mass'?before:null,requiredFlow:p.target,sm4Hz:p.hz,sm4MinPerT:p.mpt};pendingCalResult=null;const b=p.batch;b.status='calibrating';touch(b);saveState();queueRecord('batches',b);renderCalState();
};
$('stopCal').onclick=()=>{if(!state.activeCal||state.activeCal.stoppedAt)return;state.activeCal.stoppedAt=Date.now();saveState();renderCalState();$('calAfterMeasure').focus();};
function updateCalTimer(){const a=state.activeCal;if(!a||a.batchClientId!==state.activeBatchId)return;const end=a.stoppedAt||Date.now(),sec=Math.max(0,(end-a.startedAt)/1000),mm=Math.floor(sec/60),ss=Math.floor(sec%60),mode=a.measurementMode||'mass';$('calTimer').textContent=String(mm).padStart(2,'0')+':'+String(ss).padStart(2,'0');const target=a.requiredFlow*(sec/60);$('calTargetLoss').textContent=`Целевой расход к этому моменту: ${amountLabel(mode,target)}`+(sec>=600?' · 10 минут достигнуты — завершите контроль.':'');}
$('calcCalResult').onclick=()=>{
  const a=state.activeCal,after=Number($('calAfterMeasure').value);if(!a||!a.stoppedAt)return alert('Сначала завершите контроль.');if(!(after>0))return alert(a.measurementMode==='volume'?'Введите объём из мерного стакана в мл.':'Введите показание весов после теста в граммах.');
  const sec=(a.stoppedAt-a.startedAt)/1000,min=sec/60,mode=a.measurementMode||'mass';let amount,massAfterG=null,testVolumeMl=null;
  if(mode==='mass'){if(after>=a.massBeforeG)return alert('Показание после теста должно быть меньше показания до теста.');massAfterG=after;amount=a.massBeforeG-after;}else{testVolumeMl=after;amount=after;}
  const actual=amount/min,error=(actual-a.requiredFlow)/a.requiredFlow*100,next=a.pumpHz*(a.requiredFlow/actual);pendingCalResult={durationSec:sec,massAfterG,testVolumeMl,measuredAmount:amount,actualFlow:actual,errorPct:error,suggestedNextHz:next};
  const short=sec<120,long=sec>600,cls=Math.abs(error)<=5?'':Math.abs(error)<=12?'warn':'bad',box=$('calResultBox');box.className='resultCard '+cls;box.innerHTML=`<div class="resultTitle">Фактическая ${mode==='volume'?'объёмная':'массовая'} подача</div><div class="resultBig">${fmt(actual,0)} ${flowUnit(mode)}</div><div class="metrics">${metric('Требуется',fmt(a.requiredFlow,0)+' '+flowUnit(mode))}${metric('Ошибка',(error>=0?'+':'')+fmt(error,1)+' %')}${metric(mode==='volume'?'Набрано':'Потеря массы',amountLabel(mode,amount))}${metric('Интервал',fmt(min,2)+' мин')}</div><div class="resultText" style="margin-top:12px">Расчётный следующий шаг: <b>${fmt(next,1)} Гц</b>. Это только подсказка — новую частоту нужно снова проверить ${mode==='volume'?'мерным стаканом':'на весах'}.${short?' Контроль короче 2 минут: точность оценки ниже.':''}${long?' Контроль превысил 10 минут: для следующей попытки достаточно более короткого интервала.':''}</div>`;box.classList.remove('hidden');$('calDecisionButtons').classList.remove('hidden');
};
function saveCalibration(accepted){
  const a=state.activeCal,r=pendingCalResult,b=activeBatch();if(!a||!r||!b)return;const mode=a.measurementMode||'mass';
  const c={clientId:uuid(),batchClientId:b.clientId,recipeKey:b.recipeKey,crop:b.crop,measurementMode:mode,sm4Hz:a.sm4Hz,sm4MinPerT:a.sm4MinPerT,requiredFlowGMin:mode==='mass'?a.requiredFlow:null,requiredFlowMlMin:mode==='volume'?a.requiredFlow:null,pumpHz:a.pumpHz,durationSec:r.durationSec,massBeforeG:mode==='mass'?a.massBeforeG:null,massAfterG:mode==='mass'?r.massAfterG:null,testVolumeMl:mode==='volume'?r.testVolumeMl:null,actualFlowGMin:mode==='mass'?r.actualFlow:null,actualFlowMlMin:mode==='volume'?r.actualFlow:null,errorPct:r.errorPct,accepted:!!accepted,occurredAt:iso(),notes:'',createdAt:iso(),updatedAt:iso()};
  state.calibrations.push(c);queueRecord('calibrations',c);if(accepted){b.status='ready';touch(b);queueRecord('batches',b);}else{b.status='prepared';touch(b);queueRecord('batches',b);}const next=r.suggestedNextHz;state.activeCal=null;pendingCalResult=null;saveState();$('calAfterMeasure').value='';$('calBeforeMeasure').value='';$('calResultBox').classList.add('hidden');$('calDecisionButtons').classList.add('hidden');if(!accepted&&isFinite(next))$('pumpHz').value=(Math.round(next*10)/10).toFixed(1);cloudSync(true);if(accepted)showPage('work');else renderCalibration();
}
$('acceptCal').onclick=()=>{if(pendingCalResult&&Math.abs(pendingCalResult.errorPct)>12&&!confirm(`Отклонение ${fmt(Math.abs(pendingCalResult.errorPct),1)}%. Принять эту калибровку как рабочую?`))return;saveCalibration(true);};$('repeatCal').onclick=()=>saveCalibration(false);

function bagActiveSec(bag,nowMs=Date.now()){
  if(!bag||!bag.startedAt)return 0;
  const endMs=bag.endedAt?new Date(bag.endedAt).getTime():nowMs;
  let total=(endMs-new Date(bag.startedAt).getTime())/1000-Number(bag.pausedDurationSec||0);
  if(bag.pausedAt&&!bag.endedAt)total-=(nowMs-new Date(bag.pausedAt).getTime())/1000;
  return Math.max(0,total);
}
function estimatedBagKg(bag){const sec=bagActiveSec(bag),mpt=Number(bag&&bag.modelMinPerT);return mpt>0?sec/60*1000/mpt:0;}
function bagValueKg(bag){if(Number(bag.actualNetKg)>0)return Number(bag.actualNetKg);if(Number(bag.estimatedKg)>0)return Number(bag.estimatedKg);if(bag.status==='running')return estimatedBagKg(bag);return 0;}
function processedSeedKg(run,includeActive=true){if(!run)return 0;return bagsForRun(run.clientId).reduce((s,b)=>s+(includeActive||b.status!=='running'?bagValueKg(b):0),0);}
function updateRunProcessedFromBags(run){
  if(!run)return;const kg=processedSeedKg(run,true);if(kg>0){run.processedTonnage=kg/1000;touch(run);queueRecord('runs',run);}
}
function nextBagNo(run){const a=bagsForRun(run.clientId);return a.length?Math.max(...a.map(b=>Number(b.bagNo)||0))+1:1;}
function nextBagTarget(run){
  const planned=Math.max(0,Number(run.seedTonnage||0)*1000);
  const committed=bagsForRun(run.clientId).filter(b=>b.status!=='cancelled').reduce((s,b)=>s+Number(b.targetKg||0),0);
  const left=planned-committed;
  return left>0?Math.min(1000,left):1000;
}
function sm4BadgeClass(c){return c==='Высокая'?'good':c==='Низкая'?'bad':'warn';}
function renderSm4WorkState(run){
  const pred=sm4Prediction(run.sm4Hz,run.crop),badge=$('sm4LearningBadge');
  badge.className='badge '+sm4BadgeClass(pred.confidence);badge.textContent=pred.confidence.toLowerCase()+' опора';
  const drift=Math.abs(Number(run.sm4MinPerT)-Number(pred.minPerT));
  $('sm4LearningHint').className='hint '+(drift>0.35?'warn':pred.cls);
  $('sm4LearningHint').innerHTML=drift>0.35
    ?`Текущая работа зафиксирована на <b>${fmt(run.sm4MinPerT,2)} мин/т</b>. Самообучение уже оценивает СМ‑4 в ${fmt(pred.minPerT,2)} мин/т. Новое значение применяем только после следующей калибровки насоса, чтобы не менять дозирование посреди партии.`
    :`Счётчик семян: <b>${fmt(run.sm4MinPerT,2)} мин/т = ${fmt(1000/run.sm4MinPerT,2)} кг/мин</b>. ${esc(pred.text)}`;
  let bag=currentBag();if(bag&&bag.runClientId!==run.clientId){state.activeBagId=null;saveState();bag=null;}
  $('bagIdle').classList.toggle('hidden',!!bag);$('bagRunning').classList.toggle('hidden',!bag);
  if(!bag){
    $('bagNo').value=nextBagNo(run);$('bagTargetKg').value=Math.round(nextBagTarget(run));
  }else updateBagCounter();
  renderPendingWeights(run);
}
function renderPendingWeights(run){
  const host=$('pendingWeights');host.innerHTML='';
  const rows=bagsForRun(run.clientId).filter(b=>b.status==='completed').slice().reverse();
  if(!rows.length){host.innerHTML='<div class="hint">После завершения первого биг-бэга здесь появится отдельная кнопка фиксации фактического веса.</div>';return;}
  rows.forEach(b=>{
    const row=document.createElement('div');row.className='pendingWeightRow';
    const weighed=Number(b.actualNetKg)>0;
    row.innerHTML=`<div class="meta"><b>Биг-бэг №${fmtInt(b.bagNo)} · ${weighed?'взвешен':'ждёт весов'}</b><span>${fmt(b.activeDurationSec/60,2)} мин · расчётно ${fmt(b.estimatedKg,1)} кг${weighed?' · факт '+fmt(b.actualNetKg,1)+' кг':''}</span></div><button type="button">${weighed?'Изменить вес':'Зафиксировать вес'}</button>`;
    row.querySelector('button').onclick=()=>openBagWeight(b);host.appendChild(row);
  });
}
function openBagWeight(bag){
  if(!bag)return;state.weightBagId=bag.clientId;saveState();
  $('bagWeightTitle').textContent=`Биг-бэг №${fmtInt(bag.bagNo)} — фиксация веса`;
  $('bagWeightInfo').innerHTML=`СМ‑4: <b>${fmt(bag.sm4Hz,1)} Гц</b> · активное время <b>${fmt(bag.activeDurationSec/60,2)} мин</b> · расчётно <b>${fmt(bag.estimatedKg,1)} кг</b>.`;
  $('bagActualKg').value=Number(bag.actualNetKg)>0?Number(bag.actualNetKg).toFixed(1):'';
  $('bagWeightResult').classList.add('hidden');$('bagWeightShade').classList.remove('hidden');setTimeout(()=>$('bagActualKg').focus(),100);
}
function closeBagWeight(){$('bagWeightShade').classList.add('hidden');state.weightBagId=null;saveState();}
$('closeBagWeight').onclick=closeBagWeight;$('bagWeightShade').onclick=e=>{if(e.target===$('bagWeightShade'))closeBagWeight();};
$('saveBagWeight').onclick=()=>{
  const bag=state.bags.find(b=>b.clientId===state.weightBagId&&!b.deletedAt),kg=Number($('bagActualKg').value);if(!bag)return;if(!(kg>0))return alert('Введите фактический вес семян в биг-бэге, кг.');
  const min=Number(bag.activeDurationSec)/60;if(!(min>0))return alert('В этой записи нет корректного активного времени.');
  bag.actualNetKg=kg;bag.actualKgMin=kg/min;bag.actualMinPerT=1000/bag.actualKgMin;bag.deviationPct=(bag.actualMinPerT-bag.modelMinPerT)/bag.modelMinPerT*100;bag.weightRecordedAt=iso();
  const ad=Math.abs(bag.deviationPct);bag.learningStatus=ad<=8?'accepted':'review';touch(bag);queueRecord('bags',bag);
  const run=state.runs.find(r=>r.clientId===bag.runClientId&&!r.deletedAt);if(run){updateRunProcessedFromBags(run);saveState();}
  cloudSync(true);
  $('bagWeightResult').className='resultCard '+(bag.learningStatus==='accepted'?'':'warningCard');
  $('bagWeightResult').innerHTML=`<div class="resultTitle">${bag.learningStatus==='accepted'?'Замер принят в самообучение':'Замер сохранён для проверки'}</div><div class="resultBig">${fmt(bag.actualMinPerT,2)} мин/т</div><div class="metrics">${metric('Фактический вес',fmt(kg,1)+' кг')}${metric('Производительность',fmt(bag.actualKgMin,2)+' кг/мин')}${metric('Отклонение от модели',(bag.deviationPct>=0?'+':'')+fmt(bag.deviationPct,1)+' %')}${metric('СМ‑4',fmt(bag.sm4Hz,1)+' Гц')}</div>`;
  if(bag.learningStatus==='review')alert('Вес сохранён, но отклонение больше 8%. Чтобы случайная пауза или ошибочный вес не испортили модель СМ‑4, этот замер пока не участвует в самообучении. Его можно подтвердить в Истории.');
  renderHistory();if(currentRun())renderSm4WorkState(currentRun());
};
$('startBag').onclick=()=>{
  const run=currentRun();if(!run)return alert('Сначала начните работу.');if(currentBag())return;const target=Number($('bagTargetKg').value);if(!(target>0))return alert('Укажите целевой вес биг-бэга.');
  const pred=sm4Prediction(run.sm4Hz,run.crop),bag={clientId:uuid(),runClientId:run.clientId,batchClientId:run.batchClientId,crop:run.crop||'Соя',bagNo:nextBagNo(run),targetKg:target,sm4Hz:run.sm4Hz,modelMinPerT:run.sm4MinPerT,modelSource:pred.source,modelConfidence:pred.confidence,startedAt:iso(),endedAt:null,pausedAt:null,pausedDurationSec:0,activeDurationSec:null,estimatedKg:null,actualNetKg:null,actualKgMin:null,actualMinPerT:null,deviationPct:null,weightRecordedAt:null,learningStatus:'pending_weight',status:'running',notes:'',createdAt:iso(),updatedAt:iso()};
  state.bags.push(bag);state.activeBagId=bag.clientId;saveState();queueRecord('bags',bag);cloudSync(true);renderSm4WorkState(run);updateBagCounter();
};
$('pauseBag').onclick=()=>{
  const bag=currentBag();if(!bag)return;
  if(bag.pausedAt){bag.pausedDurationSec=Number(bag.pausedDurationSec||0)+(Date.now()-new Date(bag.pausedAt).getTime())/1000;bag.pausedAt=null;}else bag.pausedAt=iso();
  touch(bag);saveState();queueRecord('bags',bag);cloudSync(true);updateBagCounter();
};
$('finishBag').onclick=()=>{
  const bag=currentBag(),run=currentRun();if(!(bag&&run))return;
  if(bag.pausedAt){bag.pausedDurationSec=Number(bag.pausedDurationSec||0)+(Date.now()-new Date(bag.pausedAt).getTime())/1000;bag.pausedAt=null;}
  bag.endedAt=iso();bag.activeDurationSec=bagActiveSec(bag,new Date(bag.endedAt).getTime());bag.estimatedKg=bag.activeDurationSec/60*1000/bag.modelMinPerT;bag.status='completed';touch(bag);state.activeBagId=null;updateRunProcessedFromBags(run);saveState();queueRecord('bags',bag);queueRecord('runs',run);cloudSync(true);renderWork();
  alert(`Биг-бэг №${bag.bagNo} завершён.\nАктивное время: ${fmt(bag.activeDurationSec/60,2)} мин.\nПо счётчику обработано: ${fmt(bag.estimatedKg,1)} кг.\nПосле взвешивания нажмите «Зафиксировать вес» — это станет фактической калибровкой подачи сои в СМ‑4.`);
};
function updateBagCounter(){
  const bag=currentBag();if(!bag)return;const sec=bagActiveSec(bag),kg=estimatedBagKg(bag),target=Number(bag.targetKg)||1000,mm=Math.floor(sec/60),ss=Math.floor(sec%60);
  $('bagKgCounter').textContent=fmt(kg,1)+' кг';$('bagCounterMeta').textContent=`${String(mm).padStart(2,'0')}:${String(ss).padStart(2,'0')} · ${fmt(bag.sm4Hz,1)} Гц · ${fmt(bag.modelMinPerT,2)} мин/т${bag.pausedAt?' · ПАУЗА':''}`;
  $('bagProgress').querySelector('i').style.width=clamp(kg/target*100,0,100)+'%';$('pauseBag').textContent=bag.pausedAt?'Продолжить':'Пауза';
  const counter=$('bagKgCounter');counter.style.color=kg>=target?'#58d39b':'';
  const run=currentRun();if(run){const total=processedSeedKg(run,true);$('processedSeedsSummary').className='hint '+(kg>=target?'good':'');$('processedSeedsSummary').innerHTML=`По счётчикам обработано сейчас: <b>${fmt(total,1)} кг</b> (${fmt(total/1000,3)} т). Фактические веса биг-бэгов автоматически заменяют расчётные значения после взвешивания.`;}
}
function renderWork(){
  const b=ensureActiveBatch(),cal=acceptedForBatch(b);$('workNoReady').classList.toggle('hidden',!!(b&&cal));$('workBody').classList.toggle('hidden',!(b&&cal));if(!(b&&cal))return;const mode=modeOf(b),req=requiredFlow(cal),actual=flowValue(cal),unit=flowUnit(mode);
  $('workStartLabel').textContent=mode==='volume'?'Объём смеси перед работой, л':'Показание весов перед работой, г';$('workStartMeasure').step=mode==='volume'?'0.01':'1';$('workStartMeasure').placeholder=mode==='volume'?'Например 45':'Например 52000';
  $('checkpointLabel').textContent=mode==='volume'?'Текущий объём смеси, л':'Текущее показание весов, г';$('checkpointMeasure').step=mode==='volume'?'0.01':'1';$('checkpointMeasure').placeholder=mode==='volume'?'Например 38.5':'Например 46800';
  $('workEndLabel').textContent=mode==='volume'?'Объём смеси после работы, л':'Показание весов после работы, г';$('workEndMeasure').step=mode==='volume'?'0.01':'1';$('workEndMeasure').placeholder=mode==='volume'?'Например 2.0':'Например 8500';
  if(mode==='volume'&&!$('workStartMeasure').value&&b.totalVolumeMl)$('workStartMeasure').value=(b.totalVolumeMl/1000).toFixed(2);
  const sm4p=sm4Prediction(cal.sm4Hz,b.crop);
  $('workMetrics').innerHTML=metric('Партия',b.recipeName)+metric('Семена',fmt(b.seedTonnage,2)+' т')+metric('Доза смеси',doseLabel(b))+metric('Контроль',mode==='volume'?'по объёму':'по массе')+metric('СМ‑4',fmt(cal.sm4Hz,1)+' Гц · '+fmt(cal.sm4MinPerT,2)+' мин/т')+metric('СМ‑4 модель',sm4p.confidence+' опора',sm4p.realPoints+' взвешиваний рядом')+metric('Насос',fmt(cal.pumpHz,1)+' Гц')+metric('Требуемая подача',fmt(req,0)+' '+unit)+metric('Калибр. подача',fmt(actual,0)+' '+unit)+metric('Ошибка калибровки',(cal.errorPct>=0?'+':'')+fmt(cal.errorPct,1)+' %')+metric('Плановое время',duration(b.seedTonnage*cal.sm4MinPerT));
  const safety=$('workMetrics').nextElementSibling;if(safety&&safety.classList.contains('safetyInline'))safety.textContent=Math.abs(cal.errorPct)>5?`Калибровка отличается от требуемой подачи на ${(cal.errorPct>=0?'+':'')+fmt(cal.errorPct,1)}%. Во время работы чаще контролируйте ${mode==='volume'?'объём':'массу'}; при возможности повторите калибровку.`:'СМ‑4 и насос не управляются приложением. Счётчик килограммов является расчётным до фактического взвешивания биг-бэга.';
  let run=currentRun();if(run&&run.batchClientId!==b.clientId){state.activeRunId=null;state.activeBagId=null;saveState();run=null;}$('workStartCard').classList.toggle('hidden',!!run);$('workRunningCard').classList.toggle('hidden',!run);if(run){renderCheckpoints(run);renderSm4WorkState(run);updateWorkTimer();updateBagCounter();const kg=processedSeedKg(run,true);$('processedSeedsSummary').innerHTML=`По счётчикам обработано сейчас: <b>${fmt(kg,1)} кг</b> (${fmt(kg/1000,3)} т).`;}
}
$('startWork').onclick=()=>{
  const b=activeBatch(),cal=acceptedForBatch(b),v=Number($('workStartMeasure').value);if(!(b&&cal))return alert('Нет подтверждённой калибровки.');if(!(v>0))return alert(modeOf(b)==='volume'?'Введите объём смеси перед работой в литрах.':'Введите показание весов перед работой в граммах.');const mode=modeOf(b),req=requiredFlow(cal),actual=flowValue(cal);
  const r={clientId:uuid(),batchClientId:b.clientId,recipeKey:b.recipeKey,crop:b.crop,measurementMode:mode,seedTonnage:b.seedTonnage,sm4Hz:cal.sm4Hz,sm4MinPerT:cal.sm4MinPerT,plannedDurationMin:b.seedTonnage*cal.sm4MinPerT,requiredFlowGMin:mode==='mass'?req:null,requiredFlowMlMin:mode==='volume'?req:null,pumpHz:cal.pumpHz,calibratedFlowGMin:mode==='mass'?actual:null,calibratedFlowMlMin:mode==='volume'?actual:null,startMassG:mode==='mass'?v:null,endMassG:null,startVolumeMl:mode==='volume'?v*1000:null,endVolumeMl:null,processedTonnage:0,checkpoints:[],startedAt:iso(),endedAt:null,status:'running',notes:'',createdAt:iso(),updatedAt:iso()};
  state.runs.push(r);state.activeRunId=r.clientId;state.activeBagId=null;b.status='running';touch(b);saveState();queueRecord('runs',r);queueRecord('batches',b);cloudSync(true);renderWork();
};
function elapsedRunMin(run){return run&&run.startedAt?(Date.now()-new Date(run.startedAt).getTime())/60000:0;}
function updateWorkTimer(){const r=currentRun();if(!r)return;const min=Math.max(0,elapsedRunMin(r)),sec=Math.floor(min*60),mm=Math.floor(sec/60),ss=sec%60;$('workTimer').textContent=String(mm).padStart(2,'0')+':'+String(ss).padStart(2,'0');const kg=processedSeedKg(r,true),remainKg=Math.max(0,Number(r.seedTonnage)*1000-kg),remain=remainKg/1000*Number(r.sm4MinPerT);$('workRemain').textContent=`Общее время ${String(mm).padStart(2,'0')}:${String(ss).padStart(2,'0')} · по счётчикам осталось ≈ ${fmt(remainKg,0)} кг / ${duration(remain)}`;$('workProgress').querySelector('i').style.width=clamp(kg/(Number(r.seedTonnage)*1000)*100,0,100)+'%';updateBagCounter();}
$('addCheckpoint').onclick=()=>{
  const r=currentRun(),b=activeBatch(),v=Number($('checkpointMeasure').value);if(!r)return;if(!(v>0))return alert(modeOf(r)==='volume'?'Введите текущий объём смеси в литрах.':'Введите текущее показание весов в граммах.');const mode=modeOf(r),current=mode==='volume'?v*1000:v,start=mode==='volume'?r.startVolumeMl:r.startMassG;if(current>start)return alert(mode==='volume'?'Текущий объём не может быть больше стартового.':'Текущее показание не может быть больше стартового.');
  const used=start-current,seedKg=processedSeedKg(r,true),dose=primaryDose(b),expected=seedKg>0?dose*(seedKg/1000):requiredFlow(r)*elapsedRunMin(r),dev=expected>0?(used-expected)/expected*100:0,avgDose=seedKg>0?used/(seedKg/1000):null,cp={at:iso(),measurementMode:mode,elapsedMin:elapsedRunMin(r),processedSeedKg:seedKg,usedValue:used,expectedValue:expected,deviationPct:dev};if(mode==='volume')cp.volumeMl=current;else cp.massG=current;r.checkpoints=r.checkpoints||[];r.checkpoints.push(cp);touch(r);saveState();queueRecord('runs',r);cloudSync(true);const cls=Math.abs(dev)<=5?'good':Math.abs(dev)<=12?'warn':'bad';$('checkpointResult').className='hint '+cls;$('checkpointResult').innerHTML=`По счётчику обработано <b>${fmt(seedKg,1)} кг</b>. Использовано состава <b>${amountLabel(mode,used)}</b>, по целевой дозе должно быть ${amountLabel(mode,expected)}. Отклонение ${(dev>=0?'+':'')+fmt(dev,1)}%.${avgDose!==null?' Фактическая доза: <b>'+(mode==='volume'?fmt(avgDose/1000,3)+' л/т':fmtInt(avgDose)+' г/т')+'</b>.':''}`;renderCheckpoints(r);$('checkpointMeasure').value='';
};
function renderCheckpoints(r){const host=$('checkpointsList');host.innerHTML='';const runMode=modeOf(r);(r.checkpoints||[]).slice().reverse().forEach(cp=>{const mode=cp.measurementMode||runMode,current=mode==='volume'?(cp.volumeMl??null):(cp.massG??null),d=document.createElement('div');d.className='checkpointRow';d.innerHTML=`<div><b>${new Date(cp.at).toLocaleTimeString('ru-RU',{hour:'2-digit',minute:'2-digit'})}</b><br><span>${current===null?'—':mode==='volume'?fmt(current/1000,3)+' л':fmtG(current)} · семена ${fmt(cp.processedSeedKg||0,1)} кг</span></div><div style="text-align:right"><b>${(cp.deviationPct>=0?'+':'')+fmt(cp.deviationPct,1)}%</b><br><span>к дозе</span></div>`;host.appendChild(d);});}
$('finishWork').onclick=()=>{
  const r=currentRun(),b=activeBatch(),rawEnd=$('workEndMeasure').value,v=Number(rawEnd);if(!r)return;if(currentBag())return alert('Сначала завершите текущий биг-бэг.');if(rawEnd===''||!isFinite(v)||v<0)return alert(modeOf(r)==='volume'?'Введите финальный объём смеси в литрах.':'Введите финальное показание весов в граммах.');const mode=modeOf(r),end=mode==='volume'?v*1000:v,start=mode==='volume'?r.startVolumeMl:r.startMassG;if(end>start)return alert(mode==='volume'?'Финальный объём не может быть больше стартового.':'Финальное показание не может быть больше стартового.');
  const seedKg=processedSeedKg(r,false);if(!(seedKg>0)&&!confirm('Нет ни одного завершённого счётчика биг-бэга. Завершить работу без фиксации обработанных килограммов?'))return;
  if(mode==='volume')r.endVolumeMl=end;else r.endMassG=end;r.processedTonnage=seedKg>0?seedKg/1000:Number(b.seedTonnage);r.endedAt=iso();r.status='completed';touch(r);b.status='completed';touch(b);state.activeRunId=null;state.activeBagId=null;saveState();queueRecord('runs',r);queueRecord('batches',b);cloudSync(true);const used=start-end,actualDose=r.processedTonnage>0?used/r.processedTonnage:null,targetDose=primaryDose(b),doseErr=actualDose!==null&&targetDose>0?(actualDose-targetDose)/targetDose*100:null,doseTxt=mode==='volume'?fmt(actualDose/1000,3)+' л/т':fmtInt(actualDose)+' г/т',pendingWeights=bagsForRun(r.clientId).filter(x=>x.status==='completed'&&!(Number(x.actualNetKg)>0)).length;alert(`Работа сохранена.\nОбработано по счётчикам: ${fmt(r.processedTonnage*1000,1)} кг.\nФактический расход состава: ${amountLabel(mode,used)}.\nФактическая доза: ${doseTxt} (${doseErr>=0?'+':''}${fmt(doseErr,1)}% к расчёту).${pendingWeights?`\nБиг-бэгов ожидают взвешивания: ${pendingWeights}. После ввода веса тоннаж работы будет уточнён автоматически.`:''}`);$('workStartMeasure').value='';$('workEndMeasure').value='';renderWork();
};

function statusRu(s){return({prepared:'смесь готова',calibrating:'калибровка',ready:'готово к работе',running:'в работе',completed:'завершено',cancelled:'отменено',planned:'запланировано'}[s]||s||'—');}
function renderHistory(){
  qsa('[data-history-tab]').forEach(b=>b.classList.toggle('active',b.dataset.historyTab===historyTab));
  const acceptedPump=state.calibrations.filter(c=>c.accepted&&!c.deletedAt),recipes=new Set(acceptedPump.map(c=>c.recipeKey));
  const weighed=state.bags.filter(b=>!b.deletedAt&&Number(b.actualNetKg)>0),acceptedBags=weighed.filter(b=>b.learningStatus==='accepted');
  $('learningSummary').innerHTML=metric('Насос — точек',String(acceptedPump.length))+metric('СМ‑4 — в обучении',String(acceptedBags.length))+metric('Взвешено биг-бэгов',String(weighed.length))+metric('Работ',String(state.runs.filter(x=>x.status==='completed'&&!x.deletedAt).length));
  $('cloudStatus').textContent=cloudText;
  const host=$('historyList');host.innerHTML='';let arr=[];
  if(historyTab==='batches')arr=state.batches.filter(x=>!x.deletedAt).sort((a,b)=>String(b.createdAt).localeCompare(String(a.createdAt)));
  if(historyTab==='calibrations')arr=state.calibrations.filter(x=>!x.deletedAt).sort((a,b)=>String(b.occurredAt).localeCompare(String(a.occurredAt)));
  if(historyTab==='bags'){
    const curve=document.createElement('article');curve.className='historyCard';
    const points=sm4LearningCurve('Соя');
    curve.innerHTML=`<div class="historyTop"><h3>Самообучение СМ‑4 — соя</h3><span class="badge">${acceptedBags.filter(b=>b.crop==='Соя').length} факт. взвеш.</span></div><div class="sm4Curve">${points.map(p=>`<div class="sm4Point"><span>${fmt(p.hz,0)} Гц · ${esc(p.confidence)}</span><b>${fmt(p.minPerT,2)} мин/т</b><span>${fmt(p.kgMin,2)} кг/мин · ${p.realPoints} факт.</span></div>`).join('')}</div><div class="hint" style="margin-top:10px">Стартовые точки 2026: 29→37, 30→36, 31→35, 32→34 мин/т. Фактические взвешивания получают больший вес в модели; сильно отличающиеся замеры сначала требуют подтверждения.</div>`;
    host.appendChild(curve);
    arr=state.bags.filter(x=>!x.deletedAt).sort((a,b)=>String(b.startedAt||b.createdAt).localeCompare(String(a.startedAt||a.createdAt)));
  }
  if(historyTab==='runs')arr=state.runs.filter(x=>!x.deletedAt).sort((a,b)=>String(b.startedAt||b.createdAt).localeCompare(String(a.startedAt||a.createdAt)));
  if(!arr.length){if(historyTab!=='bags')host.innerHTML='<div class="empty">Записей пока нет.</div>';else host.insertAdjacentHTML('beforeend','<div class="empty">Фактических биг-бэгов пока нет.</div>');return;}
  arr.forEach(x=>host.appendChild(historyCard(x,historyTab)));
}
qsa('[data-history-tab]').forEach(b=>b.onclick=()=>{historyTab=b.dataset.historyTab;renderHistory();});
function deleteCalibration(x){
  if(!x||x.deletedAt)return;const suffix=x.accepted?' Эта точка больше не будет участвовать в самообучении и не будет использоваться как рабочая калибровка.':'';if(!confirm('Удалить эту калибровку?'+suffix))return;x.deletedAt=iso();x.updatedAt=iso();queueRecord('calibrations',x);const b=state.batches.find(b=>b.clientId===x.batchClientId&&!b.deletedAt);if(b&&x.accepted&&!acceptedForBatch(b)&&!['running','completed'].includes(b.status)){b.status='prepared';touch(b);queueRecord('batches',b);}saveState();cloudSync(true);renderHistory();renderCalibration();renderWork();
}
function setBagLearning(x,status){
  if(!x||x.deletedAt||!(Number(x.actualNetKg)>0))return;x.learningStatus=status;touch(x);queueRecord('bags',x);saveState();cloudSync(true);renderHistory();renderCalibration();renderWork();
}
function deleteBagRecord(x){
  if(!x||x.deletedAt)return;if(!confirm(`Удалить запись биг-бэга №${x.bagNo}? Она будет исключена из самообучения и из расчёта обработанного тоннажа.`))return;
  x.deletedAt=iso();x.learningStatus='excluded';touch(x);queueRecord('bags',x);if(state.activeBagId===x.clientId)state.activeBagId=null;const run=state.runs.find(r=>r.clientId===x.runClientId&&!r.deletedAt);if(run){updateRunProcessedFromBags(run);queueRecord('runs',run);}saveState();cloudSync(true);renderHistory();renderWork();renderCalibration();
}
function historyCard(x,type){
  const d=document.createElement('article');d.className='historyCard';const mode=modeOf(x);
  if(type==='batches'){d.innerHTML=`<div class="historyTop"><h3>${esc(x.recipeName)}</h3><span class="badge">${esc(statusRu(x.status))}</span></div><div style="margin-top:7px"><span class="modeBadge ${mode==='volume'?'volume':''}">${mode==='volume'?'по объёму':'по массе'}</span></div><div class="historyMeta"><div>Культура: <b>${esc(x.crop)}</b></div><div>Тоннаж: <b>${fmt(x.seedTonnage,2)} т</b></div><div>${mode==='volume'?'Объём':'Масса'}: <b>${esc(totalLabel(x))}</b></div><div>Доза: <b>${esc(doseLabel(x))}</b></div></div>`;}
  else if(type==='calibrations'){const actual=flowValue(x),req=requiredFlow(x);d.innerHTML=`<div class="historyTop"><h3>${fmt(x.pumpHz,1)} Гц → ${fmt(actual,0)} ${flowUnit(mode)}</h3><span class="badge ${x.accepted?'good':'warn'}">${x.accepted?'принято':'попытка'}</span></div><div style="margin-top:7px"><span class="modeBadge ${mode==='volume'?'volume':''}">${mode==='volume'?'по объёму':'по массе'}</span></div><div class="historyMeta"><div>Требовалось: <b>${fmt(req,0)} ${flowUnit(mode)}</b></div><div>Ошибка: <b>${(x.errorPct>=0?'+':'')+fmt(x.errorPct,1)}%</b></div><div>СМ‑4: <b>${fmt(x.sm4Hz,1)} Гц</b></div><div>Интервал: <b>${fmt(x.durationSec/60,2)} мин</b></div></div><div class="historyActions"><button class="miniDanger" type="button">Удалить</button></div>`;d.querySelector('.miniDanger').onclick=()=>deleteCalibration(x);}
  else if(type==='bags'){
    const weighed=Number(x.actualNetKg)>0,learn=x.learningStatus||'pending_weight',badgeClass=learn==='accepted'?'good':learn==='review'?'warn':'';
    d.classList.toggle('learningReview',learn==='review');
    d.innerHTML=`<div class="historyTop"><h3>Биг-бэг №${fmtInt(x.bagNo)} · ${fmt(x.sm4Hz,1)} Гц</h3><span class="badge ${badgeClass}">${weighed?(learn==='accepted'?'в обучении':learn==='review'?'нужно подтвердить':'исключён'):'ждёт весов'}</span></div><div class="historyMeta"><div>Цель: <b>${fmt(x.targetKg,0)} кг</b></div><div>Активное время: <b>${fmt(Number(x.activeDurationSec||0)/60,2)} мин</b></div><div>Расчётно: <b>${fmt(x.estimatedKg,1)} кг</b></div><div>Факт. вес: <b>${weighed?fmt(x.actualNetKg,1)+' кг':'—'}</b></div><div>Модель на старте: <b>${fmt(x.modelMinPerT,2)} мин/т</b></div><div>Факт. СМ‑4: <b>${weighed?fmt(x.actualMinPerT,2)+' мин/т':'—'}</b></div>${weighed?`<div>Отклонение: <b>${(x.deviationPct>=0?'+':'')+fmt(x.deviationPct,1)}%</b></div><div>Производительность: <b>${fmt(x.actualKgMin,2)} кг/мин</b></div>`:''}</div><div class="historyActions">${x.status==='completed'?`<button class="miniBtn weightBtn" type="button">${weighed?'Изменить вес':'Зафиксировать вес'}</button>`:''}${weighed&&learn!=='accepted'?'<button class="miniBtn acceptBtn" type="button">Использовать в обучении</button>':''}${weighed&&learn==='accepted'?'<button class="miniBtn excludeBtn" type="button">Исключить из обучения</button>':''}<button class="miniDanger deleteBagBtn" type="button">Удалить запись</button></div>`;
    const wb=d.querySelector('.weightBtn');if(wb)wb.onclick=()=>openBagWeight(x);const ab=d.querySelector('.acceptBtn');if(ab)ab.onclick=()=>setBagLearning(x,'accepted');const eb=d.querySelector('.excludeBtn');if(eb)eb.onclick=()=>setBagLearning(x,'excluded');d.querySelector('.deleteBagBtn').onclick=()=>deleteBagRecord(x);
  }
  else{const start=mode==='volume'?x.startVolumeMl:x.startMassG,end=mode==='volume'?x.endVolumeMl:x.endMassG,used=start!==null&&start!==undefined&&end!==null&&end!==undefined?start-end:null,tons=Number(x.processedTonnage||x.seedTonnage)||0,actualDose=used!==null&&tons>0?used/tons:null,bagCount=bagsForRun(x.clientId).filter(b=>b.status==='completed').length,weighedCount=bagsForRun(x.clientId).filter(b=>Number(b.actualNetKg)>0).length;d.innerHTML=`<div class="historyTop"><h3>${esc(x.crop||'Работа')}</h3><span class="badge ${x.status==='completed'?'good':''}">${esc(statusRu(x.status))}</span></div><div style="margin-top:7px"><span class="modeBadge ${mode==='volume'?'volume':''}">${mode==='volume'?'по объёму':'по массе'}</span></div><div class="historyMeta"><div>Семена: <b>${fmt(tons,3)} т</b></div><div>Биг-бэги: <b>${bagCount} · взвешено ${weighedCount}</b></div><div>СМ‑4: <b>${fmt(x.sm4Hz,1)} Гц · ${fmt(x.sm4MinPerT,2)} мин/т</b></div><div>Насос: <b>${fmt(x.pumpHz,1)} Гц</b></div><div>Подача: <b>${fmt(calibratedFlow(x),0)} ${flowUnit(mode)}</b></div><div>Факт. расход: <b>${used===null?'—':amountLabel(mode,used)}</b></div><div>Факт. доза: <b>${actualDose===null?'—':mode==='volume'?fmt(actualDose/1000,3)+' л/т':fmtInt(actualDose)+' г/т'}</b></div></div>`;}
  return d;
}

// Облако: используем ту же авторизацию, что сушилка и склад химии. Ядро приложения от сети не зависит.
function bestSession(){const a=[readJSON(SHARED_SESSION_KEY,null),readJSON(DRYER_SESSION_KEY,null),readJSON(CHEM_SESSION_KEY,null)].filter(x=>x&&x.access_token);a.sort((x,y)=>(Number(y.expires_at)||0)-(Number(x.expires_at)||0));return a[0]||null;}
let cloudConfig=Object.assign({},DEFAULT_CLOUD,readJSON(CLOUD_CONFIG_KEY,{}));let cloudSession=bestSession();let pending=readJSON(PENDING_KEY,[]);if(!Array.isArray(pending))pending=[];
function savePending(){writeJSON(PENDING_KEY,pending);}
function saveSession(s){cloudSession=s;if(s){writeJSON(SHARED_SESSION_KEY,s);writeJSON(DRYER_SESSION_KEY,s);writeJSON(CHEM_SESSION_KEY,s);}}
async function fetchTimed(url,opts={},timeout=25000){const ctrl=new AbortController(),tm=setTimeout(()=>ctrl.abort(),timeout);try{return await fetch(url,Object.assign({},opts,{signal:ctrl.signal}));}finally{clearTimeout(tm);}}
async function authRequest(path,opts={}){const h=Object.assign({'apikey':cloudConfig.key,'Content-Type':'application/json'},opts.headers||{}),r=await fetchTimed(cloudConfig.url.replace(/\/+$/,'')+path,Object.assign({},opts,{headers:h}));const t=await r.text();let j=null;try{j=t?JSON.parse(t):null;}catch(e){}if(!r.ok)throw new Error((j&&(j.message||j.msg||j.error_description))||t||('HTTP '+r.status));return j;}
async function refreshSession(){if(!cloudSession||!cloudSession.refresh_token)throw new Error('Нет общей сессии');const j=await authRequest('/auth/v1/token?grant_type=refresh_token',{method:'POST',body:JSON.stringify({refresh_token:cloudSession.refresh_token})});if(!j||!j.access_token)throw new Error('Не удалось обновить сессию');saveSession(j);return j;}
async function dataRequest(tableQuery,opts={},retried=false){if(!cloudSession||!cloudSession.access_token)throw new Error('Нет входа в общую базу');const h=Object.assign({'apikey':cloudConfig.key,'Authorization':'Bearer '+cloudSession.access_token,'Content-Type':'application/json'},opts.headers||{}),r=await fetchTimed(cloudConfig.url.replace(/\/+$/,'')+'/rest/v1/'+tableQuery,Object.assign({},opts,{headers:h}));if(r.status===401&&!retried){await refreshSession();return dataRequest(tableQuery,opts,true);}const t=await r.text();let j=null;try{j=t?JSON.parse(t):null;}catch(e){}if(!r.ok)throw new Error((j&&(j.message||j.error||j.hint))||t||('HTTP '+r.status));return j;}
function rowFor(type,x){
  if(type==='batches')return{client_id:x.clientId,crop:x.crop,recipe_name:x.recipeName,recipe_key:x.recipeKey,measurement_mode:modeOf(x),seed_tonnage:x.seedTonnage,total_mass_g:x.totalMassG,total_volume_ml:x.totalVolumeMl,dose_g_per_t:x.doseGPerT,dose_ml_per_t:x.doseMlPerT,components:x.components||[],status:x.status,notes:x.notes||null,created_at:x.createdAt,updated_at:x.updatedAt,deleted_at:x.deletedAt||null};
  if(type==='calibrations')return{client_id:x.clientId,batch_client_id:x.batchClientId,recipe_key:x.recipeKey,crop:x.crop,measurement_mode:modeOf(x),sm4_hz:x.sm4Hz,sm4_min_per_t:x.sm4MinPerT,required_flow_g_min:x.requiredFlowGMin,required_flow_ml_min:x.requiredFlowMlMin,pump_hz:x.pumpHz,duration_sec:x.durationSec,mass_before_g:x.massBeforeG,mass_after_g:x.massAfterG,test_volume_ml:x.testVolumeMl,actual_flow_g_min:x.actualFlowGMin,actual_flow_ml_min:x.actualFlowMlMin,error_pct:x.errorPct,accepted:!!x.accepted,occurred_at:x.occurredAt,notes:x.notes||null,created_at:x.createdAt,updated_at:x.updatedAt,deleted_at:x.deletedAt||null};
  if(type==='bags')return{client_id:x.clientId,run_client_id:x.runClientId,batch_client_id:x.batchClientId,crop:x.crop||'Соя',bag_no:x.bagNo,target_kg:x.targetKg,sm4_hz:x.sm4Hz,model_min_per_t:x.modelMinPerT,model_source:x.modelSource||null,model_confidence:x.modelConfidence||null,started_at:x.startedAt,ended_at:x.endedAt||null,paused_at:x.pausedAt||null,paused_duration_sec:x.pausedDurationSec||0,active_duration_sec:x.activeDurationSec,estimated_kg:x.estimatedKg,actual_net_kg:x.actualNetKg,actual_kg_min:x.actualKgMin,actual_min_per_t:x.actualMinPerT,deviation_pct:x.deviationPct,weight_recorded_at:x.weightRecordedAt||null,learning_status:x.learningStatus||'pending_weight',status:x.status||'completed',notes:x.notes||null,created_at:x.createdAt,updated_at:x.updatedAt,deleted_at:x.deletedAt||null};
  return{client_id:x.clientId,batch_client_id:x.batchClientId,recipe_key:x.recipeKey,crop:x.crop,measurement_mode:modeOf(x),seed_tonnage:x.seedTonnage,sm4_hz:x.sm4Hz,sm4_min_per_t:x.sm4MinPerT,planned_duration_min:x.plannedDurationMin,required_flow_g_min:x.requiredFlowGMin,required_flow_ml_min:x.requiredFlowMlMin,pump_hz:x.pumpHz,calibrated_flow_g_min:x.calibratedFlowGMin,calibrated_flow_ml_min:x.calibratedFlowMlMin,start_mass_g:x.startMassG,end_mass_g:x.endMassG,start_volume_ml:x.startVolumeMl,end_volume_ml:x.endVolumeMl,processed_tonnage:x.processedTonnage,checkpoints:x.checkpoints||[],started_at:x.startedAt,ended_at:x.endedAt,status:x.status,notes:x.notes||null,created_at:x.createdAt,updated_at:x.updatedAt,deleted_at:x.deletedAt||null};
}
function mapRemote(type,r){
  if(type==='batches')return{clientId:r.client_id,crop:r.crop,recipeName:r.recipe_name,recipeKey:r.recipe_key,measurementMode:r.measurement_mode||'mass',seedTonnage:Number(r.seed_tonnage),totalMassG:nullableNum(r.total_mass_g),totalVolumeMl:nullableNum(r.total_volume_ml),doseGPerT:nullableNum(r.dose_g_per_t),doseMlPerT:nullableNum(r.dose_ml_per_t),components:r.components||[],status:r.status,notes:r.notes||'',createdAt:r.created_at,updatedAt:r.updated_at,deletedAt:r.deleted_at};
  if(type==='calibrations')return{clientId:r.client_id,batchClientId:r.batch_client_id,recipeKey:r.recipe_key,crop:r.crop,measurementMode:r.measurement_mode||'mass',sm4Hz:Number(r.sm4_hz),sm4MinPerT:Number(r.sm4_min_per_t),requiredFlowGMin:nullableNum(r.required_flow_g_min),requiredFlowMlMin:nullableNum(r.required_flow_ml_min),pumpHz:Number(r.pump_hz),durationSec:Number(r.duration_sec),massBeforeG:nullableNum(r.mass_before_g),massAfterG:nullableNum(r.mass_after_g),testVolumeMl:nullableNum(r.test_volume_ml),actualFlowGMin:nullableNum(r.actual_flow_g_min),actualFlowMlMin:nullableNum(r.actual_flow_ml_min),errorPct:nullableNum(r.error_pct),accepted:!!r.accepted,occurredAt:r.occurred_at,notes:r.notes||'',createdAt:r.created_at,updatedAt:r.updated_at,deletedAt:r.deleted_at};
  if(type==='bags')return{clientId:r.client_id,runClientId:r.run_client_id,batchClientId:r.batch_client_id,crop:r.crop||'Соя',bagNo:Number(r.bag_no),targetKg:Number(r.target_kg),sm4Hz:Number(r.sm4_hz),modelMinPerT:Number(r.model_min_per_t),modelSource:r.model_source||'',modelConfidence:r.model_confidence||'',startedAt:r.started_at,endedAt:r.ended_at,pausedAt:r.paused_at,pausedDurationSec:Number(r.paused_duration_sec||0),activeDurationSec:nullableNum(r.active_duration_sec),estimatedKg:nullableNum(r.estimated_kg),actualNetKg:nullableNum(r.actual_net_kg),actualKgMin:nullableNum(r.actual_kg_min),actualMinPerT:nullableNum(r.actual_min_per_t),deviationPct:nullableNum(r.deviation_pct),weightRecordedAt:r.weight_recorded_at,learningStatus:r.learning_status||'pending_weight',status:r.status||'completed',notes:r.notes||'',createdAt:r.created_at,updatedAt:r.updated_at,deletedAt:r.deleted_at};
  return{clientId:r.client_id,batchClientId:r.batch_client_id,recipeKey:r.recipe_key,crop:r.crop,measurementMode:r.measurement_mode||'mass',seedTonnage:Number(r.seed_tonnage),sm4Hz:nullableNum(r.sm4_hz),sm4MinPerT:Number(r.sm4_min_per_t),plannedDurationMin:Number(r.planned_duration_min),requiredFlowGMin:nullableNum(r.required_flow_g_min),requiredFlowMlMin:nullableNum(r.required_flow_ml_min),pumpHz:nullableNum(r.pump_hz),calibratedFlowGMin:nullableNum(r.calibrated_flow_g_min),calibratedFlowMlMin:nullableNum(r.calibrated_flow_ml_min),startMassG:nullableNum(r.start_mass_g),endMassG:nullableNum(r.end_mass_g),startVolumeMl:nullableNum(r.start_volume_ml),endVolumeMl:nullableNum(r.end_volume_ml),processedTonnage:nullableNum(r.processed_tonnage),checkpoints:r.checkpoints||[],startedAt:r.started_at,endedAt:r.ended_at,status:r.status,notes:r.notes||'',createdAt:r.created_at,updatedAt:r.updated_at,deletedAt:r.deleted_at};
}
function queueRecord(type,x){pending=pending.filter(p=>!(p.type===type&&p.clientId===x.clientId));pending.push({type,clientId:x.clientId,row:rowFor(type,x)});savePending();}
async function flushPending(){if(!pending.length)return;const remain=[];for(const p of pending){try{await dataRequest(TABLES[p.type]+'?on_conflict=client_id',{method:'POST',headers:{Prefer:'resolution=merge-duplicates,missing=default,return=minimal'},body:JSON.stringify(p.row)});}catch(e){remain.push(p);}}pending=remain;savePending();}
function mergeByUpdated(local,remote){const m=new Map();[...local,...remote].forEach(x=>{if(!x||!x.clientId)return;const old=m.get(x.clientId);if(!old||String(x.updatedAt||'')>=String(old.updatedAt||''))m.set(x.clientId,x);});return Array.from(m.values());}
async function cloudSync(silent=false){
  if(cloudBusy||navigator.onLine===false)return false;if(!cloudSession||!cloudSession.access_token){cloudText='Облако не подключено в этом браузере. Локальная работа полностью доступна; вход можно выполнить в модуле Сушки или Склада химии.';if(!silent)renderHistory();return false;}
  cloudBusy=true;cloudText='Синхронизация…';if(!silent&&$('cloudStatus'))$('cloudStatus').textContent=cloudText;
  try{await flushPending();for(const type of ['batches','calibrations','bags','runs']){const rows=await dataRequest(TABLES[type]+'?select=*',{method:'GET'});state[type]=mergeByUpdated(state[type],(Array.isArray(rows)?rows:[]).map(r=>mapRemote(type,r)));}saveState();cloudText=pending.length?'Есть изменения, ожидающие отправки.':'Синхронизировано с общей базой.';if(!silent&&$('cloudStatus'))$('cloudStatus').textContent=cloudText;return true;}catch(e){cloudText='Облако недоступно. Данные сохранены локально и будут отправлены позже.';if(!silent&&$('cloudStatus'))$('cloudStatus').textContent=cloudText;return false;}finally{cloudBusy=false;if(routeStack[routeStack.length-1]==='history')renderHistory();}
}
$('syncNow').onclick=()=>cloudSync(false);

setInterval(()=>{updateCalTimer();updateWorkTimer();},1000);
setInterval(()=>{if(document.visibilityState==='visible'&&navigator.onLine!==false)cloudSync(true);},60000);

// Инициализация
renderComponents();setMixMode('mass');renderMixResult();ensureActiveBatch();renderCalibration();renderWork();renderHistory();
if(state.activeCal)renderCalState();
if(navigator.onLine!==false)setTimeout(()=>cloudSync(true),900);
})();
