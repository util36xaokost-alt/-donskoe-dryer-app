(function(){
'use strict';
const $=id=>document.getElementById(id);
const qsa=s=>Array.from(document.querySelectorAll(s));
const STATE_KEY='donskoe_connisseur_state_v1';
const PENDING_KEY='donskoe_connisseur_cloud_pending_v1';
const CLOUD_CONFIG_KEY='donskoe_dryer_cloud_config_v1';
const SHARED_SESSION_KEY='donskoe_cloud_session_shared_v1';
const DRYER_SESSION_KEY='donskoe_dryer_cloud_session_v1';
const CHEM_SESSION_KEY='donskoe_chem_cloud_session_v1';
const DEFAULT_CLOUD={url:'https://vschnaxezsceogewlmin.supabase.co',key:'sb_publishable_1SSHvNqBFudiE71JpzcyGQ_ZP-bNV9c'};
const TABLES={batches:'connisseur_batches',calibrations:'connisseur_calibrations',runs:'connisseur_runs'};
let routeStack=['home'];
let draftComponents=[{name:'',qty:'',unit:'л'}];
let pendingCalResult=null;
let historyTab='batches';
let cloudBusy=false;
let cloudText='Локальная история.';

function readJSON(key,fallback){try{const v=JSON.parse(localStorage.getItem(key)||'null');return v===null?fallback:v;}catch(e){return fallback;}}
function writeJSON(key,val){try{localStorage.setItem(key,JSON.stringify(val));}catch(e){}}
function uuid(){return (crypto&&crypto.randomUUID)?crypto.randomUUID():'c-'+Date.now().toString(36)+'-'+Math.random().toString(36).slice(2,10);}
function iso(){return new Date().toISOString();}
function fmt(v,d=1){if(v===null||v===undefined||!isFinite(Number(v)))return '—';return Number(v).toFixed(d).replace('.',',');}
function fmtKgG(g){return g>=1000?fmt(g/1000,3)+' кг':fmt(g,0)+' г';}
function clamp(v,a,b){return Math.max(a,Math.min(b,v));}
function esc(v){return String(v??'').replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));}
function duration(min){if(!isFinite(min))return '—';const m=Math.max(0,Math.round(min));return Math.floor(m/60)+' ч '+String(m%60).padStart(2,'0')+' мин';}
function normalize(s){return String(s||'').trim().toLowerCase().replace(/ё/g,'е').replace(/\s+/g,' ');}
function hashString(s){let h=2166136261;for(let i=0;i<s.length;i++){h^=s.charCodeAt(i);h=Math.imul(h,16777619);}return (h>>>0).toString(16).padStart(8,'0');}
function recipeKey(batchLike){
  const t=Number(batchLike.seedTonnage||batchLike.seed_tonnage||1)||1;
  const comps=(batchLike.components||[]).filter(x=>x&&normalize(x.name)).map(x=>({n:normalize(x.name),u:normalize(x.unit),p:(Number(x.qty)||0)/t})).sort((a,b)=>(a.n+a.u).localeCompare(b.n+b.u));
  const dose=Number(batchLike.doseGPerT||batchLike.dose_g_per_t||0)||0;
  const raw=[normalize(batchLike.recipeName||batchLike.recipe_name),normalize(batchLike.crop),Math.round(dose),...comps.map(x=>x.n+':'+x.u+':'+x.p.toFixed(5))].join('|');
  return 'r-'+hashString(raw);
}
function initialState(){return{batches:[],calibrations:[],runs:[],activeBatchId:null,activeRunId:null,activeCal:null,settings:{sm4Points:[{hz:29,minPerT:37},{hz:30,minPerT:36},{hz:31,minPerT:35},{hz:32,minPerT:34}]}};}
let state=Object.assign(initialState(),readJSON(STATE_KEY,{}));
state.batches=Array.isArray(state.batches)?state.batches:[];
state.calibrations=Array.isArray(state.calibrations)?state.calibrations:[];
state.runs=Array.isArray(state.runs)?state.runs:[];
state.settings=state.settings||initialState().settings;
function saveState(){writeJSON(STATE_KEY,state);}
function touch(o){o.updatedAt=iso();return o;}
function activeBatch(){return state.batches.find(x=>x.clientId===state.activeBatchId&&!x.deletedAt)||null;}
function latestBatch(){return state.batches.filter(x=>!x.deletedAt).sort((a,b)=>String(b.createdAt).localeCompare(String(a.createdAt)))[0]||null;}
function ensureActiveBatch(){if(!activeBatch()){const b=latestBatch();state.activeBatchId=b?b.clientId:null;saveState();}return activeBatch();}
function acceptedForBatch(batch){if(!batch)return null;return state.calibrations.filter(c=>!c.deletedAt&&c.accepted&&c.batchClientId===batch.clientId).sort((a,b)=>String(b.occurredAt).localeCompare(String(a.occurredAt)))[0]||null;}
function currentRun(){return state.runs.find(r=>r.clientId===state.activeRunId&&r.status==='running'&&!r.deletedAt)||null;}

function setNetwork(){const online=navigator.onLine!==false,p=$('networkPill');p.classList.toggle('online',online);p.classList.toggle('offline',!online);$('networkText').textContent=online?'Online':'Offline';}
window.addEventListener('online',()=>{setNetwork();cloudSync(true);});window.addEventListener('offline',setNetwork);setNetwork();
$('masterHome').addEventListener('click',()=>location.href='../index.html?skipSplash=1');

const titles={home:'ConNiSseur',mix:'Приготовить смесь',cal:'Калибровка',work:'Работа',history:'История'};
function showPage(name,push=true){
  if(!titles[name])name='home';
  qsa('.page').forEach(p=>p.classList.toggle('active',p.id==='page-'+name));
  $('subbar').classList.toggle('hidden',name==='home');$('pageTitle').textContent=titles[name];
  if(push&&routeStack[routeStack.length-1]!==name)routeStack.push(name);
  if(name==='mix')renderMix();if(name==='cal')renderCalibration();if(name==='work')renderWork();if(name==='history')renderHistory();
  window.scrollTo({top:0,behavior:'auto'});
}
function goBack(){if(routeStack.length>1){routeStack.pop();showPage(routeStack[routeStack.length-1],false);}else location.href='../index.html?skipSplash=1';}
$('backBtn').addEventListener('click',goBack);
qsa('[data-route]').forEach(b=>b.addEventListener('click',()=>showPage(b.dataset.route)));
let sx=0,sy=0,tracking=false;document.addEventListener('touchstart',e=>{const t=e.touches[0];if(t.clientX<28){sx=t.clientX;sy=t.clientY;tracking=true;}},{passive:true});document.addEventListener('touchend',e=>{if(!tracking)return;tracking=false;const t=e.changedTouches[0];if(t.clientX-sx>75&&Math.abs(t.clientY-sy)<70)goBack();},{passive:true});

function metric(label,value,sub=''){return `<div class="metric"><span>${esc(label)}</span><b>${esc(value)}</b>${sub?`<small>${esc(sub)}</small>`:''}</div>`;}

function renderComponents(){
  const host=$('componentsList');host.innerHTML='';
  if(!draftComponents.length)draftComponents=[{name:'',qty:'',unit:'л'}];
  draftComponents.forEach((c,i)=>{
    const row=document.createElement('div');row.className='componentRow';
    row.innerHTML=`<input data-cname="${i}" type="text" placeholder="Препарат / компонент" value="${esc(c.name)}"><input data-cqty="${i}" type="number" inputmode="decimal" step="0.001" min="0" placeholder="Кол-во" value="${esc(c.qty)}"><select data-cunit="${i}"><option>л</option><option>мл</option><option>кг</option><option>г</option></select><button data-cremove="${i}" class="removeComp" type="button">×</button>`;
    host.appendChild(row);row.querySelector('[data-cunit]').value=c.unit||'л';
  });
  host.querySelectorAll('[data-cname]').forEach(x=>x.oninput=()=>{draftComponents[+x.dataset.cname].name=x.value;renderMixResult();});
  host.querySelectorAll('[data-cqty]').forEach(x=>x.oninput=()=>{draftComponents[+x.dataset.cqty].qty=x.value;renderMixResult();});
  host.querySelectorAll('[data-cunit]').forEach(x=>x.onchange=()=>{draftComponents[+x.dataset.cunit].unit=x.value;renderMixResult();});
  host.querySelectorAll('[data-cremove]').forEach(x=>x.onclick=()=>{draftComponents.splice(+x.dataset.cremove,1);renderComponents();renderMixResult();});
}
$('addComponent').onclick=()=>{draftComponents.push({name:'',qty:'',unit:'л'});renderComponents();};
['mixTonnage','mixMassKg','mixVolumeL','mixName','mixCrop'].forEach(id=>$(id).addEventListener('input',renderMixResult));
function renderMix(){renderComponents();renderMixResult();}
function renderMixResult(){
  const t=Number($('mixTonnage').value),kg=Number($('mixMassKg').value),box=$('mixResult');
  if(!(t>0&&kg>0)){box.classList.add('hidden');return;}
  const doseKgT=kg/t,totalMin30=t*(66-30),flow30=kg*1000/totalMin30;
  box.className='resultCard';box.innerHTML=`<div class="resultTitle">Расчёт по фактической массе</div><div class="resultBig">${fmt(doseKgT,3)} кг/т</div><div class="metrics">${metric('Масса смеси',fmt(kg,3)+' кг')}${metric('Тоннаж',fmt(t,2)+' т')}${metric('При СМ-4 30 Гц',fmt(flow30,0)+' г/мин','ориентир до калибровки')}${metric('Время партии при 30 Гц',duration(totalMin30))}</div>`;
}
$('saveBatch').onclick=()=>{
  const crop=$('mixCrop').value,t=Number($('mixTonnage').value),kg=Number($('mixMassKg').value),vol=Number($('mixVolumeL').value)||null;
  if(!(t>0))return alert('Укажите тоннаж семян.');if(!(kg>0))return alert('Укажите фактическую массу готовой смеси по весам.');
  const components=draftComponents.filter(c=>normalize(c.name)&&Number(c.qty)>0).map(c=>({name:String(c.name).trim(),qty:Number(c.qty),unit:c.unit||'л'}));
  const recipeName=String($('mixName').value||'').trim()||(crop+' — рабочий состав');
  const b={clientId:uuid(),crop,recipeName,seedTonnage:t,totalMassG:kg*1000,totalVolumeMl:vol?vol*1000:null,doseGPerT:kg*1000/t,components,status:'prepared',notes:String($('mixNote').value||'').trim(),createdAt:iso(),updatedAt:iso()};b.recipeKey=recipeKey(b);
  state.batches.push(b);state.activeBatchId=b.clientId;saveState();queueRecord('batches',b);cloudSync(true);
  $('mixMassKg').value='';$('mixVolumeL').value='';$('mixNote').value='';draftComponents=[{name:'',qty:'',unit:'л'}];renderComponents();renderMixResult();showPage('cal');
};

function sm4Minutes(hz){return 66-Number(hz);}
function renderCalibration(){
  const b=ensureActiveBatch();$('calNoBatch').classList.toggle('hidden',!!b);$('calBody').classList.toggle('hidden',!b);if(!b)return;
  $('calBatchName').textContent=`${b.recipeName} · ${fmt(b.seedTonnage,2)} т`;
  $('calBatchMetrics').innerHTML=metric('Масса смеси',fmt(b.totalMassG/1000,3)+' кг')+metric('Доза',fmt(b.doseGPerT/1000,3)+' кг/т')+metric('Рецепт',b.recipeKey)+metric('Статус',statusRu(b.status));
  if(!$('sm4Hz').value)$('sm4Hz').value='30';if(!$('sm4MinPerT').value)$('sm4MinPerT').value=fmt(sm4Minutes($('sm4Hz').value),1).replace(',','.');
  renderCalPlan();renderCalState();
}
$('sm4Hz').addEventListener('input',()=>{const h=Number($('sm4Hz').value);if(isFinite(h))$('sm4MinPerT').value=Math.max(.1,sm4Minutes(h)).toFixed(1);renderCalPlan();});
$('sm4MinPerT').addEventListener('input',renderCalPlan);
function estimatePumpHz(target,recipeKeyValue){
  const pts=state.calibrations.filter(c=>!c.deletedAt&&c.accepted&&c.recipeKey===recipeKeyValue&&c.actualFlowGMin>0&&c.pumpHz>0).sort((a,b)=>a.actualFlowGMin-b.actualFlowGMin);
  if(!pts.length)return{hz:null,confidence:'Нет данных',points:0,text:'Первую частоту насоса задаёт оператор. После подтверждённых калибровок приложение начнёт предлагать стартовую частоту.'};
  if(pts.length===1){const p=pts[0],ratio=target/p.actualFlowGMin,hz=p.pumpHz*ratio,conf=(ratio>=.8&&ratio<=1.2)?'Средняя':'Низкая';return{hz,confidence:conf,points:1,text:`По одной подтверждённой точке: ${fmt(p.pumpHz,1)} Гц → ${fmt(p.actualFlowGMin,0)} г/мин. Новую частоту обязательно перепроверить на весах.`};}
  let lo=null,hi=null;for(let i=0;i<pts.length-1;i++){if(target>=pts[i].actualFlowGMin&&target<=pts[i+1].actualFlowGMin){lo=pts[i];hi=pts[i+1];break;}}
  let conf='Высокая';if(!lo){const near=[...pts].sort((a,b)=>Math.abs(a.actualFlowGMin-target)-Math.abs(b.actualFlowGMin-target)).slice(0,2).sort((a,b)=>a.actualFlowGMin-b.actualFlowGMin);lo=near[0];hi=near[1];const edge=target<pts[0].actualFlowGMin?pts[0].actualFlowGMin:pts[pts.length-1].actualFlowGMin;conf=Math.abs(target-edge)/Math.max(edge,1)<=.2?'Средняя':'Низкая';}
  const dy=hi.actualFlowGMin-lo.actualFlowGMin;let hz;if(Math.abs(dy)<.0001)hz=(lo.pumpHz+hi.pumpHz)/2;else hz=lo.pumpHz+(target-lo.actualFlowGMin)*(hi.pumpHz-lo.pumpHz)/dy;
  return{hz,confidence:conf,points:pts.length,text:`Использовано ${pts.length} подтверждённых калибровок этой смеси. ${conf==='Высокая'?'Цель находится между фактическими точками.':'Расчёт выходит за фактически измеренный диапазон — обязательна контрольная калибровка.'}`};
}
function calPlan(){const b=activeBatch();if(!b)return null;const hz=Number($('sm4Hz').value),mpt=Number($('sm4MinPerT').value);if(!(mpt>0))return null;const totalMin=b.seedTonnage*mpt,target=b.totalMassG/totalMin;return{batch:b,hz,mpt,totalMin,target,learn:estimatePumpHz(target,b.recipeKey)};}
function renderCalPlan(){
  const p=calPlan();if(!p)return;
  const baseMpt=sm4Minutes(p.hz),inKnownRange=p.hz>=29&&p.hz<=32,confirmed=inKnownRange&&Math.abs(p.mpt-baseMpt)<=0.25;
  $('sm4Hint').className='hint '+(confirmed?'good':'warn');
  if(confirmed)$('sm4Hint').textContent=`Подтверждённая кривая СМ‑4: ${fmt(p.hz,1)} Гц ≈ ${fmt(p.mpt,1)} мин/т. Базовые точки: 29→37, 30→36, 31→35, 32→34 мин/т.`;
  else if(inKnownRange)$('sm4Hint').textContent=`Для ${fmt(p.hz,1)} Гц базовая кривая даёт ≈ ${fmt(baseMpt,1)} мин/т, а введено ${fmt(p.mpt,1)}. В расчёте будет использовано введённое оператором значение как фактическое; проверьте производительность СМ‑4.`;
  else $('sm4Hint').textContent=`${fmt(p.hz,1)} Гц находится вне подтверждённого диапазона 29–32 Гц. Введённые ${fmt(p.mpt,1)} мин/т используются только как рабочий ориентир и должны быть уточнены фактически.`;
  $('flowMetrics').innerHTML=metric('Требуемая подача',fmt(p.target,0)+' г/мин')+metric('Время партии',duration(p.totalMin))+metric('СМ‑4',fmt(p.hz,1)+' Гц')+metric('Мин/т',fmt(p.mpt,1));
  const l=p.learn;$('learningHint').className='hint '+(l.confidence==='Высокая'?'good':l.confidence==='Нет данных'?'':l.confidence==='Средняя'?'warn':'bad');$('learningHint').innerHTML=`<b>${esc(l.confidence==='Нет данных'?'Стартовая частота пока не рассчитана':`Подсказка: ${fmt(l.hz,1)} Гц · ${l.confidence} опора`)}</b><br>${esc(l.text)}`;
  if(l.hz!==null&&!$('pumpHz').value)$('pumpHz').value=(Math.round(l.hz*10)/10).toFixed(1);
}
$('changeBatchCal').onclick=openBatchPicker;
function openBatchPicker(){const list=$('batchPickerList'),rows=state.batches.filter(b=>!b.deletedAt).sort((a,b)=>String(b.createdAt).localeCompare(String(a.createdAt)));list.innerHTML=rows.length?'':'<div class="empty">Нет сохранённых партий.</div>';rows.forEach(b=>{const btn=document.createElement('button');btn.className='batchPick';btn.innerHTML=`<b>${esc(b.recipeName)}</b><small>${esc(b.crop)} · ${fmt(b.seedTonnage,2)} т · ${fmt(b.totalMassG/1000,3)} кг · ${esc(statusRu(b.status))}</small>`;btn.onclick=()=>{state.activeBatchId=b.clientId;saveState();closeBatchPicker();renderCalibration();renderWork();};list.appendChild(btn);});$('batchPickerShade').classList.remove('hidden');}
function closeBatchPicker(){$('batchPickerShade').classList.add('hidden');}$('closeBatchPicker').onclick=closeBatchPicker;$('batchPickerShade').onclick=e=>{if(e.target===$('batchPickerShade'))closeBatchPicker();};
function renderCalState(){
  const a=state.activeCal;if(!a||a.batchClientId!==state.activeBatchId){$('calRunning').classList.add('hidden');$('calIdleButtons').classList.remove('hidden');$('calFinish').classList.add('hidden');return;}
  $('calIdleButtons').classList.add('hidden');
  if(!a.stoppedAt){$('calRunning').classList.remove('hidden');$('calFinish').classList.add('hidden');}
  else{$('calRunning').classList.add('hidden');$('calFinish').classList.remove('hidden');}
  updateCalTimer();
}
$('startCal').onclick=()=>{
  const p=calPlan(),pump=Number($('pumpHz').value),before=Number($('calMassBefore').value);if(!p)return alert('Проверьте режим СМ‑4.');if(!(pump>0))return alert('Укажите частоту насоса.');if(!(before>0))return alert('Введите массу ёмкости перед тестом.');
  state.activeCal={batchClientId:p.batch.clientId,startedAt:Date.now(),stoppedAt:null,pumpHz:pump,massBeforeKg:before,requiredFlowGMin:p.target,sm4Hz:p.hz,sm4MinPerT:p.mpt};pendingCalResult=null;const b=p.batch;b.status='calibrating';touch(b);saveState();queueRecord('batches',b);renderCalState();
};
$('stopCal').onclick=()=>{if(!state.activeCal||state.activeCal.stoppedAt)return;state.activeCal.stoppedAt=Date.now();saveState();renderCalState();$('calMassAfter').focus();};
function updateCalTimer(){const a=state.activeCal;if(!a||a.batchClientId!==state.activeBatchId)return;const end=a.stoppedAt||Date.now(),sec=Math.max(0,(end-a.startedAt)/1000),mm=Math.floor(sec/60),ss=Math.floor(sec%60);$('calTimer').textContent=String(mm).padStart(2,'0')+':'+String(ss).padStart(2,'0');const loss=a.requiredFlowGMin*(sec/60)/1000;$('calTargetLoss').textContent='Целевая потеря массы к этому моменту: '+fmt(loss,3)+' кг'+(sec>=600?' · 10 минут достигнуты — завершите контроль.':'');}
$('calcCalResult').onclick=()=>{
  const a=state.activeCal,after=Number($('calMassAfter').value);if(!a||!a.stoppedAt)return alert('Сначала завершите контроль.');if(!(after>0))return alert('Введите массу ёмкости после теста.');if(after>=a.massBeforeKg)return alert('Масса после теста должна быть меньше массы до теста.');
  const sec=(a.stoppedAt-a.startedAt)/1000,min=sec/60,lossKg=a.massBeforeKg-after,actual=lossKg*1000/min,error=(actual-a.requiredFlowGMin)/a.requiredFlowGMin*100,next=a.pumpHz*(a.requiredFlowGMin/actual);pendingCalResult={durationSec:sec,massAfterKg:after,lossKg,actualFlowGMin:actual,errorPct:error,suggestedNextHz:next};
  const short=sec<120,long=sec>600,cls=Math.abs(error)<=5?'':Math.abs(error)<=12?'warn':'bad';const box=$('calResultBox');box.className='resultCard '+cls;box.innerHTML=`<div class="resultTitle">Фактическая массовая подача</div><div class="resultBig">${fmt(actual,0)} г/мин</div><div class="metrics">${metric('Требуется',fmt(a.requiredFlowGMin,0)+' г/мин')}${metric('Ошибка',(error>=0?'+':'')+fmt(error,1)+' %')}${metric('Потеря массы',fmt(lossKg,3)+' кг')}${metric('Интервал',fmt(min,2)+' мин')}</div><div class="resultText" style="margin-top:12px">Расчётный следующий шаг: <b>${fmt(next,1)} Гц</b>. Это только подсказка — новую частоту нужно снова проверить на весах.${short?' Контроль короче 2 минут: точность оценки ниже.':''}${long?' Контроль превысил 10 минут: для следующей попытки достаточно более короткого интервала.':''}</div>`;box.classList.remove('hidden');$('calDecisionButtons').classList.remove('hidden');
};
function saveCalibration(accepted){
  const a=state.activeCal,r=pendingCalResult,b=activeBatch();if(!a||!r||!b)return;
  const c={clientId:uuid(),batchClientId:b.clientId,recipeKey:b.recipeKey,crop:b.crop,sm4Hz:a.sm4Hz,sm4MinPerT:a.sm4MinPerT,requiredFlowGMin:a.requiredFlowGMin,pumpHz:a.pumpHz,durationSec:r.durationSec,massBeforeG:a.massBeforeKg*1000,massAfterG:r.massAfterKg*1000,actualFlowGMin:r.actualFlowGMin,errorPct:r.errorPct,accepted:!!accepted,occurredAt:iso(),notes:'',createdAt:iso(),updatedAt:iso()};
  state.calibrations.push(c);queueRecord('calibrations',c);
  if(accepted){b.status='ready';touch(b);queueRecord('batches',b);}else{b.status='prepared';touch(b);queueRecord('batches',b);}
  const next=r.suggestedNextHz;state.activeCal=null;pendingCalResult=null;saveState();$('calMassAfter').value='';$('calMassBefore').value='';$('calResultBox').classList.add('hidden');$('calDecisionButtons').classList.add('hidden');if(!accepted&&isFinite(next))$('pumpHz').value=(Math.round(next*10)/10).toFixed(1);cloudSync(true);if(accepted)showPage('work');else renderCalibration();
}
$('acceptCal').onclick=()=>{if(pendingCalResult&&Math.abs(pendingCalResult.errorPct)>12&&!confirm(`Отклонение ${fmt(Math.abs(pendingCalResult.errorPct),1)}%. Принять эту калибровку как рабочую?`))return;saveCalibration(true);};$('repeatCal').onclick=()=>saveCalibration(false);

function renderWork(){
  const b=ensureActiveBatch(),cal=acceptedForBatch(b);$('workNoReady').classList.toggle('hidden',!!(b&&cal));$('workBody').classList.toggle('hidden',!(b&&cal));if(!(b&&cal))return;
  $('workMetrics').innerHTML=metric('Партия',b.recipeName)+metric('Семена',fmt(b.seedTonnage,2)+' т')+metric('Доза смеси',fmt(b.doseGPerT/1000,3)+' кг/т')+metric('СМ‑4',fmt(cal.sm4Hz,1)+' Гц · '+fmt(cal.sm4MinPerT,1)+' мин/т')+metric('Насос',fmt(cal.pumpHz,1)+' Гц')+metric('Требуемая подача',fmt(cal.requiredFlowGMin,0)+' г/мин')+metric('Калибр. подача',fmt(cal.actualFlowGMin,0)+' г/мин')+metric('Ошибка калибровки',(cal.errorPct>=0?'+':'')+fmt(cal.errorPct,1)+' %')+metric('Плановое время',duration(b.seedTonnage*cal.sm4MinPerT));
  const safety=$('workMetrics').nextElementSibling;if(safety&&safety.classList.contains('safetyInline'))safety.textContent=Math.abs(cal.errorPct)>5?`Калибровка отличается от требуемой подачи на ${(cal.errorPct>=0?'+':'')+fmt(cal.errorPct,1)}%. Во время работы чаще контролируйте массу; при возможности повторите калибровку.`:'Режим является расчётным ориентиром. Приложение не включает и не отключает оборудование.';
  let run=currentRun();if(run&&run.batchClientId!==b.clientId){state.activeRunId=null;saveState();run=null;}
  $('workStartCard').classList.toggle('hidden',!!run);$('workRunningCard').classList.toggle('hidden',!run);if(run){$('workProcessedT').value=run.processedTonnage||b.seedTonnage;renderCheckpoints(run);updateWorkTimer();}
}
$('startWork').onclick=()=>{
  const b=activeBatch(),cal=acceptedForBatch(b),mass=Number($('workMassStart').value);if(!(b&&cal))return alert('Нет подтверждённой калибровки.');if(!(mass>0))return alert('Введите массу ёмкости перед работой.');
  const r={clientId:uuid(),batchClientId:b.clientId,recipeKey:b.recipeKey,crop:b.crop,seedTonnage:b.seedTonnage,sm4Hz:cal.sm4Hz,sm4MinPerT:cal.sm4MinPerT,plannedDurationMin:b.seedTonnage*cal.sm4MinPerT,requiredFlowGMin:cal.requiredFlowGMin,pumpHz:cal.pumpHz,calibratedFlowGMin:cal.actualFlowGMin,startMassG:mass*1000,endMassG:null,processedTonnage:null,checkpoints:[],startedAt:iso(),endedAt:null,status:'running',notes:'',createdAt:iso(),updatedAt:iso()};
  state.runs.push(r);state.activeRunId=r.clientId;b.status='running';touch(b);saveState();queueRecord('runs',r);queueRecord('batches',b);cloudSync(true);renderWork();
};
function elapsedRunMin(run){return run&&run.startedAt?(Date.now()-new Date(run.startedAt).getTime())/60000:0;}
function updateWorkTimer(){const r=currentRun();if(!r)return;const min=Math.max(0,elapsedRunMin(r)),sec=Math.floor(min*60),mm=Math.floor(sec/60),ss=sec%60;$('workTimer').textContent=String(mm).padStart(2,'0')+':'+String(ss).padStart(2,'0');const remain=r.plannedDurationMin-min,end=new Date(new Date(r.startedAt).getTime()+r.plannedDurationMin*60000);$('workRemain').textContent=(remain>0?'Осталось по расчёту '+duration(remain)+' · ':'Расчётное время партии достигнуто · ')+'ориентир '+end.toLocaleTimeString('ru-RU',{hour:'2-digit',minute:'2-digit'});$('workProgress').querySelector('i').style.width=clamp(min/r.plannedDurationMin*100,0,100)+'%';}
$('addCheckpoint').onclick=()=>{
  const r=currentRun(),mass=Number($('checkpointMass').value);if(!r)return;if(!(mass>0))return alert('Введите текущее показание весов.');if(mass*1000>r.startMassG)return alert('Текущая масса не может быть больше стартовой.');
  const em=elapsedRunMin(r),used=r.startMassG-mass*1000,expected=r.requiredFlowGMin*em,calExpected=r.calibratedFlowGMin*em,dev=expected>0?(used-expected)/expected*100:0,avgFlow=em>0?used/em:null,cp={at:iso(),massG:mass*1000,elapsedMin:em,usedG:used,expectedG:expected,deviationPct:dev};r.checkpoints=r.checkpoints||[];r.checkpoints.push(cp);touch(r);saveState();queueRecord('runs',r);cloudSync(true);const cls=Math.abs(dev)<=5?'good':Math.abs(dev)<=12?'warn':'bad';$('checkpointResult').className='hint '+cls;$('checkpointResult').innerHTML=`Использовано <b>${fmtKgG(used)}</b>, по целевой дозе должно быть ${fmtKgG(expected)}. Отклонение ${(dev>=0?'+':'')+fmt(dev,1)}%.${avgFlow!==null?' Средняя фактическая подача: <b>'+fmt(avgFlow,0)+' г/мин</b>.':''}${isFinite(calExpected)&&Math.abs(r.calibratedFlowGMin-r.requiredFlowGMin)>1?' Калибровка прогнозировала '+fmtKgG(calExpected)+' к этому моменту.':''}`;renderCheckpoints(r);$('checkpointMass').value='';
};
function renderCheckpoints(r){const host=$('checkpointsList');host.innerHTML='';(r.checkpoints||[]).slice().reverse().forEach(cp=>{const d=document.createElement('div');d.className='checkpointRow';d.innerHTML=`<div><b>${new Date(cp.at).toLocaleTimeString('ru-RU',{hour:'2-digit',minute:'2-digit'})}</b><br><span>${fmt(cp.massG/1000,3)} кг на весах</span></div><div style="text-align:right"><b>${(cp.deviationPct>=0?'+':'')+fmt(cp.deviationPct,1)}%</b><br><span>к расчёту</span></div>`;host.appendChild(d);});}
$('finishWork').onclick=()=>{
  const r=currentRun(),b=activeBatch(),endKg=Number($('workMassEnd').value),processed=Number($('workProcessedT').value);if(!r)return;if(!(endKg>0))return alert('Введите финальную массу ёмкости.');if(endKg*1000>r.startMassG)return alert('Финальная масса не может быть больше стартовой.');
  r.endMassG=endKg*1000;r.processedTonnage=processed>0?processed:b.seedTonnage;r.endedAt=iso();r.status='completed';touch(r);b.status='completed';touch(b);state.activeRunId=null;saveState();queueRecord('runs',r);queueRecord('batches',b);cloudSync(true);const elapsed=(new Date(r.endedAt)-new Date(r.startedAt))/60000,used=r.startMassG-r.endMassG,flow=elapsed>0?used/elapsed:null,actualDose=r.processedTonnage>0?used/r.processedTonnage:null,doseErr=actualDose!==null&&b.doseGPerT>0?(actualDose-b.doseGPerT)/b.doseGPerT*100:null;alert(`Работа сохранена.\nФактический расход: ${fmt(used/1000,3)} кг.\nФактическая доза: ${fmt(actualDose/1000,3)} кг/т (${doseErr>=0?'+':''}${fmt(doseErr,1)}% к расчёту).\nСредняя подача: ${fmt(flow,0)} г/мин.`);$('workMassStart').value='';$('workMassEnd').value='';renderWork();
};

function statusRu(s){return({prepared:'смесь готова',calibrating:'калибровка',ready:'готово к работе',running:'в работе',completed:'завершено',cancelled:'отменено',planned:'запланировано'}[s]||s||'—');}
function renderHistory(){
  qsa('[data-history-tab]').forEach(b=>b.classList.toggle('active',b.dataset.historyTab===historyTab));
  const accepted=state.calibrations.filter(c=>c.accepted&&!c.deletedAt),recipes=new Set(accepted.map(c=>c.recipeKey));$('learningSummary').innerHTML=metric('Подтверждённых точек',String(accepted.length))+metric('Изученных рецептов',String(recipes.size))+metric('Партий',String(state.batches.filter(x=>!x.deletedAt).length))+metric('Работ',String(state.runs.filter(x=>x.status==='completed'&&!x.deletedAt).length));$('cloudStatus').textContent=cloudText;
  const host=$('historyList');host.innerHTML='';let arr=[];
  if(historyTab==='batches')arr=state.batches.filter(x=>!x.deletedAt).sort((a,b)=>String(b.createdAt).localeCompare(String(a.createdAt)));
  if(historyTab==='calibrations')arr=state.calibrations.filter(x=>!x.deletedAt).sort((a,b)=>String(b.occurredAt).localeCompare(String(a.occurredAt)));
  if(historyTab==='runs')arr=state.runs.filter(x=>!x.deletedAt).sort((a,b)=>String(b.startedAt||b.createdAt).localeCompare(String(a.startedAt||a.createdAt)));
  if(!arr.length){host.innerHTML='<div class="empty">Записей пока нет.</div>';return;}
  arr.forEach(x=>host.appendChild(historyCard(x,historyTab)));
}
qsa('[data-history-tab]').forEach(b=>b.onclick=()=>{historyTab=b.dataset.historyTab;renderHistory();});
function historyCard(x,type){const d=document.createElement('article');d.className='historyCard';if(type==='batches'){d.innerHTML=`<div class="historyTop"><h3>${esc(x.recipeName)}</h3><span class="badge">${esc(statusRu(x.status))}</span></div><div class="historyMeta"><div>Культура: <b>${esc(x.crop)}</b></div><div>Тоннаж: <b>${fmt(x.seedTonnage,2)} т</b></div><div>Масса: <b>${fmt(x.totalMassG/1000,3)} кг</b></div><div>Доза: <b>${fmt(x.doseGPerT/1000,3)} кг/т</b></div></div>`;}
  else if(type==='calibrations'){d.innerHTML=`<div class="historyTop"><h3>${fmt(x.pumpHz,1)} Гц → ${fmt(x.actualFlowGMin,0)} г/мин</h3><span class="badge ${x.accepted?'good':'warn'}">${x.accepted?'принято':'попытка'}</span></div><div class="historyMeta"><div>Требовалось: <b>${fmt(x.requiredFlowGMin,0)} г/мин</b></div><div>Ошибка: <b>${(x.errorPct>=0?'+':'')+fmt(x.errorPct,1)}%</b></div><div>СМ‑4: <b>${fmt(x.sm4Hz,1)} Гц</b></div><div>Интервал: <b>${fmt(x.durationSec/60,2)} мин</b></div></div>`;}
  else{const used=x.startMassG&&x.endMassG!==null?(x.startMassG-x.endMassG):null,tons=Number(x.processedTonnage||x.seedTonnage)||0,actualDose=used!==null&&tons>0?used/tons:null;d.innerHTML=`<div class="historyTop"><h3>${esc(x.crop||'Работа')}</h3><span class="badge ${x.status==='completed'?'good':''}">${esc(statusRu(x.status))}</span></div><div class="historyMeta"><div>Семена: <b>${fmt(tons,2)} т</b></div><div>Насос: <b>${fmt(x.pumpHz,1)} Гц</b></div><div>Подача: <b>${fmt(x.calibratedFlowGMin,0)} г/мин</b></div><div>Факт. расход: <b>${used===null?'—':fmt(used/1000,3)+' кг'}</b></div><div>Факт. доза: <b>${actualDose===null?'—':fmt(actualDose/1000,3)+' кг/т'}</b></div></div>`;}
  return d;}

// Облако: используем ту же авторизацию, что сушилка и склад химии. Ядро приложения от сети не зависит.
function bestSession(){const a=[readJSON(SHARED_SESSION_KEY,null),readJSON(DRYER_SESSION_KEY,null),readJSON(CHEM_SESSION_KEY,null)].filter(x=>x&&x.access_token);a.sort((x,y)=>(Number(y.expires_at)||0)-(Number(x.expires_at)||0));return a[0]||null;}
let cloudConfig=Object.assign({},DEFAULT_CLOUD,readJSON(CLOUD_CONFIG_KEY,{}));let cloudSession=bestSession();let pending=readJSON(PENDING_KEY,[]);if(!Array.isArray(pending))pending=[];
function savePending(){writeJSON(PENDING_KEY,pending);}
function saveSession(s){cloudSession=s;if(s){writeJSON(SHARED_SESSION_KEY,s);writeJSON(DRYER_SESSION_KEY,s);writeJSON(CHEM_SESSION_KEY,s);}}
async function fetchTimed(url,opts={},timeout=25000){const ctrl=new AbortController(),tm=setTimeout(()=>ctrl.abort(),timeout);try{return await fetch(url,Object.assign({},opts,{signal:ctrl.signal}));}finally{clearTimeout(tm);}}
async function authRequest(path,opts={}){const h=Object.assign({'apikey':cloudConfig.key,'Content-Type':'application/json'},opts.headers||{}),r=await fetchTimed(cloudConfig.url.replace(/\/+$/,'')+path,Object.assign({},opts,{headers:h}));const t=await r.text();let j=null;try{j=t?JSON.parse(t):null;}catch(e){}if(!r.ok)throw new Error((j&&(j.message||j.msg||j.error_description))||t||('HTTP '+r.status));return j;}
async function refreshSession(){if(!cloudSession||!cloudSession.refresh_token)throw new Error('Нет общей сессии');const j=await authRequest('/auth/v1/token?grant_type=refresh_token',{method:'POST',body:JSON.stringify({refresh_token:cloudSession.refresh_token})});if(!j||!j.access_token)throw new Error('Не удалось обновить сессию');saveSession(j);return j;}
async function dataRequest(tableQuery,opts={},retried=false){if(!cloudSession||!cloudSession.access_token)throw new Error('Нет входа в общую базу');const h=Object.assign({'apikey':cloudConfig.key,'Authorization':'Bearer '+cloudSession.access_token,'Content-Type':'application/json'},opts.headers||{}),r=await fetchTimed(cloudConfig.url.replace(/\/+$/,'')+'/rest/v1/'+tableQuery,Object.assign({},opts,{headers:h}));if(r.status===401&&!retried){await refreshSession();return dataRequest(tableQuery,opts,true);}const t=await r.text();let j=null;try{j=t?JSON.parse(t):null;}catch(e){}if(!r.ok)throw new Error((j&&(j.message||j.error||j.hint))||t||('HTTP '+r.status));return j;}
function rowFor(type,x){
  if(type==='batches')return{client_id:x.clientId,crop:x.crop,recipe_name:x.recipeName,recipe_key:x.recipeKey,seed_tonnage:x.seedTonnage,total_mass_g:x.totalMassG,total_volume_ml:x.totalVolumeMl,dose_g_per_t:x.doseGPerT,components:x.components||[],status:x.status,notes:x.notes||null,created_at:x.createdAt,updated_at:x.updatedAt,deleted_at:x.deletedAt||null};
  if(type==='calibrations')return{client_id:x.clientId,batch_client_id:x.batchClientId,recipe_key:x.recipeKey,crop:x.crop,sm4_hz:x.sm4Hz,sm4_min_per_t:x.sm4MinPerT,required_flow_g_min:x.requiredFlowGMin,pump_hz:x.pumpHz,duration_sec:x.durationSec,mass_before_g:x.massBeforeG,mass_after_g:x.massAfterG,actual_flow_g_min:x.actualFlowGMin,error_pct:x.errorPct,accepted:!!x.accepted,occurred_at:x.occurredAt,notes:x.notes||null,created_at:x.createdAt,updated_at:x.updatedAt,deleted_at:x.deletedAt||null};
  return{client_id:x.clientId,batch_client_id:x.batchClientId,recipe_key:x.recipeKey,crop:x.crop,seed_tonnage:x.seedTonnage,sm4_hz:x.sm4Hz,sm4_min_per_t:x.sm4MinPerT,planned_duration_min:x.plannedDurationMin,required_flow_g_min:x.requiredFlowGMin,pump_hz:x.pumpHz,calibrated_flow_g_min:x.calibratedFlowGMin,start_mass_g:x.startMassG,end_mass_g:x.endMassG,processed_tonnage:x.processedTonnage,checkpoints:x.checkpoints||[],started_at:x.startedAt,ended_at:x.endedAt,status:x.status,notes:x.notes||null,created_at:x.createdAt,updated_at:x.updatedAt,deleted_at:x.deletedAt||null};
}
function mapRemote(type,r){
  if(type==='batches')return{clientId:r.client_id,crop:r.crop,recipeName:r.recipe_name,recipeKey:r.recipe_key,seedTonnage:Number(r.seed_tonnage),totalMassG:Number(r.total_mass_g),totalVolumeMl:r.total_volume_ml===null?null:Number(r.total_volume_ml),doseGPerT:Number(r.dose_g_per_t),components:r.components||[],status:r.status,notes:r.notes||'',createdAt:r.created_at,updatedAt:r.updated_at,deletedAt:r.deleted_at};
  if(type==='calibrations')return{clientId:r.client_id,batchClientId:r.batch_client_id,recipeKey:r.recipe_key,crop:r.crop,sm4Hz:Number(r.sm4_hz),sm4MinPerT:Number(r.sm4_min_per_t),requiredFlowGMin:Number(r.required_flow_g_min),pumpHz:Number(r.pump_hz),durationSec:Number(r.duration_sec),massBeforeG:Number(r.mass_before_g),massAfterG:Number(r.mass_after_g),actualFlowGMin:Number(r.actual_flow_g_min),errorPct:Number(r.error_pct),accepted:!!r.accepted,occurredAt:r.occurred_at,notes:r.notes||'',createdAt:r.created_at,updatedAt:r.updated_at,deletedAt:r.deleted_at};
  return{clientId:r.client_id,batchClientId:r.batch_client_id,recipeKey:r.recipe_key,crop:r.crop,seedTonnage:Number(r.seed_tonnage),sm4Hz:Number(r.sm4_hz),sm4MinPerT:Number(r.sm4_min_per_t),plannedDurationMin:Number(r.planned_duration_min),requiredFlowGMin:Number(r.required_flow_g_min),pumpHz:r.pump_hz===null?null:Number(r.pump_hz),calibratedFlowGMin:r.calibrated_flow_g_min===null?null:Number(r.calibrated_flow_g_min),startMassG:r.start_mass_g===null?null:Number(r.start_mass_g),endMassG:r.end_mass_g===null?null:Number(r.end_mass_g),processedTonnage:r.processed_tonnage===null?null:Number(r.processed_tonnage),checkpoints:r.checkpoints||[],startedAt:r.started_at,endedAt:r.ended_at,status:r.status,notes:r.notes||'',createdAt:r.created_at,updatedAt:r.updated_at,deletedAt:r.deleted_at};
}
function queueRecord(type,x){pending=pending.filter(p=>!(p.type===type&&p.clientId===x.clientId));pending.push({type,clientId:x.clientId,row:rowFor(type,x)});savePending();}
async function flushPending(){if(!pending.length)return;const remain=[];for(const p of pending){try{await dataRequest(TABLES[p.type]+'?on_conflict=client_id',{method:'POST',headers:{Prefer:'resolution=merge-duplicates,missing=default,return=minimal'},body:JSON.stringify(p.row)});}catch(e){remain.push(p);}}pending=remain;savePending();}
function mergeByUpdated(local,remote){const m=new Map();[...local,...remote].forEach(x=>{if(!x||!x.clientId)return;const old=m.get(x.clientId);if(!old||String(x.updatedAt||'')>=String(old.updatedAt||''))m.set(x.clientId,x);});return Array.from(m.values()).filter(x=>!x.deletedAt);}
async function cloudSync(silent=false){
  if(cloudBusy||navigator.onLine===false)return false;if(!cloudSession||!cloudSession.access_token){cloudText='Облако не подключено в этом браузере. Локальная работа полностью доступна; вход можно выполнить в модуле Сушки или Склада химии.';if(!silent)renderHistory();return false;}
  cloudBusy=true;cloudText='Синхронизация…';if(!silent&&$('cloudStatus'))$('cloudStatus').textContent=cloudText;
  try{await flushPending();for(const type of ['batches','calibrations','runs']){const rows=await dataRequest(TABLES[type]+'?select=*&deleted_at=is.null',{method:'GET'});state[type]=mergeByUpdated(state[type],(Array.isArray(rows)?rows:[]).map(r=>mapRemote(type,r)));}saveState();cloudText=pending.length?'Есть изменения, ожидающие отправки.':'Синхронизировано с общей базой.';if(!silent&&$('cloudStatus'))$('cloudStatus').textContent=cloudText;return true;}catch(e){cloudText='Облако недоступно. Данные сохранены локально и будут отправлены позже.';if(!silent&&$('cloudStatus'))$('cloudStatus').textContent=cloudText;return false;}finally{cloudBusy=false;if(routeStack[routeStack.length-1]==='history')renderHistory();}
}
$('syncNow').onclick=()=>cloudSync(false);

setInterval(()=>{updateCalTimer();updateWorkTimer();},1000);
setInterval(()=>{if(document.visibilityState==='visible'&&navigator.onLine!==false)cloudSync(true);},60000);

// Инициализация
renderComponents();renderMixResult();ensureActiveBatch();renderCalibration();renderWork();renderHistory();
if(state.activeCal)renderCalState();
if(navigator.onLine!==false)setTimeout(()=>cloudSync(true),900);
})();
