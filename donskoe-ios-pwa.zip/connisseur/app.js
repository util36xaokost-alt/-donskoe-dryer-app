(function(){
'use strict';
const $=id=>document.getElementById(id);
const qsa=s=>Array.from(document.querySelectorAll(s));
const STATE_SCHEMA=4;
const STATE_BACKUP_KEY='donskoe_connisseur_state_backup_v1',STATE_BACKUP2_KEY='donskoe_connisseur_state_backup2_v1';
const STATE_KEY='donskoe_connisseur_state_v1';
const PENDING_KEY='donskoe_connisseur_cloud_pending_v1';
const CLOUD_CONFIG_KEY='donskoe_dryer_cloud_config_v1';
const SHARED_SESSION_KEY='donskoe_cloud_session_shared_v1';
const DRYER_SESSION_KEY='donskoe_dryer_cloud_session_v1';
const CHEM_SESSION_KEY='donskoe_chem_cloud_session_v1';
const DEFAULT_CLOUD={url:'https://vschnaxezsceogewlmin.supabase.co',key:'sb_publishable_1SSHvNqBFudiE71JpzcyGQ_ZP-bNV9c'};
const TABLES={batches:'connisseur_batches',calibrations:'connisseur_calibrations',runs:'connisseur_runs',bags:'connisseur_bag_cycles'};
let routeStack=['home'];
let draftComponents=[{name:'',qty:'',unit:'л'}];
let pendingCalResult=null;
let historyTab='batches';
let cloudBusy=false;
let cloudText='Локальная история.';
let sm4ManualEdit=false;

function readJSON(key,fallback){const value=DonskoeCore.read(key,fallback);return value===null?fallback:value;}
function writeJSON(key,val){return DonskoeCore.write(key,val);}
function uuid(){return (crypto&&crypto.randomUUID)?crypto.randomUUID():'c-'+Date.now().toString(36)+'-'+Math.random().toString(36).slice(2,10);}
function iso(){return new Date().toISOString();}
function fmt(v,d=1){if(v===null||v===undefined||!isFinite(Number(v)))return '—';return Number(v).toFixed(d).replace('.',',');}
function fmtInt(v){if(v===null||v===undefined||!isFinite(Number(v)))return '—';return new Intl.NumberFormat('ru-RU',{maximumFractionDigits:0}).format(Math.round(Number(v)));}
function fmtG(g){return fmtInt(g)+' г';}
function fmtMl(ml){return ml>=1000?fmt(ml/1000,3)+' л':fmt(ml,0)+' мл';}
function modeOf(x){return x&&x.measurementMode==='volume'?'volume':'mass';}
function flowUnit(mode){return mode==='volume'?'мл/мин':'г/мин';}
function measureUnit(mode){return mode==='volume'?'мл':'г';}
function flowValue(x){const v=modeOf(x)==='volume'?x&&x.actualFlowMlMin:x&&x.actualFlowGMin;return v===null||v===undefined||v===''?null:Number(v);}
function requiredFlow(x){const v=modeOf(x)==='volume'?x&&x.requiredFlowMlMin:x&&x.requiredFlowGMin;return v===null||v===undefined||v===''?null:Number(v);}
function calibratedFlow(x){const v=modeOf(x)==='volume'?x&&x.calibratedFlowMlMin:x&&x.calibratedFlowGMin;return v===null||v===undefined||v===''?null:Number(v);}
function primaryTotal(b){return modeOf(b)==='volume'?Number(b.totalVolumeMl):Number(b.totalMassG);}
function primaryDose(b){return modeOf(b)==='volume'?Number(b.doseMlPerT):Number(b.doseGPerT);}
function totalLabel(b){return modeOf(b)==='volume'?fmt(Number(b.totalVolumeMl)/1000,3)+' л':fmtG(b.totalMassG);}
function doseLabel(b){return modeOf(b)==='volume'?fmt(Number(b.doseMlPerT)/1000,3)+' л/т':fmtInt(b.doseGPerT)+' г/т';}
function amountLabel(mode,v){return mode==='volume'?fmtMl(v):fmtG(v);}
function nullableNum(v){return v===null||v===undefined||v===''?null:Number(v);}
function clamp(v,a,b){return Math.max(a,Math.min(b,v));}
function esc(v){return String(v??'').replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));}
function duration(min){if(min===null||!isFinite(min))return '—';const m=Math.max(0,Math.round(min));return Math.floor(m/60)+' ч '+String(m%60).padStart(2,'0')+' мин';}
function normalize(s){return String(s||'').trim().toLowerCase().replace(/ё/g,'е').replace(/\s+/g,' ');}
function hashString(s){let h=2166136261;for(let i=0;i<s.length;i++){h^=s.charCodeAt(i);h=Math.imul(h,16777619);}return (h>>>0).toString(16).padStart(8,'0');}
function recipeKey(batchLike){
  const t=Number(batchLike.seedTonnage||batchLike.seed_tonnage||1)||1;
  const comps=(batchLike.components||[]).filter(x=>x&&normalize(x.name)).map(x=>({n:normalize(x.name),u:normalize(x.unit),p:(Number(x.qty)||0)/t})).sort((a,b)=>(a.n+a.u).localeCompare(b.n+b.u));
  const mode=modeOf(batchLike);
  if(mode==='mass'){
    const dose=Number(batchLike.doseGPerT||batchLike.dose_g_per_t||0)||0;
    const raw=[normalize(batchLike.recipeName||batchLike.recipe_name),normalize(batchLike.crop),Math.round(dose),...comps.map(x=>x.n+':'+x.u+':'+x.p.toFixed(5))].join('|');
    return 'r-'+hashString(raw);
  }
  const doseMl=Number(batchLike.doseMlPerT||batchLike.dose_ml_per_t||0)||0;
  const raw=['volume',normalize(batchLike.recipeName||batchLike.recipe_name),normalize(batchLike.crop),Math.round(doseMl),...comps.map(x=>x.n+':'+x.u+':'+x.p.toFixed(5))].join('|');
  return 'rv-'+hashString(raw);
}
function initialState(){return{schemaVersion:STATE_SCHEMA,batches:[],calibrations:[],runs:[],bags:[],activeBatchId:null,activeRunId:null,activeBagId:null,activeCal:null,settings:{sm4Points:[{hz:29,minPerT:37},{hz:30,minPerT:36},{hz:31,minPerT:35},{hz:32,minPerT:34}]}};}
let state=Object.assign(initialState(),DonskoeCore.readRecoverable(STATE_KEY,[STATE_BACKUP_KEY,STATE_BACKUP2_KEY],{},v=>v&&['batches','calibrations','runs','bags'].every(k=>Array.isArray(v[k]))));
state.batches=Array.isArray(state.batches)?state.batches:[];
state.calibrations=Array.isArray(state.calibrations)?state.calibrations:[];
state.runs=Array.isArray(state.runs)?state.runs:[];
state.bags=Array.isArray(state.bags)?state.bags:[];
state.batches.forEach(b=>{if(!b.measurementMode)b.measurementMode='mass';if(b.measurementMode==='volume'&&!b.doseMlPerT&&b.totalVolumeMl&&b.seedTonnage)b.doseMlPerT=Number(b.totalVolumeMl)/Number(b.seedTonnage);});
state.calibrations.forEach(c=>{if(!c.measurementMode)c.measurementMode='mass';});
state.runs.forEach(r=>{if(!r.measurementMode)r.measurementMode='mass';if(r.pausedDurationSec===undefined||r.pausedDurationSec===null)r.pausedDurationSec=0;if(!Array.isArray(r.lineEvents))r.lineEvents=[];if(r.emergencyCount===undefined||r.emergencyCount===null)r.emergencyCount=0;});
state.bags.forEach(b=>{if(!b.learningStatus)b.learningStatus=b.actualNetKg>0?'accepted':'pending_weight';if(!b.status)b.status=b.endedAt?'completed':'running';});
if(state.activeCal&&!state.activeCal.measurementMode){state.activeCal.measurementMode='mass';if(state.activeCal.massBeforeG===undefined&&state.activeCal.massBeforeKg!==undefined)state.activeCal.massBeforeG=Number(state.activeCal.massBeforeKg)*1000;if(state.activeCal.requiredFlow===undefined&&state.activeCal.requiredFlowGMin!==undefined)state.activeCal.requiredFlow=Number(state.activeCal.requiredFlowGMin);}
state.settings=state.settings||initialState().settings;
function reconcileOperationalState(){
  let changed=false;const liveRuns=state.runs.filter(r=>r&&!r.deletedAt&&r.status==='running').sort((a,b)=>String(b.updatedAt||b.startedAt||'').localeCompare(String(a.updatedAt||a.startedAt||'')));
  if(liveRuns.length){const selected=state.runs.find(r=>r.clientId===state.activeRunId&&r.status==='running'&&!r.deletedAt)||liveRuns[0];if(state.activeRunId!==selected.clientId){state.activeRunId=selected.clientId;changed=true;}if(state.activeBatchId!==selected.batchClientId){state.activeBatchId=selected.batchClientId;changed=true;}const bags=state.bags.filter(b=>b&&!b.deletedAt&&b.status==='running'&&b.runClientId===selected.clientId).sort((a,b)=>String(b.updatedAt||b.startedAt||'').localeCompare(String(a.updatedAt||a.startedAt||'')));if(bags.length&&state.activeBagId!==bags[0].clientId){state.activeBagId=bags[0].clientId;changed=true;}if(!bags.length&&state.activeBagId){state.activeBagId=null;changed=true;}}
  else{if(state.activeRunId){state.activeRunId=null;changed=true;}if(state.activeBagId){state.activeBagId=null;changed=true;}}
  if(state.activeBatchId&&!state.batches.some(b=>b.clientId===state.activeBatchId&&!b.deletedAt)){state.activeBatchId=null;changed=true;}
  return{changed,multipleRuns:liveRuns.length>1};
}
const integrityBoot=reconcileOperationalState();
function saveState(){state.schemaVersion=STATE_SCHEMA;const old=readJSON(STATE_KEY,null);if(old&&JSON.stringify(old)!==JSON.stringify(state)){const backup=readJSON(STATE_BACKUP_KEY,null);if(backup)writeJSON(STATE_BACKUP2_KEY,backup);writeJSON(STATE_BACKUP_KEY,old);}writeJSON(STATE_KEY,state);}
function touch(o){o.updatedAt=iso();return o;}
function activeBatch(){return state.batches.find(x=>x.clientId===state.activeBatchId&&!x.deletedAt)||null;}
function latestBatch(){return state.batches.filter(x=>!x.deletedAt).sort((a,b)=>String(b.createdAt).localeCompare(String(a.createdAt)))[0]||null;}
function ensureActiveBatch(){if(!activeBatch()){const b=latestBatch();state.activeBatchId=b?b.clientId:null;saveState();}return activeBatch();}
function acceptedForBatch(batch){if(!batch)return null;const mode=modeOf(batch);return state.calibrations.filter(c=>!c.deletedAt&&c.accepted&&c.batchClientId===batch.clientId&&modeOf(c)===mode&&c.recipeKey===batch.recipeKey).sort((a,b)=>String(b.occurredAt).localeCompare(String(a.occurredAt)))[0]||null;}
function currentRun(){return state.runs.find(r=>r.clientId===state.activeRunId&&r.status==='running'&&!r.deletedAt)||null;}
function currentBag(){return state.bags.find(b=>b.clientId===state.activeBagId&&b.status==='running'&&!b.deletedAt)||null;}
function bagsForRun(runId){return state.bags.filter(b=>!b.deletedAt&&b.runClientId===runId).sort((a,b)=>Number(a.bagNo)-Number(b.bagNo));}
function acceptedSm4Bags(crop){return state.bags.filter(b=>!b.deletedAt&&b.status==='completed'&&b.learningStatus==='accepted'&&Number(b.actualNetKg)>0&&Number(b.activeDurationSec)>0&&String(b.crop||'Соя')===String(crop||'Соя'));}

function lineEvent(run,type,at=iso(),extra={}){if(!run)return;run.lineEvents=Array.isArray(run.lineEvents)?run.lineEvents:[];run.lineEvents.push(Object.assign({type,at},extra||{}));}
function runWallSec(run,nowMs=Date.now()){if(!run||!run.startedAt)return 0;const endMs=run.endedAt?new Date(run.endedAt).getTime():nowMs;return Math.max(0,(endMs-new Date(run.startedAt).getTime())/1000);}
function runActiveSec(run,nowMs=Date.now()){if(!run||!run.startedAt)return 0;let total=runWallSec(run,nowMs)-Number(run.pausedDurationSec||0);if(run.pausedAt&&!run.endedAt)total-=(nowMs-new Date(run.pausedAt).getTime())/1000;return Math.max(0,total);}
function runIsPaused(run){return !!(run&&run.pausedAt&&!run.endedAt);}
function createBag(run,targetKg,at=iso()){
  if(!run||!(Number(targetKg)>0))return null;if(currentBag())return currentBag();const pred=sm4Prediction(run.sm4Hz,run.crop),paused=runIsPaused(run);
  const bag={clientId:uuid(),runClientId:run.clientId,batchClientId:run.batchClientId,crop:run.crop||'Соя',bagNo:nextBagNo(run),targetKg:Number(targetKg),sm4Hz:run.sm4Hz,modelMinPerT:run.sm4MinPerT,modelSource:pred.source,modelConfidence:pred.confidence,startedAt:at,endedAt:null,pausedAt:paused?at:null,pausedDurationSec:0,activeDurationSec:null,estimatedKg:null,actualNetKg:null,actualKgMin:null,actualMinPerT:null,deviationPct:null,weightRecordedAt:null,learningStatus:'pending_weight',status:'running',notes:'',createdAt:at,updatedAt:at};
  state.bags.push(bag);state.activeBagId=bag.clientId;queueRecord('bags',bag);lineEvent(run,'bag_start',at,{bagNo:bag.bagNo,targetKg:bag.targetKg});return bag;
}
function pauseLine(reason='pause'){
  const run=currentRun();if(!run||runIsPaused(run))return;const at=iso();run.pausedAt=at;run.pauseReason=reason;if(reason==='emergency')run.emergencyCount=Number(run.emergencyCount||0)+1;
  const bag=currentBag();if(bag&&!bag.pausedAt){bag.pausedAt=at;touch(bag);queueRecord('bags',bag);}
  const eventType=reason==='emergency'?'emergency_stop':reason==='stop_pending'?'stop_request':'pause';
  lineEvent(run,eventType,at);touch(run);saveState();queueRecord('runs',run);cloudSync(true);renderWork();
}
function resumeLine(){
  const run=currentRun();if(!run||!run.pausedAt)return;if(run.pauseReason==='batch_complete'||run.pauseReason==='stopped')return;const now=Date.now(),at=iso(),pauseStart=new Date(run.pausedAt).getTime();run.pausedDurationSec=Number(run.pausedDurationSec||0)+Math.max(0,(now-pauseStart)/1000);
  const bag=currentBag();if(bag&&bag.pausedAt){bag.pausedDurationSec=Number(bag.pausedDurationSec||0)+Math.max(0,(now-new Date(bag.pausedAt).getTime())/1000);bag.pausedAt=null;touch(bag);queueRecord('bags',bag);}lineEvent(run,'resume',at,{after:run.pauseReason||'pause'});run.pausedAt=null;run.pauseReason=null;touch(run);saveState();queueRecord('runs',run);cloudSync(true);renderWork();
}
function closeCurrentBagAt(run,bag,endAt,{startNext=true,note=''}={}){
  if(!(run&&bag)||bag.status!=='running')return null;const endMs=new Date(endAt).getTime(),active=bagActiveSec(bag,endMs);bag.endedAt=endAt;bag.activeDurationSec=active;bag.estimatedKg=bag.modelMinPerT>0?active/60*1000/bag.modelMinPerT:null;bag.status='completed';if(note)bag.notes=[bag.notes,note].filter(Boolean).join(' · ');bag.pausedAt=null;touch(bag);state.activeBagId=null;queueRecord('bags',bag);lineEvent(run,'bag_finish',endAt,{bagNo:bag.bagNo,estimatedKg:bag.estimatedKg,targetKg:bag.targetKg});updateRunProcessedFromBags(run);
  let next=null;if(startNext){const target=nextBagTarget(run);if(target>0.5)next=createBag(run,target,endAt);else{if(!run.pausedAt)run.pausedAt=endAt;run.pauseReason='batch_complete';lineEvent(run,'planned_seed_complete',endAt);}}
  touch(run);queueRecord('runs',run);saveState();cloudSync(true);return next;
}
function stopLineHere(){
  const run=currentRun();if(!run)return;if(!runIsPaused(run))return alert('Сначала остановите счётчики кнопкой «Пауза», «СТОП РАБОТЫ» или «АВАРИЙНЫЙ СТОП».');
  const stopAt=run.pausedAt||iso(),bag=currentBag();if(bag)closeCurrentBagAt(run,bag,stopAt,{startNext:false,note:'Партия остановлена досрочно'});
  run.pauseReason='stopped';lineEvent(run,'run_stop',stopAt);touch(run);saveState();queueRecord('runs',run);cloudSync(true);renderWork();
}
function requestNormalStop(){const run=currentRun();if(!run||runIsPaused(run))return;pauseLine('stop_pending');}
function bagHadEmergency(bag){
  if(!bag)return false;const run=state.runs.find(r=>r.clientId===bag.runClientId&&!r.deletedAt);if(!run)return false;
  const a=new Date(bag.startedAt).getTime(),z=bag.endedAt?new Date(bag.endedAt).getTime():Date.now();
  return (run.lineEvents||[]).some(e=>e.type==='emergency_stop'&&new Date(e.at).getTime()>=a&&new Date(e.at).getTime()<=z);
}


function setNetwork(){const online=navigator.onLine!==false,p=$('networkPill');p.classList.toggle('online',online);p.classList.toggle('offline',!online);$('networkText').textContent=online?'Сеть есть':'Без сети';}
window.addEventListener('online',()=>{setNetwork();cloudSync(true);});window.addEventListener('offline',setNetwork);setNetwork();
$('masterHome').addEventListener('click',()=>location.href='../index.html?skipSplash=1');

const titles={home:'ConNiSseur',mix:'Приготовить смесь',cal:'Калибровка',work:'Работа',history:'История'};
let navDepth=0;
let navPopInFlight=false;
function currentRoute(){return routeStack[routeStack.length-1]||'home';}
function setRouteState(name,mode='push'){
  if(!history||!history[mode+'State'])return;
  const stateObj={connisseur:true,route:name,depth:navDepth,stack:routeStack.slice()};
  try{history[mode+'State'](stateObj,'','#'+name);}catch(e){}
}
function showPage(name,push=true){
  if(!titles[name])name='home';
  const from=currentRoute();updateProOverview();
  qsa('.page').forEach(p=>p.classList.toggle('active',p.id==='page-'+name));
  $('subbar').classList.toggle('hidden',name==='home');$('pageTitle').textContent=titles[name];
  if(push&&from!==name){routeStack.push(name);navDepth++;setRouteState(name,'push');}
  document.dispatchEvent(new Event('donskoe-route'));if(name==='mix')renderMix();if(name==='cal')renderCalibration();if(name==='work')renderWork();if(name==='history')renderHistory();
  window.scrollTo({top:0,behavior:'auto'});
}
function hasOpenOverlay(){return !$('bagWeightShade').classList.contains('hidden')||!$('batchPickerShade').classList.contains('hidden');}
function closeOpenOverlay(){
  // Закрываем модальные окна их штатными функциями, чтобы не оставить служебное состояние после свайпа/Back.
  if(!$('bagWeightShade').classList.contains('hidden')){closeBagWeight();return true;}
  if(!$('batchPickerShade').classList.contains('hidden')){closeBatchPicker();return true;}
  return false;
}
function goBack(){
  if(closeOpenOverlay())return;
  if(navPopInFlight)return;
  const cur=currentRoute();
  if(cur!=='home'){
    if(history.state&&history.state.connisseur&&Number(history.state.depth)>0){navPopInFlight=true;history.back();setTimeout(()=>{navPopInFlight=false;},350);return;}
    routeStack=['home'];navDepth=0;setRouteState('home','replace');showPage('home',false);return;
  }
  location.href='../index.html?skipSplash=1';
}
$('backBtn').addEventListener('click',goBack);
qsa('[data-route]').forEach(b=>b.addEventListener('click',()=>showPage(b.dataset.route)));
try{
  history.replaceState({connisseur:true,route:'home',depth:0},'','#home');
}catch(e){}
window.addEventListener('popstate',e=>{
  navPopInFlight=false;
  const st=e.state;
  if(st&&st.connisseur&&titles[st.route]){
    navDepth=Math.max(0,Number(st.depth)||0);
    routeStack=Array.isArray(st.stack)?st.stack:(navDepth===0?['home']:['home',st.route]);
    showPage(st.route,false);
  }
});
const edgeSwipeStandalone=(window.matchMedia&&window.matchMedia('(display-mode: standalone)').matches)||window.navigator.standalone===true;
let sx=0,sy=0,tracking=false,swipeDepth=0,swipeTimer=null;
if(edgeSwipeStandalone){
  document.addEventListener('touchstart',e=>{
    if(e.touches.length!==1||hasOpenOverlay())return;
    const t=e.touches[0];
    if(t.clientX<=44){sx=t.clientX;sy=t.clientY;tracking=true;swipeDepth=Number(history.state&&history.state.depth)||0;}
  },{passive:true});
  document.addEventListener('touchcancel',()=>{tracking=false;if(swipeTimer)clearTimeout(swipeTimer);},{passive:true});
  document.addEventListener('touchend',e=>{
    if(!tracking)return;tracking=false;
    const t=e.changedTouches[0],dx=t.clientX-sx,dy=Math.abs(t.clientY-sy);
    if(dx<70||dy>80||dx<dy*1.35)return;
    if(swipeTimer)clearTimeout(swipeTimer);
    // Даём WebKit сначала выполнить нативный history-back. Fallback нужен только если standalone-жест не сработал.
    swipeTimer=setTimeout(()=>{
      const depthNow=Number(history.state&&history.state.depth)||0;
      if(!navPopInFlight&&depthNow===swipeDepth)goBack();
    },220);
  },{passive:true});
}

function metric(label,value,sub=''){return `<div class="metric"><span>${esc(label)}</span><b>${esc(value)}</b>${sub?`<small>${esc(sub)}</small>`:''}</div>`;}

let mixMode='mass';
function setMixMode(mode){
  mixMode=mode==='volume'?'volume':'mass';
  $('modeMass').classList.toggle('active',mixMode==='mass');$('modeVolume').classList.toggle('active',mixMode==='volume');
  $('mixMassLabel').textContent=mixMode==='mass'?'Фактическая масса смеси, г — основной параметр':'Фактическая масса смеси, г — если известна';
  $('mixVolumeLabel').textContent=mixMode==='volume'?'Общий объём, л — основной параметр':'Общий объём, л — справочно';
  $('mixModeHint').className='hint '+(mixMode==='mass'?'good':'warn');
  $('mixModeHint').textContent=mixMode==='mass'?'Точный режим: расчёт по массе, все показания весов вводятся в граммах.':'Резервный режим: расчёт по объёму. Калибровка — по мерному стакану в мл; рабочие остатки — в литрах.';
  renderMixResult();
}
$('modeMass').onclick=()=>setMixMode('mass');$('modeVolume').onclick=()=>setMixMode('volume');
function renderComponents(){
  const host=$('componentsList');host.innerHTML='';
  if(!draftComponents.length)draftComponents=[{name:'',qty:'',unit:'л'}];
  draftComponents.forEach((c,i)=>{
    const row=document.createElement('div');row.className='componentRow';
    row.innerHTML=`<input data-cname="${i}" type="text" placeholder="Препарат / компонент" value="${esc(c.name)}"><input data-cqty="${i}" type="number" inputmode="decimal" step="0.001" min="0" placeholder="Кол-во" value="${esc(c.qty)}"><select data-cunit="${i}"><option>л</option><option>мл</option><option>кг</option><option>г</option></select><button data-cremove="${i}" class="removeComp" type="button">×</button>`;
    host.appendChild(row);row.querySelector('[data-cunit]').value=c.unit||'л';
  });
  host.querySelectorAll('[data-cname]').forEach(x=>x.oninput=()=>{draftComponents[+x.dataset.cname].name=x.value;renderMixResult();});
  host.querySelectorAll('[data-cqty]').forEach(x=>x.oninput=()=>{draftComponents[+x.dataset.cqty].qty=x.value;renderMixResult();});
  host.querySelectorAll('[data-cunit]').forEach(x=>x.onchange=()=>{draftComponents[+x.dataset.cunit].unit=x.value;renderMixResult();});
  host.querySelectorAll('[data-cremove]').forEach(x=>x.onclick=()=>{draftComponents.splice(+x.dataset.cremove,1);renderComponents();renderMixResult();});
}
$('addComponent').onclick=()=>{draftComponents.push({name:'',qty:'',unit:'л'});renderComponents();};
['mixTonnage','mixMassG','mixVolumeL','mixName','mixCrop'].forEach(id=>$(id).addEventListener('input',renderMixResult));
function renderMix(){renderComponents();setMixMode(mixMode);renderMixResult();}
function renderMixResult(){
  const t=Number($('mixTonnage').value),massG=Number($('mixMassG').value),volL=Number($('mixVolumeL').value),box=$('mixResult');
  const primary=mixMode==='volume'?volL*1000:massG;
  if(!(t>0&&primary>0)){box.classList.add('hidden');return;}
  const totalMin30=t*(66-30),flow30=primary/totalMin30;
  const dose=mixMode==='volume'?primary/t:massG/t;
  box.className='resultCard';box.innerHTML=`<div class="resultTitle">Расчёт ${mixMode==='volume'?'по объёму':'по массе'}</div><div class="resultBig">${mixMode==='volume'?fmt(dose/1000,3)+' л/т':fmtInt(dose)+' г/т'}</div><div class="metrics">${metric(mixMode==='volume'?'Объём смеси':'Масса смеси',mixMode==='volume'?fmt(volL,3)+' л':fmtG(massG))}${metric('Тоннаж',fmt(t,2)+' т')}${metric('При СМ-4 30 Гц',fmt(flow30,0)+' '+flowUnit(mixMode),'ориентир до калибровки')}${metric('Время партии при 30 Гц',duration(totalMin30))}</div>`;
}
$('saveBatch').onclick=()=>{
  if(currentRun())return alert('Сначала завершите текущую обработку. Нельзя сменить её партию до сохранения итогов.');
  if(draftComponents.some(c=>(normalize(c.name)||String(c.qty).trim())&&(!normalize(c.name)||!(Number(c.qty)>0))))return alert('У каждого компонента укажите название и положительное количество либо удалите незаполненную строку.');
  const crop=$('mixCrop').value,t=Number($('mixTonnage').value),massG=Number($('mixMassG').value)||null,volL=Number($('mixVolumeL').value)||null;
  if(!(t>0))return alert('Укажите тоннаж семян.');
  if(mixMode==='mass'&&!(massG>0))return alert('Укажите фактическую массу готовой смеси в граммах.');
  if(mixMode==='volume'&&!(volL>0))return alert('Укажите фактический объём готовой смеси в литрах.');
  const components=draftComponents.filter(c=>normalize(c.name)&&Number(c.qty)>0).map(c=>({name:String(c.name).trim(),qty:Number(c.qty),unit:c.unit||'л'}));
  const recipeName=String($('mixName').value||'').trim()||(crop+' — рабочий состав');
  const b={clientId:uuid(),crop,recipeName,measurementMode:mixMode,seedTonnage:t,totalMassG:massG,totalVolumeMl:volL?volL*1000:null,doseGPerT:massG?massG/t:null,doseMlPerT:volL?volL*1000/t:null,components,status:'prepared',notes:String($('mixNote').value||'').trim(),createdAt:iso(),updatedAt:iso()};b.recipeKey=recipeKey(b);
  state.batches.push(b);state.activeBatchId=b.clientId;$('calPumpHz').value='';$('workPumpHz').value='';workPumpManual=false;workStartMeasureManual=false;$('workStartMeasure').value='';$('calBeforeMeasure').value='';$('calAfterMeasure').value='';saveState();queueRecord('batches',b);cloudSync(true);
  $('mixMassG').value='';$('mixVolumeL').value='';$('mixNote').value='';draftComponents=[{name:'',qty:'',unit:'л'}];renderComponents();renderMixResult();showPage('work');
};

function sm4Minutes(hz){hz=Number(hz);return hz>=29&&hz<=32?66-hz:null;}
function sm4Prediction(hz,crop='Соя'){
  hz=Number(hz);const baseline=sm4Minutes(hz),inBase=hz>=29&&hz<=32;
  const all=acceptedSm4Bags(crop).filter(b=>Number(b.actualMinPerT)>0&&Number(b.sm4Hz)>0&&Number(b.actualMinPerT)>=5&&Number(b.actualMinPerT)<=720);
  const nearby=all.map(b=>({b,d:Math.abs(Number(b.sm4Hz)-hz),m:Number(b.actualMinPerT)})).filter(x=>x.d<=1.25);
  const exact=nearby.filter(x=>x.d<=0.15);
  if(!inBase){const vals=exact.map(x=>x.m),mean=vals.length?vals.reduce((a,b)=>a+b,0)/vals.length:0,reliable=vals.length>=3&&(Math.max(...vals)-Math.min(...vals))/mean<=.05;if(!reliable)return {hz,minPerT:null,kgMin:null,confidence:'Низкая',cls:'warn',realPoints:exact.length,exactPoints:exact.length,source:'нет достоверной калибровки',text:'Вне 29–32 Гц нет достоверной калибровки. Время и масса по таймеру не прогнозируются. Возможен ручной запуск с фактическим взвешиванием каждого биг-бэга.'};return {hz,minPerT:mean,kgMin:1000/mean,confidence:'Средняя',cls:'warn',realPoints:exact.length,exactPoints:exact.length,source:'повторные взвешивания на этой частоте',text:'Опора на '+exact.length+' согласованных фактических взвешивания на этой частоте. Проверяйте расход и фактическую массу.'};}
  let sw=0,sm=0;
  if(isFinite(baseline)&&baseline>0){const bw=inBase?0.7:0.18;sw+=bw;sm+=baseline*bw;}
  nearby.forEach(x=>{const w=2.5/(0.18+x.d*x.d);sw+=w;sm+=x.m*w;});
  let minPerT=sw>0?sm/sw:baseline;
  if(!(minPerT>0))minPerT=36;
  let confidence='Низкая',cls='bad';
  if(exact.length>=3){
    const vals=exact.map(x=>x.m),avgv=vals.reduce((a,b)=>a+b,0)/vals.length;
    const spread=Math.max(...vals)-Math.min(...vals);
    if(spread/avgv<=.05){confidence='Высокая';cls='good';}
    else{confidence='Средняя';cls='warn';}
  }else if(exact.length>=1||nearby.length>=2){confidence='Средняя';cls='warn';}
  else if(inBase){confidence='Стартовая';cls='warn';}
  const source=nearby.length?`${nearby.length} взвешиван${nearby.length===1?'ие':nearby.length<5?'ия':'ий'} биг-бэга + модель СМ‑4`:(inBase?'базовая кривая 2026':'физическая экстраполяция от ближайшей подтверждённой точки');
  let text;
  if(nearby.length)text=`Прогноз СМ‑4: ${fmt(minPerT,2)} мин/т (${fmt(1000/minPerT,2)} кг/мин). В модели ${source}.`;
  else if(inBase)text=`Стартовая опора: ${fmt(hz,1)} Гц → ${fmt(baseline,1)} мин/т. Это подтверждённая ручная калибровка 2026, но реальных взвешиваний биг-бэгов при этой частоте ещё нет.`;
  else text=`Частота ${fmt(hz,1)} Гц вне подтверждённого диапазона 29–32 Гц. Ориентир ${fmt(minPerT,2)} мин/т рассчитан по обратной пропорции частоты от ближайшей подтверждённой точки, а не по формуле 66−Гц. Опора низкая до фактического взвешивания биг-бэга на этой частоте.`;
  return{hz,minPerT,kgMin:1000/minPerT,confidence,cls,realPoints:nearby.length,exactPoints:exact.length,source,text};
}
function sm4LearningCurve(crop='Соя'){
  return [29,30,31,32].map(h=>({hz:h,...sm4Prediction(h,crop)}));
}

function renderCalibration(){
  const b=ensureActiveBatch();$('calNoBatch').classList.toggle('hidden',!!b);$('calBody').classList.toggle('hidden',!b);if(!b)return;
  const mode=modeOf(b);$('calBatchName').textContent=`${b.recipeName} · ${fmt(b.seedTonnage,2)} т`;
  $('calBatchMetrics').innerHTML=metric(mode==='volume'?'Объём смеси':'Масса смеси',totalLabel(b))+metric('Доза',doseLabel(b))+metric('Контроль',mode==='volume'?'по объёму':'по массе')+metric('Калибровка','не обязательна');
  $('calModeMass').classList.toggle('active',mode==='mass');$('calModeVolume').classList.toggle('active',mode==='volume');
  $('calModeSwitchHint').className='hint '+(mode==='volume'?'warn':'good');$('calModeSwitchHint').textContent=mode==='volume'?'Объёмный режим: измеряем фактическую подачу насоса мерным стаканом в мл/мин.':'Массовый режим: измеряем фактическую подачу насоса по потере массы в г/мин.';
  $('calBeforeField').classList.toggle('hidden',mode==='volume');
  $('calAfterLabel').textContent=mode==='volume'?'Объём, набранный в мерный стакан, мл':'Показание весов после теста, г';
  $('calAfterMeasure').placeholder=mode==='volume'?'Например 1350':'Например 50350';
  $('calMeasureHint').className='hint '+(mode==='volume'?'warn':'good');
  $('calMeasureHint').textContent=mode==='volume'?'Поставьте мерный стакан на выход насоса, запустите только насос и после остановки внесите набранный объём.':'Введите вес до теста, запустите только насос и после остановки внесите вес после теста.';
  renderPumpCalibrationHint(b);renderCalState();
}
function switchBatchMode(mode){
  const b=activeBatch();if(!b)return;if(currentRun()&&currentRun().batchClientId===b.clientId)return alert('Во время активной работы способ контроля менять нельзя. Завершите текущую работу.');if(state.activeCal&&state.activeCal.batchClientId===b.clientId)return alert('Сначала завершите текущую калибровку.');mode=mode==='volume'?'volume':'mass';if(mode===modeOf(b))return;
  if(mode==='volume'&&!(Number(b.totalVolumeMl)>0)){const raw=prompt('Введите общий объём этой партии рабочего состава, л.');if(raw===null)return;const v=Number(String(raw).replace(',','.'));if(!(v>0))return alert('Объём должен быть больше нуля.');b.totalVolumeMl=v*1000;b.doseMlPerT=b.totalVolumeMl/b.seedTonnage;}
  if(mode==='mass'&&!(Number(b.totalMassG)>0)){const raw=prompt('Введите фактическую массу этой партии, г.');if(raw===null)return;const g=Number(String(raw).replace(',','.'));if(!(g>0))return alert('Масса должна быть больше нуля.');b.totalMassG=g;b.doseGPerT=g/b.seedTonnage;}
  b.measurementMode=mode;b.recipeKey=recipeKey(b);if(!['running','completed'].includes(b.status))b.status='prepared';touch(b);state.activeCal=null;pendingCalResult=null;$('calPumpHz').value='';$('calBeforeMeasure').value='';$('calAfterMeasure').value='';saveState();queueRecord('batches',b);cloudSync(true);renderCalibration();renderWork();
}
$('calModeMass').onclick=()=>switchBatchMode('mass');$('calModeVolume').onclick=()=>switchBatchMode('volume');
function pumpPoints(recipeKeyValue,mode){return state.calibrations.filter(c=>!c.deletedAt&&c.accepted&&c.recipeKey===recipeKeyValue&&modeOf(c)===mode&&flowValue(c)>0&&Number(c.pumpHz)>0);}
function estimatePumpHz(target,recipeKeyValue,mode){
  target=Number(target);const pts=pumpPoints(recipeKeyValue,mode).sort((a,b)=>flowValue(a)-flowValue(b)),unit=flowUnit(mode);
  if(!(target>0))return{hz:null,confidence:'Нет данных',points:pts.length,text:'Нет корректной требуемой подачи для расчёта насоса.'};
  if(!pts.length)return{hz:null,confidence:'Нет данных',points:0,text:`Калибровок насоса для этого рецепта нет. Частоту задаёт оператор.`};
  if(pts.length===1){
    const p=pts[0],pv=flowValue(p),ratio=target/pv;
    if(!(ratio>=.5&&ratio<=1.5))return{hz:null,confidence:'Низкая',points:1,text:`Есть только одна точка ${fmt(p.pumpHz,1)} Гц → ${fmt(pv,0)} ${unit}, а требуемая подача ${fmt(target,0)} ${unit} слишком далеко от неё. Числовую рекомендацию не выдаём.`};
    const hz=Number(p.pumpHz)*ratio;
    if(!(hz>0))return{hz:null,confidence:'Низкая',points:1,text:'Единственная точка насоса не даёт корректной рекомендации.'};
    const conf=(ratio>=.8&&ratio<=1.2)?'Средняя':'Низкая';
    return{hz,confidence:conf,points:1,text:`Одна точка: ${fmt(p.pumpHz,1)} Гц → ${fmt(pv,0)} ${unit}. Используем только ограниченную пропорциональную подсказку.`};
  }
  const minFlow=flowValue(pts[0]),maxFlow=flowValue(pts[pts.length-1]);
  if(target<minFlow||target>maxFlow)return{hz:null,confidence:'Низкая',points:pts.length,text:`Требуемая подача ${fmt(target,0)} ${unit} вне изученного диапазона насоса ${fmt(minFlow,0)}–${fmt(maxFlow,0)} ${unit}. Экстраполяцию не используем.`};
  let lo=null,hi=null;for(let i=0;i<pts.length-1;i++){const a=flowValue(pts[i]),b=flowValue(pts[i+1]);if(target>=a&&target<=b){lo=pts[i];hi=pts[i+1];break;}}
  if(!lo)return{hz:null,confidence:'Низкая',points:pts.length,text:'Точки насоса не позволяют надёжно интерполировать требуемую подачу.'};
  const lov=flowValue(lo),hiv=flowValue(hi),dy=hiv-lov;let hz=Math.abs(dy)<.0001?(Number(lo.pumpHz)+Number(hi.pumpHz))/2:Number(lo.pumpHz)+(target-lov)*(Number(hi.pumpHz)-Number(lo.pumpHz))/dy;
  const minHz=Math.min(...pts.map(p=>Number(p.pumpHz))),maxHz=Math.max(...pts.map(p=>Number(p.pumpHz)));
  if(!(hz>0)||hz<minHz-.001||hz>maxHz+.001)return{hz:null,confidence:'Низкая',points:pts.length,text:'Калибровочные точки насоса противоречат друг другу; рекомендацию скрываем до новой контрольной точки.'};
  return{hz,confidence:'Высокая',points:pts.length,text:`${pts.length} подтверждённых точек насоса. Требуемая подача находится внутри измеренного диапазона.`};
}
function estimatePumpFlowAtHz(hz,recipeKeyValue,mode){
  hz=Number(hz);const pts=pumpPoints(recipeKeyValue,mode).sort((a,b)=>Number(a.pumpHz)-Number(b.pumpHz)),unit=flowUnit(mode);
  if(!(hz>0)||!pts.length)return{flow:null,confidence:'Нет данных',points:pts.length,text:'Нет фактических точек насоса для оценки этой частоты.'};
  if(pts.length===1){
    const p=pts[0],baseHz=Number(p.pumpHz),ratio=hz/baseHz;
    if(!(ratio>=.5&&ratio<=1.5))return{flow:null,confidence:'Низкая',points:1,text:`${fmt(hz,1)} Гц слишком далеко от единственной изученной точки ${fmt(baseHz,1)} Гц. Экстраполяцию не используем.`};
    const flow=flowValue(p)*ratio;return{flow,confidence:ratio>=.8&&ratio<=1.2?'Средняя':'Низкая',points:1,text:`Оценка рядом с одной точкой ${fmt(baseHz,1)} Гц → ${fmt(flowValue(p),0)} ${unit}.`};
  }
  const minHz=Number(pts[0].pumpHz),maxHz=Number(pts[pts.length-1].pumpHz);
  if(hz<minHz||hz>maxHz)return{flow:null,confidence:'Низкая',points:pts.length,text:`${fmt(hz,1)} Гц вне изученного диапазона насоса ${fmt(minHz,1)}–${fmt(maxHz,1)} Гц. Экстраполяцию не используем.`};
  let lo=null,hi=null;for(let i=0;i<pts.length-1;i++){if(hz>=Number(pts[i].pumpHz)&&hz<=Number(pts[i+1].pumpHz)){lo=pts[i];hi=pts[i+1];break;}}
  if(!lo)return{flow:null,confidence:'Низкая',points:pts.length,text:'Не удалось выбрать соседние точки насоса.'};
  const x1=Number(lo.pumpHz),x2=Number(hi.pumpHz),y1=flowValue(lo),y2=flowValue(hi),flow=Math.abs(x2-x1)<.0001?(y1+y2)/2:y1+(hz-x1)*(y2-y1)/(x2-x1);
  if(!(flow>0))return{flow:null,confidence:'Низкая',points:pts.length,text:'Интерполяция дала некорректную подачу; рекомендацию скрываем.'};
  return{flow,confidence:'Высокая',points:pts.length,text:`Оценка внутри диапазона ${pts.length} подтверждённых точек.`};
}
function renderPumpCalibrationHint(b){
  const pts=pumpPoints(b.recipeKey,modeOf(b)).sort((a,b)=>Number(a.pumpHz)-Number(b.pumpHz)),unit=flowUnit(modeOf(b));
  $('learningHint').className='hint '+(pts.length>=2?'good':pts.length===1?'warn':'');
  $('learningHint').innerHTML=pts.length?`В обучении <b>${pts.length}</b> точек: ${pts.slice(-4).map(p=>`${fmt(p.pumpHz,1)} Гц → ${fmt(flowValue(p),0)} ${unit}`).join(' · ')}. Калибровка нужна только для улучшения подсказок в «Работе».`:'Калибровок пока нет. Это не мешает работе: СМ‑4 и насос можно выставить вручную на странице «Работа».';
}
let batchPickerContext='cal';
$('changeBatchCal').onclick=()=>openBatchPicker('cal');
function openBatchPicker(context='cal'){
  batchPickerContext=context;const list=$('batchPickerList'),rows=state.batches.filter(b=>!b.deletedAt).sort((a,b)=>{const ac=pumpPoints(a.recipeKey,modeOf(a)).length?1:0,bc=pumpPoints(b.recipeKey,modeOf(b)).length?1:0;return bc-ac||String(b.createdAt).localeCompare(String(a.createdAt));});
  list.innerHTML=rows.length?'':'<div class="empty">Нет сохранённых партий.</div>';
  rows.forEach(b=>{const n=pumpPoints(b.recipeKey,modeOf(b)).length,btn=document.createElement('button');btn.className='batchPick';btn.innerHTML=`<b>${esc(b.recipeName)}</b><small>${esc(b.crop)} · ${fmt(b.seedTonnage,2)} т · ${esc(totalLabel(b))} · ${modeOf(b)==='volume'?'объём':'масса'} · ${n?`насос: ${n} точ.`:'насос: без калибровки'}</small>`;btn.onclick=()=>{state.activeBatchId=b.clientId;$('calPumpHz').value='';$('calBeforeMeasure').value='';$('calAfterMeasure').value='';$('workPumpHz').value='';workPumpManual=false;workStartMeasureManual=false;$('workStartMeasure').value='';saveState();closeBatchPicker();renderCalibration();renderWork();};list.appendChild(btn);});$('batchPickerShade').classList.remove('hidden');
}
function closeBatchPicker(){$('batchPickerShade').classList.add('hidden');}$('closeBatchPicker').onclick=closeBatchPicker;$('batchPickerShade').onclick=e=>{if(e.target===$('batchPickerShade'))closeBatchPicker();};
function renderCalState(){const a=state.activeCal;if(!a||a.batchClientId!==state.activeBatchId){$('calRunning').classList.add('hidden');$('calIdleButtons').classList.remove('hidden');$('calFinish').classList.add('hidden');return;}$('calIdleButtons').classList.add('hidden');if(!a.stoppedAt){$('calRunning').classList.remove('hidden');$('calFinish').classList.add('hidden');}else{$('calRunning').classList.add('hidden');$('calFinish').classList.remove('hidden');}updateCalTimer();}
$('startCal').onclick=()=>{const b=activeBatch(),mode=b?modeOf(b):'mass',pump=Number($('calPumpHz').value),before=Number($('calBeforeMeasure').value);if(!b)return alert('Сначала выберите партию.');if(!(pump>0))return alert('Укажите частоту насоса.');if(mode==='mass'&&!(before>0))return alert('Введите показание весов перед тестом в граммах.');state.activeCal={batchClientId:b.clientId,measurementMode:mode,startedAt:Date.now(),stoppedAt:null,pumpHz:pump,massBeforeG:mode==='mass'?before:null};pendingCalResult=null;if(!['running','completed'].includes(b.status)){b.status='calibrating';touch(b);queueRecord('batches',b);}saveState();renderCalState();};
$('stopCal').onclick=()=>{if(!state.activeCal||state.activeCal.stoppedAt)return;state.activeCal.stoppedAt=Date.now();saveState();renderCalState();$('calAfterMeasure').focus();};
function updateCalTimer(){const a=state.activeCal;if(!a||a.batchClientId!==state.activeBatchId)return;const end=a.stoppedAt||Date.now(),sec=Math.max(0,(end-a.startedAt)/1000),mm=Math.floor(sec/60),ss=Math.floor(sec%60);$('calTimer').textContent=String(mm).padStart(2,'0')+':'+String(ss).padStart(2,'0');$('calTargetLoss').textContent=(sec>=600?'10 минут достигнуты — завершите контроль.':'Измеряем фактическую подачу насоса.');}
$('calcCalResult').onclick=()=>{const a=state.activeCal,after=Number($('calAfterMeasure').value);if(!a||!a.stoppedAt)return alert('Сначала завершите контроль.');if(!(after>0))return alert(a.measurementMode==='volume'?'Введите объём из мерного стакана в мл.':'Введите показание весов после теста в граммах.');const sec=(a.stoppedAt-a.startedAt)/1000,min=sec/60,mode=a.measurementMode||'mass';if(!(min>0))return;let amount,massAfterG=null,testVolumeMl=null;if(mode==='mass'){if(after>=a.massBeforeG)return alert('Показание после теста должно быть меньше показания до теста.');massAfterG=after;amount=a.massBeforeG-after;}else{testVolumeMl=after;amount=after;}const actual=amount/min;pendingCalResult={durationSec:sec,massAfterG,testVolumeMl,measuredAmount:amount,actualFlow:actual};const short=sec<60,long=sec>600,box=$('calResultBox');box.className='resultCard '+(short?'warn':'');box.innerHTML=`<div class="resultTitle">Фактическая подача насоса</div><div class="resultBig">${fmt(actual,0)} ${flowUnit(mode)}</div><div class="metrics">${metric('Насос',fmt(a.pumpHz,1)+' Гц')}${metric(mode==='volume'?'Набрано':'Потеря массы',amountLabel(mode,amount))}${metric('Интервал',fmt(min,2)+' мин')}${metric('Назначение','точка обучения')}</div><div class="resultText" style="margin-top:12px">Эта точка не меняет СМ‑4. Она только связывает частоту насоса с фактической подачей.${short?' Контроль короче 1 минуты — лучше повторить для повышения точности.':''}${long?' Для следующей проверки достаточно более короткого интервала.':''}</div>`;box.classList.remove('hidden');$('calDecisionButtons').classList.remove('hidden');};
function saveCalibration(accepted){const a=state.activeCal,r=pendingCalResult,b=activeBatch();if(!a||!r||!b)return;const mode=a.measurementMode||'mass',now=iso();const c={clientId:uuid(),batchClientId:b.clientId,recipeKey:b.recipeKey,crop:b.crop,measurementMode:mode,sm4Hz:null,sm4MinPerT:null,requiredFlowGMin:null,requiredFlowMlMin:null,pumpHz:a.pumpHz,durationSec:r.durationSec,massBeforeG:mode==='mass'?a.massBeforeG:null,massAfterG:mode==='mass'?r.massAfterG:null,testVolumeMl:mode==='volume'?r.testVolumeMl:null,actualFlowGMin:mode==='mass'?r.actualFlow:null,actualFlowMlMin:mode==='volume'?r.actualFlow:null,errorPct:null,accepted:!!accepted,occurredAt:now,notes:'',createdAt:now,updatedAt:now};state.calibrations.push(c);queueRecord('calibrations',c);if(accepted&&!['running','completed'].includes(b.status)){b.status='ready';touch(b);queueRecord('batches',b);}state.activeCal=null;pendingCalResult=null;saveState();$('calAfterMeasure').value='';$('calBeforeMeasure').value='';$('calResultBox').classList.add('hidden');$('calDecisionButtons').classList.add('hidden');cloudSync(true);if(accepted){workPumpManual=false;showPage('work');}else renderCalibration();}
$('acceptCal').onclick=()=>saveCalibration(true);$('repeatCal').onclick=()=>saveCalibration(false);


function bagActiveSec(bag,nowMs=Date.now()){
  if(!bag||!bag.startedAt)return 0;
  const endMs=bag.endedAt?new Date(bag.endedAt).getTime():nowMs;
  let total=(endMs-new Date(bag.startedAt).getTime())/1000-Number(bag.pausedDurationSec||0);
  if(bag.pausedAt&&!bag.endedAt)total-=(nowMs-new Date(bag.pausedAt).getTime())/1000;
  return Math.max(0,total);
}
function estimatedBagKg(bag){const sec=bagActiveSec(bag),mpt=Number(bag&&bag.modelMinPerT);return mpt>0?sec/60*1000/mpt:null;}
function bagValueKg(bag){if(Number(bag.actualNetKg)>0)return Number(bag.actualNetKg);if(Number(bag.estimatedKg)>0)return Number(bag.estimatedKg);if(bag.status==='running')return estimatedBagKg(bag);return 0;}
function processedSeedKg(run,includeActive=true){if(!run)return 0;return bagsForRun(run.clientId).reduce((s,b)=>s+(includeActive||b.status!=='running'?bagValueKg(b):0),0);}
function updateRunProcessedFromBags(run){if(!run)return;run.processedTonnage=processedSeedKg(run,true)/1000;run.weighedTonnage=bagsForRun(run.clientId).reduce((s,b)=>s+(Number(b.actualNetKg)||0),0)/1000;touch(run);queueRecord('runs',run);}
function nextBagNo(run){const a=state.bags.filter(b=>b&&b.runClientId===run.clientId);return a.length?Math.max(...a.map(b=>Number(b.bagNo)||0))+1:1;}
function nextBagTarget(run){
  const planned=Math.max(0,Number(run.seedTonnage||0)*1000);
  const committed=bagsForRun(run.clientId).filter(b=>b.status!=='cancelled').reduce((s,b)=>s+Number(b.targetKg||0),0);
  const left=planned-committed;
  return left>0.5?Math.min(1000,left):0;
}
function sm4BadgeClass(c){return c==='Высокая'?'good':c==='Низкая'?'bad':'warn';}
function renderSm4WorkState(run){
  const pred=sm4Prediction(run.sm4Hz,run.crop),badge=$('sm4LearningBadge');
  badge.className='badge '+sm4BadgeClass(pred.confidence);badge.textContent=pred.confidence.toLowerCase()+' опора';
  const drift=Math.abs(Number(run.sm4MinPerT)-Number(pred.minPerT));
  $('sm4LearningHint').className='hint '+(drift>0.35?'warn':pred.cls);
  $('sm4LearningHint').innerHTML=drift>0.35
    ?`Текущая работа зафиксирована на <b>${fmt(run.sm4MinPerT,2)} мин/т</b>. Самообучение уже оценивает СМ‑4 в ${fmt(pred.minPerT,2)} мин/т. Новое значение применяем только после следующей калибровки насоса, чтобы не менять дозирование посреди партии.`
    :`Счётчик семян: <b>${fmt(run.sm4MinPerT,2)} мин/т = ${fmt(1000/run.sm4MinPerT,2)} кг/мин</b>. ${esc(pred.text)}`;
  let bag=currentBag();if(bag&&bag.runClientId!==run.clientId){state.activeBagId=null;saveState();bag=null;}
  $('bagIdle').classList.toggle('hidden',!!bag);$('bagRunning').classList.toggle('hidden',!bag);
  if(!bag){const target=nextBagTarget(run),blocked=run.pauseReason==='batch_complete'||run.pauseReason==='stopped';$('bagNo').value=nextBagNo(run);$('bagTargetKg').value=Math.round(target);$('startBag').disabled=blocked||!(target>0.5);$('startBag').textContent=blocked||!(target>0.5)?'Плановый тоннаж набран':'Восстановить счётчик биг-бэга';}else updateBagCounter();
  renderPendingWeights(run);
}
function renderPendingWeights(run){
  const host=$('pendingWeights');host.innerHTML='';
  const rows=bagsForRun(run.clientId).filter(b=>b.status==='completed').slice().reverse();
  if(!rows.length){host.innerHTML='<div class="hint">После завершения первого биг-бэга здесь появится отдельная кнопка фиксации фактического веса.</div>';return;}
  rows.forEach(b=>{
    const row=document.createElement('div');row.className='pendingWeightRow';
    const weighed=Number(b.actualNetKg)>0;
    row.innerHTML=`<div class="meta"><b>Биг-бэг №${fmtInt(b.bagNo)} · ${weighed?'взвешен':'ждёт весов'}</b><span>${fmt(b.activeDurationSec/60,2)} мин · расчётно ${fmt(b.estimatedKg,1)} кг${weighed?' · факт '+fmt(b.actualNetKg,1)+' кг':''}</span></div><button type="button">${weighed?'Изменить вес':'Зафиксировать вес'}</button>`;
    row.querySelector('button').onclick=()=>openBagWeight(b);host.appendChild(row);
  });
}
function openBagWeight(bag){
  if(!bag)return;state.weightBagId=bag.clientId;saveState();
  $('bagWeightTitle').textContent=`Биг-бэг №${fmtInt(bag.bagNo)} — фиксация веса`;
  $('bagWeightInfo').innerHTML=`СМ‑4: <b>${fmt(bag.sm4Hz,1)} Гц</b> · активное время <b>${fmt(bag.activeDurationSec/60,2)} мин</b> · расчётно <b>${fmt(bag.estimatedKg,1)} кг</b>.`;
  $('bagActualKg').value=Number(bag.actualNetKg)>0?Number(bag.actualNetKg).toFixed(1):'';
  $('bagWeightResult').classList.add('hidden');$('bagWeightShade').classList.remove('hidden');setTimeout(()=>$('bagActualKg').focus(),100);
}
function closeBagWeight(){$('bagWeightShade').classList.add('hidden');state.weightBagId=null;saveState();}
$('closeBagWeight').onclick=closeBagWeight;$('bagWeightShade').onclick=e=>{if(e.target===$('bagWeightShade'))closeBagWeight();};
$('saveBagWeight').onclick=()=>{
  const bag=state.bags.find(b=>b.clientId===state.weightBagId&&!b.deletedAt),kg=Number($('bagActualKg').value);if(!bag)return;if(!(kg>0))return alert('Введите фактический вес семян в биг-бэге, кг.');
  const min=Number(bag.activeDurationSec)/60;if(!(min>0))return alert('В этой записи нет корректного активного времени.');
  bag.actualNetKg=kg;bag.actualKgMin=kg/min;bag.actualMinPerT=1000/bag.actualKgMin;bag.deviationPct=bag.modelMinPerT>0?(bag.actualMinPerT-bag.modelMinPerT)/bag.modelMinPerT*100:null;bag.weightRecordedAt=iso();
  const ad=Math.abs(bag.deviationPct),emergency=bagHadEmergency(bag),tooSmall=kg<300;
  bag.learningStatus=bag.modelMinPerT>0&&ad<=8&&!emergency&&!tooSmall?'accepted':'review';touch(bag);queueRecord('bags',bag);
  const run=state.runs.find(r=>r.clientId===bag.runClientId&&!r.deletedAt);if(run){updateRunProcessedFromBags(run);saveState();}
  cloudSync(true);
  $('bagWeightResult').className='resultCard '+(bag.learningStatus==='accepted'?'':'warningCard');
  $('bagWeightResult').innerHTML=`<div class="resultTitle">${bag.learningStatus==='accepted'?'Замер принят в самообучение':'Замер сохранён для проверки'}</div><div class="resultBig">${fmt(bag.actualMinPerT,2)} мин/т</div><div class="metrics">${metric('Фактический вес',fmt(kg,1)+' кг')}${metric('Производительность',fmt(bag.actualKgMin,2)+' кг/мин')}${metric('Отклонение от модели',(bag.deviationPct>=0?'+':'')+fmt(bag.deviationPct,1)+' %')}${metric('СМ‑4',fmt(bag.sm4Hz,1)+' Гц')}${metric('Авария в этом биг-бэге',emergency?'да':'нет')}</div>`;
  if(bag.learningStatus==='review'){
    const why=[];if(ad>8)why.push('отклонение больше 8%');if(emergency)why.push('в интервале был аварийный стоп');if(tooSmall)why.push('фактический вес меньше 300 кг');
    alert('Вес сохранён, но пока не участвует в самообучении: '+why.join(', ')+'. Если запись корректна, её можно вручную подтвердить в Истории.');
  }
  renderHistory();if(currentRun())renderSm4WorkState(currentRun());
};
$('startBag').onclick=()=>{const run=currentRun();if(!run)return alert('Сначала начните работу.');if(currentBag())return;const target=Number($('bagTargetKg').value)||nextBagTarget(run);if(!(target>0))return alert('Для этой партии больше нет планового остатка семян.');createBag(run,target,iso());touch(run);saveState();queueRecord('runs',run);cloudSync(true);renderWork();};
$('finishBag').onclick=()=>{const bag=currentBag(),run=currentRun();if(!(bag&&run))return;const at=iso(),wasPaused=runIsPaused(run),next=closeCurrentBagAt(run,bag,at,{startNext:true});renderWork();if(next){alert(`Биг-бэг №${bag.bagNo} завершён.\nАктивное время: ${fmt(bag.activeDurationSec/60,2)} мин.\nРасчётно обработано: ${fmt(bag.estimatedKg,1)} кг.\nСчётчик биг-бэга №${next.bagNo} запущен автоматически в тот же момент${wasPaused?' и остаётся на паузе до продолжения линии':''}.`);}else{alert(`Биг-бэг №${bag.bagNo} завершён.\nАктивное время: ${fmt(bag.activeDurationSec/60,2)} мин.\nРасчётно обработано: ${fmt(bag.estimatedKg,1)} кг.\nПлановый тоннаж партии набран — счётчики линии остановлены. После фактического взвешивания вес можно внести отдельно.`);}};
$('pauseLine').onclick=()=>pauseLine('pause');
$('normalStop').onclick=requestNormalStop;
$('emergencyStop').onclick=()=>pauseLine('emergency');
$('resumeLine').onclick=resumeLine;
$('stopLineHere').onclick=stopLineHere;
$('confirmNormalStop').onclick=stopLineHere;
$('cancelNormalStop').onclick=resumeLine;
function updateBagCounter(){
  const bag=currentBag();if(!bag)return;const sec=bagActiveSec(bag),kg=estimatedBagKg(bag),target=Number(bag.targetKg)||1000,mm=Math.floor(sec/60),ss=Math.floor(sec%60);
  $('bagKgCounter').textContent=fmt(kg,1)+' кг';$('bagCounterMeta').textContent=`${String(mm).padStart(2,'0')}:${String(ss).padStart(2,'0')} · ${fmt(bag.sm4Hz,1)} Гц · ${fmt(bag.modelMinPerT,2)} мин/т${bag.pausedAt?' · ПАУЗА':''}`;
  const ratio=target>0?kg/target:0;
  $('bagProgress').querySelector('i').style.width=clamp(ratio*100,0,100)+'%';
  const counter=$('bagKgCounter');counter.style.color=ratio>=1?'#b43730':ratio>=.95?'#9a6500':'';
  const warn=$('bagWarning');
  if(ratio>=1){warn.className='hint bad';warn.innerHTML='<b>Расчётная цель достигнута.</b> Приложение не останавливает оборудование автоматически. Зафиксируйте фактический момент наполнения биг-бэга кнопкой ниже.';}
  else if(ratio>=.95){warn.className='hint warn';warn.innerHTML=`До расчётной цели осталось примерно <b>${fmt(Math.max(0,target-kg),1)} кг</b>. Подготовьтесь к смене биг-бэга.`;}
  else{warn.className='hint hidden';warn.textContent='';}
  const run=currentRun();if(run){
    const total=processedSeedKg(run,true),planned=Number(run.seedTonnage||0)*1000,remaining=Math.max(0,planned-total);
    $('processedSeedsSummary').className='hint '+(ratio>=1?'warn':'');$('processedSeedsSummary').innerHTML=`По счётчикам обработано сейчас: <b>${fmt(total,1)} кг</b> (${fmt(total/1000,3)} т). Остаток по плану ≈ <b>${fmt(remaining,1)} кг</b>. Фактические веса биг-бэгов заменяют расчётные значения после взвешивания.`;
    const futureTarget=nextBagTarget(run);$('finishBag').textContent=futureTarget>0.5?'Биг-бэг наполнен → следующий':'Последний биг-бэг наполнен → СТОП линии';
  }
}
let workPumpManual=false;
let workStartMeasureManual=false;
function workCoreMetric(label,value,sub=''){return `<div class="workCoreMetric"><span>${esc(label)}</span><b>${esc(value)}</b>${sub?`<small>${esc(sub)}</small>`:''}</div>`;}
function workBatchDraft(){
  const b=ensureActiveBatch();if(!b)return null;const mode=modeOf(b);
  const tInput=$('workBatchTonnage'),aInput=$('workBatchAmount');
  const typedT=tInput&&tInput.value!==''?Number(tInput.value):NaN;
  const typedA=aInput&&aInput.value!==''?Number(aInput.value):NaN;
  const seedTonnage=typedT>0?typedT:Number(b.seedTonnage);
  const primary=mode==='volume'?(typedA>=0?typedA*1000:Number(b.totalVolumeMl)):(typedA>=0?typedA:Number(b.totalMassG));
  const dose=seedTonnage>0&&primary>=0?primary/seedTonnage:0;
  return{b,mode,seedTonnage,primary,dose};
}
function setWorkBatchEditorFromBatch(b){
  if(!b)return;const mode=modeOf(b),t=$('workBatchTonnage'),a=$('workBatchAmount');
  if(document.activeElement!==t)t.value=Number(b.seedTonnage)>0?String(Number(b.seedTonnage)):'';
  $('workBatchAmountLabel').textContent=mode==='volume'?'Объём смеси, л':'Масса смеси, г';
  a.step=mode==='volume'?'0.01':'1';a.placeholder=mode==='volume'?'Например 35':'Например 21000';
  if(document.activeElement!==a){const v=mode==='volume'?Number(b.totalVolumeMl)/1000:Number(b.totalMassG);a.value=isFinite(v)&&v>=0?String(mode==='volume'?Math.round(v*1000)/1000:Math.round(v)):'';}
}
function commitWorkBatchEdits(silent=false){
  const d=workBatchDraft();if(!d)return false;const {b,mode,seedTonnage,primary}=d;
  if(!(seedTonnage>0)){if(!silent)alert('Масса семян должна быть больше нуля.');return false;}
  if(!(primary>0)){if(!silent)alert(mode==='volume'?'Укажите объём рабочего состава.':'Укажите массу рабочего состава.');return false;}
  let changed=Math.abs(Number(b.seedTonnage)-seedTonnage)>.000001;
  b.seedTonnage=seedTonnage;
  if(mode==='volume'){
    changed=changed||Math.abs(Number(b.totalVolumeMl||0)-primary)>.01;b.totalVolumeMl=primary;b.doseMlPerT=primary/seedTonnage;
  }else{
    changed=changed||Math.abs(Number(b.totalMassG||0)-primary)>.01;b.totalMassG=primary;b.doseGPerT=primary/seedTonnage;
  }
  // recipeKey намеренно не меняем: это та же приготовленная смесь, меняется рабочий тоннаж/доза партии.
  if(changed){touch(b);saveState();queueRecord('batches',b);cloudSync(true);}
  return true;
}
function suggestSm4ForPumpFlow(pumpFlow,dose,crop='Соя'){
  pumpFlow=Number(pumpFlow);dose=Number(dose);if(!(pumpFlow>0&&dose>0))return null;
  const targetMpt=dose/pumpFlow;if(!(targetMpt>0))return null;
  let best=null;
  for(let h=29;h<=32.001;h+=.05){const p=sm4Prediction(h,crop),err=Math.abs(Number(p.minPerT)-targetMpt);if(!best||err<best.err)best={hz:h,minPerT:p.minPerT,err,confidence:p.confidence};}
  if(!best||best.err/targetMpt>.05)return null;best.hz=Math.round(best.hz*10)/10;best.outsideBase=best.hz<29||best.hz>32;return best;
}
function workSetup(){
  const d=workBatchDraft();if(!d)return null;const {b,mode,seedTonnage,primary,dose}=d;
  const sm4Hz=Number($('workSm4Hz').value),sm4=sm4Prediction(sm4Hz,b.crop),mpt=sm4.minPerT>0?Number(sm4.minPerT):NaN,required=dose/mpt,pumpLearn=estimatePumpHz(required,b.recipeKey,mode);
  const pumpHz=Number($('workPumpHz').value),pumpFlow=estimatePumpFlowAtHz(pumpHz,b.recipeKey,mode),sm4FromPump=pumpFlow.flow!==null?suggestSm4ForPumpFlow(pumpFlow.flow,dose,b.crop):null;
  return{b,mode,seedTonnage,primary,dose,sm4Hz,sm4,mpt,required,pumpLearn,pumpHz,pumpFlow,sm4FromPump};
}
function renderWorkSetup(){
  const b=ensureActiveBatch();if(!b)return;setWorkBatchEditorFromBatch(b);
  const s=workSetup();if(!s)return;const {mode,seedTonnage,dose,sm4Hz,sm4,mpt,required,pumpLearn,pumpHz,pumpFlow,sm4FromPump}=s,unit=flowUnit(mode);
  $('workBatchName').textContent=b.recipeName;
  $('workBatchDoseLine').innerHTML=`Расчётная доза: <b>${mode==='volume'?fmt(dose/1000,3)+' л/т':fmtInt(dose)+' г/т'}</b> · можно изменить тоннаж или количество смеси прямо здесь`;
  $('workModeMass').classList.toggle('active',mode==='mass');$('workModeVolume').classList.toggle('active',mode==='volume');

  const sm4Assist=$('workSm4Assist'),pumpAssist=$('workPumpAssist');
  sm4Assist.className='inputAssist';
  if(sm4FromPump&&pumpHz>0){
    const diff=sm4FromPump.hz-sm4Hz,arrow=Math.abs(diff)<.15?'✓':diff>0?'↑':'↓';
    sm4Assist.textContent=`${arrow} ${fmt(sm4FromPump.hz,1)} Гц по фактической настройке насоса${sm4FromPump.outsideBase?' · вне 29–32 Гц':''}`;
    if(Math.abs(diff)>=1.5)sm4Assist.classList.add('attention');
  }else sm4Assist.textContent=`≈ ${fmt(mpt,1)} мин/т · ${fmt(1000/mpt,1)} кг/мин`;

  pumpAssist.className='inputAssist';
  if(pumpLearn.hz!==null){
    const diff=pumpHz>0?pumpLearn.hz-pumpHz:0,arrow=pumpHz>0?(Math.abs(diff)<.15?'✓':diff>0?'↑':'↓'):'≈';
    pumpAssist.textContent=`${arrow} ${fmt(pumpLearn.hz,1)} Гц рекомендует приложение`;
    if(pumpHz>0&&Math.abs(diff)>=2) pumpAssist.classList.add('attention');
  }else pumpAssist.textContent=pumpLearn.points? 'Нет надёжной рекомендации · '+pumpLearn.text : 'Подсказка появится после фактической точки насоса';

  $('workTargets').innerHTML=workCoreMetric('Время на 1 т',fmt(mpt,2)+' мин',`${fmt(sm4Hz,1)} Гц СМ‑4`)+workCoreMetric('Рабочий состав на 1 т',mode==='volume'?fmt(dose/1000,3)+' л/т':fmtInt(dose)+' г/т','целевая доза');
  $('workPlanLine').textContent=`План партии: ${fmt(seedTonnage,2)} т · ориентир ${duration(seedTonnage*mpt)}.`;

  $('workSm4SetupHint').className='hint '+sm4.cls;$('workSm4SetupHint').innerHTML=`СМ‑4: <b>${fmt(sm4Hz,1)} Гц → ${fmt(mpt,2)} мин/т (${fmt(1000/mpt,2)} кг/мин)</b>. ${esc(sm4.text)} Фактические веса биг-бэгов уточняют модель.`;
  const ph=$('workPumpSetupHint');
  if(!(pumpHz>0)){ph.className='hint warn';ph.innerHTML=pumpLearn.hz!==null?`Для требуемой подачи ${fmt(required,0)} ${unit} ориентир насоса <b>${fmt(pumpLearn.hz,1)} Гц</b>. Ввести можно любую фактически выставленную частоту.`:'Калибровок насоса для этой смеси нет. Введите фактическую частоту вручную — запуск всё равно разрешён.';}
  else if(pumpFlow.flow!==null){const err=(pumpFlow.flow-required)/Math.max(required,1)*100,cls=Math.abs(err)<=8?'good':Math.abs(err)<=20?'warn':'bad';ph.className='hint '+cls;ph.innerHTML=`По истории насоса ${fmt(pumpHz,1)} Гц ≈ <b>${fmt(pumpFlow.flow,0)} ${unit}</b>, требуется ${fmt(required,0)} ${unit} (${err>=0?'+':''}${fmt(err,1)}%). ${sm4FromPump?`Если насос оставить ${fmt(pumpHz,1)} Гц, ориентир СМ‑4 — <b>${fmt(sm4FromPump.hz,1)} Гц</b>.`:''}`;}
  else{ph.className='hint warn';ph.innerHTML=`Насос <b>${fmt(pumpHz,1)} Гц</b> задан вручную. ${esc(pumpFlow.text||'Для этой частоты нет надёжной оценки подачи.')} Работу контролируйте по фактической массе/объёму.`;}
  $('workMetrics').innerHTML=metric('План партии',duration(seedTonnage*mpt))+metric('Требуемая подача',fmt(required,0)+' '+unit)+(pumpFlow.flow!==null?metric('Оценка насоса',fmt(pumpFlow.flow,0)+' '+unit,pumpFlow.confidence+' опора'):metric('Оценка насоса','нет данных','частота задаётся вручную'));

  if(!currentRun()&&!workStartMeasureManual){
    const startVal=mode==='volume'?s.primary/1000:s.primary;
    if(isFinite(startVal)&&startVal>0)$('workStartMeasure').value=mode==='volume'?String(Math.round(startVal*1000)/1000):String(Math.round(startVal));
  }
}
function renderRunningTargets(run,b){
  const mode=modeOf(run),dose=primaryDose(b);
  $('runningTargets').innerHTML=workCoreMetric('Время на 1 т',fmt(run.sm4MinPerT,2)+' мин',`${fmt(run.sm4Hz,1)} Гц СМ‑4`)+workCoreMetric('Рабочий состав на 1 т',mode==='volume'?fmt(dose/1000,3)+' л/т':fmtInt(dose)+' г/т','целевая доза');
  $('workActualLiquidLabel').textContent=mode==='volume'?'Состав израсходован, л':'Состав израсходован, г';
  $('workActualLiquid').step=mode==='volume'?'0.01':'1';
  $('workActualLiquid').placeholder=mode==='volume'?'Например 5.25':'Например 5250';
}
function actualCheckValues(){
  const r=currentRun(),b=r?state.batches.find(x=>x.clientId===r.batchClientId&&!x.deletedAt):null;if(!(r&&b))return null;const mode=modeOf(r),seedKg=Number($('workActualSeedsKg').value),rawLiquid=$('workActualLiquid').value===''?null:Number($('workActualLiquid').value),used=rawLiquid===null?null:mode==='volume'?rawLiquid*1000:rawLiquid,tons=seedKg/1000,elapsed=elapsedRunMin(r),targetDose=primaryDose(b),actualMpt=tons>0?elapsed/tons:null,actualDose=tons>0&&used!==null&&used>=0?used/tons:null,timeDev=actualMpt!==null&&Number(r.sm4MinPerT)>0?(actualMpt-Number(r.sm4MinPerT))/Number(r.sm4MinPerT)*100:null,doseDev=actualDose!==null&&targetDose>0?(actualDose-targetDose)/targetDose*100:null;return{r,b,mode,seedKg,rawLiquid,used,tons,elapsed,targetDose,actualMpt,actualDose,timeDev,doseDev};
}
function renderActualCheck(){
  const v=actualCheckValues();if(!v)return;
  $('workActualTimeResult').textContent=v.actualMpt===null?'Фактическое время на 1 т —':`Факт: ${fmt(v.actualMpt,2)} мин/т (${v.timeDev>=0?'+':''}${fmt(v.timeDev,1)}%)`;
  $('workActualDoseResult').textContent=v.actualDose===null?'Фактическая доза —':`Факт: ${v.mode==='volume'?fmt(v.actualDose/1000,3)+' л/т':fmtInt(v.actualDose)+' г/т'} (${v.doseDev>=0?'+':''}${fmt(v.doseDev,1)}%)`;
  const box=$('workActualCompare');
  if(!(v.seedKg>0)||!(v.rawLiquid>=0)||$('workActualLiquid').value===''){box.className='actualCompare muted';box.textContent='Введите фактические семена и расход состава — приложение сразу сравнит их с целью.';return;}
  const worst=Math.max(Math.abs(v.timeDev||0),Math.abs(v.doseDev||0));box.className='actualCompare '+(worst<=5?'good':worst<=12?'warn':'bad');
  box.innerHTML=`За активные <b>${fmt(v.elapsed,2)} мин</b>: семена <b>${fmt(v.seedKg,1)} кг</b>, состав <b>${amountLabel(v.mode,v.used)}</b>. Время на тонну ${v.timeDev>=0?'+':''}${fmt(v.timeDev,1)}%, доза ${v.doseDev>=0?'+':''}${fmt(v.doseDev,1)}% к цели.`;
}
function renderWork(){
  const b=ensureActiveBatch(),run=currentRun();$('workNoReady').classList.toggle('hidden',!!b);$('workBody').classList.toggle('hidden',!b);if(!b)return;const mode=modeOf(b);
  $('workStartLabel').textContent=mode==='volume'?'Объём смеси перед работой, л':'Показание весов перед работой, г';$('workStartMeasure').step=mode==='volume'?'0.01':'1';$('workStartMeasure').placeholder=mode==='volume'?'Например 45':'Например 45000';
  $('checkpointLabel').textContent=mode==='volume'?'Текущий объём смеси, л':'Текущее показание весов, г';$('checkpointMeasure').step=mode==='volume'?'0.01':'1';$('checkpointMeasure').placeholder=mode==='volume'?'Например 38.5':'Например 39000';
  $('workEndLabel').textContent=mode==='volume'?'Объём смеси после работы, л':'Показание весов после работы, г';$('workEndMeasure').step=mode==='volume'?'0.01':'1';
  $('workSetupCard').classList.toggle('hidden',!!run);$('workStartCard').classList.toggle('hidden',!!run);$('workRunningCard').classList.toggle('hidden',!run);
  if(!run){renderWorkSetup();return;}
  if(run.batchClientId!==b.clientId){const rb=state.batches.find(x=>x.clientId===run.batchClientId&&!x.deletedAt);if(rb){state.activeBatchId=rb.clientId;saveState();return renderWork();}}
  const rmode=modeOf(run),pflow=calibratedFlow(run),unit=flowUnit(rmode);
  $('runningSetupSummary').innerHTML=metric('Партия',b.recipeName)+metric('СМ‑4',fmt(run.sm4Hz,1)+' Гц')+metric('Насос',fmt(run.pumpHz,1)+' Гц')+(pflow!==null?metric('Оценка насоса',fmt(pflow,0)+' '+unit):metric('Оценка насоса','без калибровки'));
  renderRunningTargets(run,b);renderCheckpoints(run);renderSm4WorkState(run);updateWorkTimer();updateBagCounter();const kg=processedSeedKg(run,true);$('processedSeedsSummary').innerHTML=`По счётчикам обработано сейчас: <b>${fmt(kg,1)} кг</b> (${fmt(kg/1000,3)} т).`;
  renderActualCheck();
}
$('changeBatchWork').onclick=()=>{if(currentRun())return alert('Во время работы партию менять нельзя.');commitWorkBatchEdits(true);openBatchPicker('work');};
$('workModeMass').onclick=()=>{if(currentRun())return;commitWorkBatchEdits(true);workStartMeasureManual=false;switchBatchMode('mass');};$('workModeVolume').onclick=()=>{if(currentRun())return;commitWorkBatchEdits(true);workStartMeasureManual=false;switchBatchMode('volume');};
$('workBatchTonnage').addEventListener('input',()=>{if(!currentRun())renderWorkSetup();});
$('workBatchAmount').addEventListener('input',()=>{if(!currentRun())renderWorkSetup();});
$('workBatchTonnage').addEventListener('change',()=>{if(!currentRun()){commitWorkBatchEdits();renderWorkSetup();}});
$('workBatchAmount').addEventListener('change',()=>{if(!currentRun()){commitWorkBatchEdits();renderWorkSetup();}});
$('workSm4Hz').addEventListener('input',()=>{if(!currentRun())renderWorkSetup();});
$('workPumpHz').addEventListener('input',()=>{workPumpManual=true;if(!currentRun())renderWorkSetup();});
$('workStartMeasure').addEventListener('input',()=>{workStartMeasureManual=true;});
$('workActualSeedsKg').addEventListener('input',renderActualCheck);$('workActualLiquid').addEventListener('input',renderActualCheck);
$('saveActualCheck').onclick=()=>{
  const v=actualCheckValues();if(!v)return;
  if(!(v.seedKg>0))return alert('Введите фактическую массу обработанных семян в кг.');
  if($('workActualLiquid').value===''||!isFinite(v.rawLiquid)||v.rawLiquid<0)return alert(v.mode==='volume'?'Введите фактически израсходованный объём состава в литрах.':'Введите фактически израсходованную массу состава в граммах.');
  const cp={at:iso(),measurementMode:v.mode,inputKind:'direct_used',elapsedMin:v.elapsed,processedSeedKg:v.seedKg,usedValue:v.used,expectedValue:v.targetDose*v.tons,deviationPct:v.doseDev,actualMinPerT:v.actualMpt,timeDeviationPct:v.timeDev,actualDose:v.actualDose};
  v.r.checkpoints=v.r.checkpoints||[];v.r.checkpoints.push(cp);touch(v.r);saveState();queueRecord('runs',v.r);cloudSync(true);renderCheckpoints(v.r);
  $('checkpointResult').className='hint good';$('checkpointResult').innerHTML=`Контроль сохранён: <b>${fmt(v.seedKg,1)} кг</b> семян · <b>${amountLabel(v.mode,v.used)}</b> состава · ${v.mode==='volume'?fmt(v.actualDose/1000,3)+' л/т':fmtInt(v.actualDose)+' г/т'}.`;$('checkpointResult').classList.remove('hidden');
  $('workActualSeedsKg').value='';$('workActualLiquid').value='';renderActualCheck();
};
$('startWork').onclick=()=>{
  if(currentRun())return; if(state.runs.some(r=>r.status==='running'&&!r.deletedAt))return alert('В истории есть незавершённая работа. Сначала восстановите её.');if(!commitWorkBatchEdits())return;const s=workSetup(),raw=$('workStartMeasure').value,v=Number(raw);if(!s)return alert('Сначала выберите партию.');if(!(s.sm4Hz>0&&s.sm4Hz<=50))return alert('Укажите частоту СМ‑4.');if(!(s.pumpHz>0&&s.pumpHz<=50))return alert('Укажите фактическую частоту насоса.');if(raw===''||!isFinite(v)||v<=0)return alert(s.mode==='volume'?'Введите стартовый объём смеси в литрах.':'Введите стартовое показание массы в граммах.');
  const at=iso(),pumpEstimated=s.pumpFlow.flow;const r={clientId:uuid(),batchClientId:s.b.clientId,recipeKey:s.b.recipeKey,crop:s.b.crop,measurementMode:s.mode,seedTonnage:s.seedTonnage,sm4Hz:s.sm4Hz,sm4MinPerT:s.mpt,plannedDurationMin:s.seedTonnage*s.mpt,requiredFlowGMin:s.mode==='mass'?s.required:null,requiredFlowMlMin:s.mode==='volume'?s.required:null,pumpHz:s.pumpHz,calibratedFlowGMin:s.mode==='mass'?pumpEstimated:null,calibratedFlowMlMin:s.mode==='volume'?pumpEstimated:null,startMassG:s.mode==='mass'?v:null,endMassG:null,startVolumeMl:s.mode==='volume'?v*1000:null,endVolumeMl:null,processedTonnage:0,checkpoints:[],lineEvents:[],pausedAt:null,pausedDurationSec:0,pauseReason:null,activeDurationSec:null,emergencyCount:0,startedAt:at,endedAt:null,status:'running',notes:pumpEstimated===null?'Запуск без калибровки насоса':'',createdAt:at,updatedAt:at};
  lineEvent(r,'run_start',at,{sm4Hz:r.sm4Hz,pumpHz:r.pumpHz,pumpEstimate:pumpEstimated,targetDose:s.dose,seedTonnage:s.seedTonnage});state.runs.push(r);state.activeRunId=r.clientId;s.b.status='running';touch(s.b);createBag(r,Math.min(1000,s.seedTonnage*1000),at);saveState();queueRecord('runs',r);queueRecord('batches',s.b);cloudSync(true);$('workActualSeedsKg').value='';$('workActualLiquid').value='';$('checkpointResult').className='hint hidden';$('checkpointResult').textContent='';renderWork();
};
function elapsedRunMin(run){return runActiveSec(run)/60;}
function updateLineControls(run){
  if(!run)return;
  const paused=runIsPaused(run),reason=run.pauseReason||'',status=$('lineStatus'),hint=$('lineStateHint');
  if(paused){
    if(reason==='emergency'){
      status.className='lineStatus emergency';status.textContent='АВАРИЙНЫЙ СТОП';
      hint.textContent='Счётчики заморожены в момент нажатия. После устранения причины продолжите работу либо завершите партию здесь. Биг-бэг с аварией автоматически потребует ручного подтверждения перед самообучением.';
    }else if(reason==='stop_pending'){
      status.className='lineStatus stopped';status.textContent='СТОП — ПОДТВЕРЖДЕНИЕ';
      hint.textContent='Счётчики уже заморожены. Если физическая линия действительно остановлена — подтвердите завершение. Если нажали случайно — продолжите работу.';
    }else if(reason==='batch_complete'){
      status.className='lineStatus complete';status.textContent='ПЛАНОВЫЙ ТОННАЖ НАБРАН';
      hint.textContent='Последний биг-бэг зафиксирован, расчётные счётчики остановлены в тот же момент. Внесите финальный остаток состава и завершите работу.';
    }else if(reason==='stopped'){
      status.className='lineStatus stopped';status.textContent='РАБОТА ОСТАНОВЛЕНА';
      hint.textContent='Текущий биг-бэг сохранён как частичный. Счётчики больше не идут. Можно внести финальный остаток состава и завершить работу.';
    }else{
      status.className='lineStatus paused';status.textContent='ПАУЗА';
      hint.textContent='СМ-4 и насос должны быть физически остановлены. Активное время и расчёт килограммов не увеличиваются.';
    }
  }else{
    status.className='lineStatus running';status.textContent='ЛИНИЯ РАБОТАЕТ';
    hint.textContent='СМ-4, насос и текущий биг-бэг идут по одному активному времени. Первый биг-бэг стартовал тем же timestamp, что и работа.';
  }
  const permanent=reason==='batch_complete'||reason==='stopped';
  $('pauseLine').classList.toggle('hidden',paused);
  $('normalStop').classList.toggle('hidden',paused);
  $('emergencyStop').classList.toggle('hidden',paused);
  $('resumeLine').classList.toggle('hidden',!paused||permanent||reason==='stop_pending');
  $('stopLineHere').classList.toggle('hidden',!paused||permanent||reason==='stop_pending');
  $('normalStopConfirm').classList.toggle('hidden',reason!=='stop_pending');
  $('finishWork').disabled=!permanent;
  $('finishWorkHint').className='hint '+(permanent?'good':'warn');
  $('finishWorkHint').textContent=permanent?'Физическая линия остановлена. После финального замера состава работу можно закрыть.':'Сначала остановите физическую линию: обычный «СТОП РАБОТЫ» или завершение последнего планового биг-бэга.';
}
function updateWorkTimer(){const r=currentRun();if(!r)return;const activeSec=Math.floor(runActiveSec(r)),wallSec=Math.floor(runWallSec(r)),mm=Math.floor(activeSec/60),ss=activeSec%60,wmm=Math.floor(wallSec/60),wss=wallSec%60;$('workTimer').textContent=String(mm).padStart(2,'0')+':'+String(ss).padStart(2,'0');const kg=processedSeedKg(r,true),remainKg=Math.max(0,Number(r.seedTonnage)*1000-kg),remain=remainKg/1000*Number(r.sm4MinPerT);$('workRemain').textContent=`Активное ${String(mm).padStart(2,'0')}:${String(ss).padStart(2,'0')} · всего ${String(wmm).padStart(2,'0')}:${String(wss).padStart(2,'0')} · осталось ≈ ${fmt(remainKg,0)} кг / ${duration(remain)}`;$('workProgress').querySelector('i').style.width=clamp(kg/(Number(r.seedTonnage)*1000)*100,0,100)+'%';updateLineControls(r);updateBagCounter();renderActualCheck();}
$('addCheckpoint').onclick=()=>{
  const r=currentRun(),b=activeBatch(),v=Number($('checkpointMeasure').value);if(!r)return;if(!(v>0))return alert(modeOf(r)==='volume'?'Введите текущий объём смеси в литрах.':'Введите текущее показание весов в граммах.');const mode=modeOf(r),current=mode==='volume'?v*1000:v,start=mode==='volume'?r.startVolumeMl:r.startMassG;if(current>start)return alert(mode==='volume'?'Текущий объём не может быть больше стартового.':'Текущее показание не может быть больше стартового.');
  const used=start-current,seedKg=processedSeedKg(r,true),dose=primaryDose(b),expected=seedKg>0?dose*(seedKg/1000):requiredFlow(r)*elapsedRunMin(r),dev=expected>0?(used-expected)/expected*100:0,avgDose=seedKg>0?used/(seedKg/1000):null,cp={at:iso(),measurementMode:mode,elapsedMin:elapsedRunMin(r),processedSeedKg:seedKg,usedValue:used,expectedValue:expected,deviationPct:dev};if(mode==='volume')cp.volumeMl=current;else cp.massG=current;r.checkpoints=r.checkpoints||[];r.checkpoints.push(cp);touch(r);saveState();queueRecord('runs',r);cloudSync(true);const cls=Math.abs(dev)<=5?'good':Math.abs(dev)<=12?'warn':'bad';$('checkpointResult').className='hint '+cls;$('checkpointResult').innerHTML=`По счётчику обработано <b>${fmt(seedKg,1)} кг</b>. Использовано состава <b>${amountLabel(mode,used)}</b>, по целевой дозе должно быть ${amountLabel(mode,expected)}. Отклонение ${(dev>=0?'+':'')+fmt(dev,1)}%.${avgDose!==null?' Фактическая доза: <b>'+(mode==='volume'?fmt(avgDose/1000,3)+' л/т':fmtInt(avgDose)+' г/т')+'</b>.':''}`;renderCheckpoints(r);$('checkpointMeasure').value='';
};
function renderCheckpoints(r){
  const host=$('checkpointsList');host.innerHTML='';const runMode=modeOf(r);
  (r.checkpoints||[]).slice().reverse().forEach(cp=>{
    const mode=cp.measurementMode||runMode,d=document.createElement('div');d.className='checkpointRow';
    if(cp.inputKind==='direct_used'){
      const used=Number(cp.usedValue||0),dose=Number(cp.actualDose),time=Number(cp.actualMinPerT),doseDev=Number(cp.deviationPct),timeDev=Number(cp.timeDeviationPct);
      d.innerHTML=`<div><b>${new Date(cp.at).toLocaleTimeString('ru-RU',{hour:'2-digit',minute:'2-digit'})} · факт</b><br><span>семена ${fmt(cp.processedSeedKg||0,1)} кг · состав ${amountLabel(mode,used)}</span></div><div style="text-align:right"><b>${mode==='volume'?fmt(dose/1000,3)+' л/т':fmtInt(dose)+' г/т'}</b><br><span>${fmt(time,2)} мин/т · ${doseDev>=0?'+':''}${fmt(doseDev,1)}%</span></div>`;
    }else{
      const current=mode==='volume'?(cp.volumeMl??null):(cp.massG??null);
      d.innerHTML=`<div><b>${new Date(cp.at).toLocaleTimeString('ru-RU',{hour:'2-digit',minute:'2-digit'})} · остаток</b><br><span>${current===null?'—':mode==='volume'?fmt(current/1000,3)+' л':fmtG(current)} · семена ${fmt(cp.processedSeedKg||0,1)} кг</span></div><div style="text-align:right"><b>${(cp.deviationPct>=0?'+':'')+fmt(cp.deviationPct,1)}%</b><br><span>к дозе</span></div>`;
    }
    host.appendChild(d);
  });
}
$('finishWork').onclick=()=>{
  const r=currentRun(),b=activeBatch(),rawEnd=$('workEndMeasure').value,v=Number(rawEnd);if(!r)return;
  if(!['stopped','batch_complete'].includes(r.pauseReason||''))return alert('Сначала остановите физическую линию. Финальное завершение доступно только после «СТОП РАБОТЫ» или завершения последнего планового биг-бэга.');
  if(currentBag())return alert('Сначала завершите текущий биг-бэг.');if(rawEnd===''||!isFinite(v)||v<0)return alert(modeOf(r)==='volume'?'Введите финальный объём смеси в литрах.':'Введите финальное показание весов в граммах.');const mode=modeOf(r),end=mode==='volume'?v*1000:v,start=mode==='volume'?r.startVolumeMl:r.startMassG;if(end>start)return alert(mode==='volume'?'Финальный объём не может быть больше стартового.':'Финальное показание не может быть больше стартового.');
  if(bagsForRun(r.clientId).some(x=>x.status==='completed'&&!(x.modelMinPerT>0)&&!(x.actualNetKg>0)))return alert('При работе без достоверной калибровки внесите вес каждого завершённого биг-бэга.');const seedKg=processedSeedKg(r,false);if(!(seedKg>0)&&!confirm('Нет ни одного завершённого счётчика биг-бэга. Завершить работу без фиксации обработанных килограммов?'))return;
  if(mode==='volume')r.endVolumeMl=end;else r.endMassG=end;r.processedTonnage=seedKg>0?seedKg/1000:0;const physicalEndAt=r.pausedAt||iso(),physicalEndMs=new Date(physicalEndAt).getTime();r.activeDurationSec=runActiveSec(r,physicalEndMs);r.endedAt=physicalEndAt;lineEvent(r,'run_finish',physicalEndAt,{processedSeedKg:seedKg});r.pausedAt=null;r.pauseReason=null;r.status='completed';touch(r);b.status='completed';touch(b);state.activeRunId=null;state.activeBagId=null;saveState();queueRecord('runs',r);queueRecord('batches',b);cloudSync(true);const used=start-end,actualDose=r.processedTonnage>0?used/r.processedTonnage:null,targetDose=primaryDose(b),doseErr=actualDose!==null&&targetDose>0?(actualDose-targetDose)/targetDose*100:null,doseTxt=mode==='volume'?fmt(actualDose/1000,3)+' л/т':fmtInt(actualDose)+' г/т',pendingWeights=bagsForRun(r.clientId).filter(x=>x.status==='completed'&&!(Number(x.actualNetKg)>0)).length;alert(`Работа сохранена.\nОбработано по счётчикам: ${fmt(r.processedTonnage*1000,1)} кг.\nФактический расход состава: ${amountLabel(mode,used)}.\nФактическая доза: ${doseTxt} (${doseErr>=0?'+':''}${fmt(doseErr,1)}% к расчёту).${pendingWeights?`\nБиг-бэгов ожидают взвешивания: ${pendingWeights}. После ввода веса тоннаж работы будет уточнён автоматически.`:''}`);$('workStartMeasure').value='';$('workEndMeasure').value='';$('workActualSeedsKg').value='';$('workActualLiquid').value='';workStartMeasureManual=false;renderWork();
};

function statusRu(s){return({prepared:'смесь готова',calibrating:'калибровка',ready:'готово к работе',running:'в работе',completed:'завершено',cancelled:'отменено',planned:'запланировано'}[s]||s||'—');}
function renderHistory(){
  qsa('[data-history-tab]').forEach(b=>b.classList.toggle('active',b.dataset.historyTab===historyTab));
  const acceptedPump=state.calibrations.filter(c=>c.accepted&&!c.deletedAt),recipes=new Set(acceptedPump.map(c=>c.recipeKey));
  const weighed=state.bags.filter(b=>!b.deletedAt&&Number(b.actualNetKg)>0),acceptedBags=weighed.filter(b=>b.learningStatus==='accepted');
  $('learningSummary').innerHTML=metric('Насос — точек',String(acceptedPump.length))+metric('СМ‑4 — в обучении',String(acceptedBags.length))+metric('Взвешено биг-бэгов',String(weighed.length))+metric('Работ',String(state.runs.filter(x=>x.status==='completed'&&!x.deletedAt).length));
  $('cloudStatus').textContent=cloudText;
  const host=$('historyList');host.innerHTML='';let arr=[];
  if(historyTab==='batches')arr=state.batches.filter(x=>!x.deletedAt).sort((a,b)=>String(b.createdAt).localeCompare(String(a.createdAt)));
  if(historyTab==='calibrations')arr=state.calibrations.filter(x=>!x.deletedAt).sort((a,b)=>String(b.occurredAt).localeCompare(String(a.occurredAt)));
  if(historyTab==='bags'){
    const curve=document.createElement('article');curve.className='historyCard';
    const points=sm4LearningCurve('Соя');
    curve.innerHTML=`<div class="historyTop"><h3>Самообучение СМ‑4 — соя</h3><span class="badge">${acceptedBags.filter(b=>b.crop==='Соя').length} факт. взвеш.</span></div><div class="sm4Curve">${points.map(p=>`<div class="sm4Point"><span>${fmt(p.hz,0)} Гц · ${esc(p.confidence)}</span><b>${fmt(p.minPerT,2)} мин/т</b><span>${fmt(p.kgMin,2)} кг/мин · ${p.realPoints} факт.</span></div>`).join('')}</div><div class="hint" style="margin-top:10px">Стартовые точки 2026: 29→37, 30→36, 31→35, 32→34 мин/т. Фактические взвешивания получают больший вес в модели; сильно отличающиеся замеры сначала требуют подтверждения.</div>`;
    host.appendChild(curve);
    arr=state.bags.filter(x=>!x.deletedAt).sort((a,b)=>String(b.startedAt||b.createdAt).localeCompare(String(a.startedAt||a.createdAt)));
  }
  if(historyTab==='runs')arr=state.runs.filter(x=>!x.deletedAt).sort((a,b)=>String(b.startedAt||b.createdAt).localeCompare(String(a.startedAt||a.createdAt)));
  const search=normalize($('historySearch').value);if(search)arr=arr.filter(x=>normalize(JSON.stringify(x)).includes(search));$('historyFound').textContent='Записей: '+arr.length+(search?' · по вашему запросу':'');if(!arr.length){if(historyTab!=='bags')host.innerHTML='<div class="empty">Нет записей. Приготовьте смесь или измените запрос поиска.</div>';else host.insertAdjacentHTML('beforeend','<div class="empty">Фактических биг-бэгов пока нет.</div>');return;}
  arr.forEach(x=>host.appendChild(historyCard(x,historyTab)));
}
qsa('[data-history-tab]').forEach(b=>b.onclick=()=>{historyTab=b.dataset.historyTab;renderHistory();});
function deleteCalibration(x){
  if(!x||x.deletedAt)return;const suffix=x.accepted?' Эта точка больше не будет участвовать в самообучении и не будет использоваться как рабочая калибровка.':'';if(!confirm('Удалить эту калибровку?'+suffix))return;x.deletedAt=iso();x.updatedAt=iso();queueRecord('calibrations',x);const b=state.batches.find(b=>b.clientId===x.batchClientId&&!b.deletedAt);if(b&&x.accepted&&!acceptedForBatch(b)&&!['running','completed'].includes(b.status)){b.status='prepared';touch(b);queueRecord('batches',b);}saveState();cloudSync(true);renderHistory();renderCalibration();renderWork();
}
function setBagLearning(x,status){
  if(!x||x.deletedAt||!(Number(x.actualNetKg)>0))return;x.learningStatus=status;touch(x);queueRecord('bags',x);saveState();cloudSync(true);renderHistory();renderCalibration();renderWork();
}
function deleteBagRecord(x){
  if(!x||x.deletedAt)return;if(x.status==='running')return alert('Текущий биг-бэг нельзя удалить. Сначала зафиксируйте остановку.');if(!confirm(`Удалить запись биг-бэга №${x.bagNo}? Она будет исключена из самообучения и из расчёта обработанного тоннажа.`))return;
  x.deletedAt=iso();x.learningStatus='excluded';touch(x);queueRecord('bags',x);if(state.activeBagId===x.clientId)state.activeBagId=null;const run=state.runs.find(r=>r.clientId===x.runClientId&&!r.deletedAt);if(run){updateRunProcessedFromBags(run);queueRecord('runs',run);}saveState();cloudSync(true);renderHistory();renderWork();renderCalibration();
}
function historyCard(x,type){
  const d=document.createElement('article');d.className='historyCard';const mode=modeOf(x);
  if(type==='batches'){d.innerHTML=`<div class="historyTop"><h3>${esc(x.recipeName)}</h3><span class="badge">${esc(statusRu(x.status))}</span></div><div style="margin-top:7px"><span class="modeBadge ${mode==='volume'?'volume':''}">${mode==='volume'?'по объёму':'по массе'}</span></div><div class="historyMeta"><div>Культура: <b>${esc(x.crop)}</b></div><div>Тоннаж: <b>${fmt(x.seedTonnage,2)} т</b></div><div>${mode==='volume'?'Объём':'Масса'}: <b>${esc(totalLabel(x))}</b></div><div>Доза: <b>${esc(doseLabel(x))}</b></div></div>`;}
  else if(type==='calibrations'){const actual=flowValue(x);d.innerHTML=`<div class="historyTop"><h3>${fmt(x.pumpHz,1)} Гц → ${fmt(actual,0)} ${flowUnit(mode)}</h3><span class="badge ${x.accepted?'good':'warn'}">${x.accepted?'в обучении':'тестовая'}</span></div><div style="margin-top:7px"><span class="modeBadge ${mode==='volume'?'volume':''}">${mode==='volume'?'по объёму':'по массе'}</span></div><div class="historyMeta"><div>Фактическая подача: <b>${fmt(actual,0)} ${flowUnit(mode)}</b></div><div>Насос: <b>${fmt(x.pumpHz,1)} Гц</b></div><div>Интервал: <b>${fmt(x.durationSec/60,2)} мин</b></div><div>СМ‑4: <b>не относится к калибровке</b></div></div><div class="historyActions"><button class="miniDanger" type="button">Удалить</button></div>`;d.querySelector('.miniDanger').onclick=()=>deleteCalibration(x);}
  else if(type==='bags'){
    const weighed=Number(x.actualNetKg)>0,learn=x.learningStatus||'pending_weight',badgeClass=learn==='accepted'?'good':learn==='review'?'warn':'';
    d.classList.toggle('learningReview',learn==='review');
    const emergency=bagHadEmergency(x);
    d.innerHTML=`<div class="historyTop"><h3>Биг-бэг №${fmtInt(x.bagNo)} · ${fmt(x.sm4Hz,1)} Гц</h3><span class="badge ${badgeClass}">${weighed?(learn==='accepted'?'в обучении':learn==='review'?'нужно подтвердить':'исключён'):'ждёт весов'}</span></div><div class="historyMeta"><div>Цель: <b>${fmt(x.targetKg,0)} кг</b></div><div>Активное время: <b>${fmt(Number(x.activeDurationSec||0)/60,2)} мин</b></div><div>Расчётно: <b>${fmt(x.estimatedKg,1)} кг</b></div><div>Факт. вес: <b>${weighed?fmt(x.actualNetKg,1)+' кг':'—'}</b></div><div>Модель на старте: <b>${fmt(x.modelMinPerT,2)} мин/т</b></div><div>Факт. СМ‑4: <b>${weighed?fmt(x.actualMinPerT,2)+' мин/т':'—'}</b></div><div>Авария в интервале: <b>${emergency?'да':'нет'}</b></div>${weighed?`<div>Отклонение: <b>${(x.deviationPct>=0?'+':'')+fmt(x.deviationPct,1)}%</b></div><div>Производительность: <b>${fmt(x.actualKgMin,2)} кг/мин</b></div>`:''}</div><div class="historyActions">${x.status==='completed'?`<button class="miniBtn weightBtn" type="button">${weighed?'Изменить вес':'Зафиксировать вес'}</button>`:''}${weighed&&learn!=='accepted'?'<button class="miniBtn acceptBtn" type="button">Использовать в обучении</button>':''}${weighed&&learn==='accepted'?'<button class="miniBtn excludeBtn" type="button">Исключить из обучения</button>':''}<button class="miniDanger deleteBagBtn" type="button">Удалить запись</button></div>`;
    const wb=d.querySelector('.weightBtn');if(wb)wb.onclick=()=>openBagWeight(x);const ab=d.querySelector('.acceptBtn');if(ab)ab.onclick=()=>setBagLearning(x,'accepted');const eb=d.querySelector('.excludeBtn');if(eb)eb.onclick=()=>setBagLearning(x,'excluded');d.querySelector('.deleteBagBtn').onclick=()=>deleteBagRecord(x);
  }
  else{const start=mode==='volume'?x.startVolumeMl:x.startMassG,end=mode==='volume'?x.endVolumeMl:x.endMassG,used=start!==null&&start!==undefined&&end!==null&&end!==undefined?start-end:null,tons=Number(x.processedTonnage??0)||0,actualDose=used!==null&&tons>0?used/tons:null,bagCount=bagsForRun(x.clientId).filter(b=>b.status==='completed').length,weighedCount=bagsForRun(x.clientId).filter(b=>Number(b.actualNetKg)>0).length;d.innerHTML=`<div class="historyTop"><h3>${esc(x.crop||'Работа')}</h3><span class="badge ${x.status==='completed'?'good':''}">${esc(statusRu(x.status))}</span></div><div style="margin-top:7px"><span class="modeBadge ${mode==='volume'?'volume':''}">${mode==='volume'?'по объёму':'по массе'}</span></div><div class="historyMeta"><div>Семена: <b>${fmt(tons,3)} т</b></div><div>Биг-бэги: <b>${bagCount} · взвешено ${weighedCount}</b></div><div>СМ‑4: <b>${fmt(x.sm4Hz,1)} Гц · ${fmt(x.sm4MinPerT,2)} мин/т</b></div><div>Насос: <b>${fmt(x.pumpHz,1)} Гц</b></div><div>Оценка насоса: <b>${calibratedFlow(x)===null?'без калибровки':fmt(calibratedFlow(x),0)+' '+flowUnit(mode)}</b></div><div>Факт. расход: <b>${used===null?'—':amountLabel(mode,used)}</b></div><div>Факт. доза: <b>${actualDose===null?'—':mode==='volume'?fmt(actualDose/1000,3)+' л/т':fmtInt(actualDose)+' г/т'}</b></div></div>`;}
  const date=document.createElement('div');date.className='proDate';const when=x.occurredAt||x.startedAt||x.createdAt;date.textContent=when?new Date(when).toLocaleString('ru-RU',{day:'2-digit',month:'long',year:'numeric',hour:'2-digit',minute:'2-digit'}):'';d.appendChild(date);
  if(type==='batches'){const actions=document.createElement('div');actions.className='historyActions';const repeat=document.createElement('button');repeat.type='button';repeat.className='miniBtn';repeat.textContent='Повторить рецепт';repeat.onclick=()=>repeatRecipe(x);actions.appendChild(repeat);d.appendChild(actions);}
  return d;
}

// Облако: используем ту же авторизацию, что сушилка и склад химии. Ядро приложения от сети не зависит.
function bestSession(){const a=[readJSON(SHARED_SESSION_KEY,null),readJSON(DRYER_SESSION_KEY,null),readJSON(CHEM_SESSION_KEY,null)].filter(x=>x&&x.access_token);a.sort((x,y)=>(Number(y.expires_at)||0)-(Number(x.expires_at)||0));return a[0]||null;}
let cloudConfig=Object.assign({},DEFAULT_CLOUD,readJSON(CLOUD_CONFIG_KEY,{}));let cloudSession=bestSession();let pending=readJSON(PENDING_KEY,[]);if(!Array.isArray(pending))pending=[];
function savePending(){writeJSON(PENDING_KEY,pending);}
function saveSession(s){cloudSession=s;if(s){writeJSON(SHARED_SESSION_KEY,s);writeJSON(DRYER_SESSION_KEY,s);writeJSON(CHEM_SESSION_KEY,s);}}
async function fetchTimed(url,opts={},timeout=25000){const ctrl=new AbortController(),tm=setTimeout(()=>ctrl.abort(),timeout);try{return await fetch(url,Object.assign({},opts,{signal:ctrl.signal}));}finally{clearTimeout(tm);}}
async function authRequest(path,opts={}){const h=Object.assign({'apikey':cloudConfig.key,'Content-Type':'application/json'},opts.headers||{}),r=await fetchTimed(cloudConfig.url.replace(/\/+$/,'')+path,Object.assign({},opts,{headers:h}));const t=await r.text();let j=null;try{j=t?JSON.parse(t):null;}catch(e){}if(!r.ok)throw new Error((j&&(j.message||j.msg||j.error_description))||t||('HTTP '+r.status));return j;}
async function refreshSession(){if(!cloudSession||!cloudSession.refresh_token)throw new Error('Нет общей сессии');const j=await authRequest('/auth/v1/token?grant_type=refresh_token',{method:'POST',body:JSON.stringify({refresh_token:cloudSession.refresh_token})});if(!j||!j.access_token)throw new Error('Не удалось обновить сессию');saveSession(j);return j;}
async function dataRequest(tableQuery,opts={},retried=false){if(!cloudSession||!cloudSession.access_token)throw new Error('Нет входа в общую базу');const h=Object.assign({'apikey':cloudConfig.key,'Authorization':'Bearer '+cloudSession.access_token,'Content-Type':'application/json'},opts.headers||{}),r=await fetchTimed(cloudConfig.url.replace(/\/+$/,'')+'/rest/v1/'+tableQuery,Object.assign({},opts,{headers:h}));if(r.status===401&&!retried){await refreshSession();return dataRequest(tableQuery,opts,true);}const t=await r.text();let j=null;try{j=t?JSON.parse(t):null;}catch(e){}if(!r.ok)throw new Error((j&&(j.message||j.error||j.hint))||t||('HTTP '+r.status));return j;}
function rowFor(type,x){
  if(type==='batches')return{client_id:x.clientId,crop:x.crop,recipe_name:x.recipeName,recipe_key:x.recipeKey,measurement_mode:modeOf(x),seed_tonnage:x.seedTonnage,total_mass_g:x.totalMassG,total_volume_ml:x.totalVolumeMl,dose_g_per_t:x.doseGPerT,dose_ml_per_t:x.doseMlPerT,components:x.components||[],status:x.status,notes:x.notes||null,created_at:x.createdAt,updated_at:x.updatedAt,deleted_at:x.deletedAt||null};
  if(type==='calibrations')return{client_id:x.clientId,batch_client_id:x.batchClientId,recipe_key:x.recipeKey,crop:x.crop,measurement_mode:modeOf(x),sm4_hz:x.sm4Hz,sm4_min_per_t:x.sm4MinPerT,required_flow_g_min:x.requiredFlowGMin,required_flow_ml_min:x.requiredFlowMlMin,pump_hz:x.pumpHz,duration_sec:x.durationSec,mass_before_g:x.massBeforeG,mass_after_g:x.massAfterG,test_volume_ml:x.testVolumeMl,actual_flow_g_min:x.actualFlowGMin,actual_flow_ml_min:x.actualFlowMlMin,error_pct:x.errorPct,accepted:!!x.accepted,occurred_at:x.occurredAt,notes:x.notes||null,created_at:x.createdAt,updated_at:x.updatedAt,deleted_at:x.deletedAt||null};
  if(type==='bags')return{client_id:x.clientId,run_client_id:x.runClientId,batch_client_id:x.batchClientId,crop:x.crop||'Соя',bag_no:x.bagNo,target_kg:x.targetKg,sm4_hz:x.sm4Hz,model_min_per_t:x.modelMinPerT,model_source:x.modelSource||null,model_confidence:x.modelConfidence||null,started_at:x.startedAt,ended_at:x.endedAt||null,paused_at:x.pausedAt||null,paused_duration_sec:x.pausedDurationSec||0,active_duration_sec:x.activeDurationSec,estimated_kg:x.estimatedKg,actual_net_kg:x.actualNetKg,actual_kg_min:x.actualKgMin,actual_min_per_t:x.actualMinPerT,deviation_pct:x.deviationPct,weight_recorded_at:x.weightRecordedAt||null,learning_status:x.learningStatus||'pending_weight',status:x.status||'completed',notes:x.notes||null,created_at:x.createdAt,updated_at:x.updatedAt,deleted_at:x.deletedAt||null};
  return{client_id:x.clientId,batch_client_id:x.batchClientId,recipe_key:x.recipeKey,crop:x.crop,measurement_mode:modeOf(x),seed_tonnage:x.seedTonnage,sm4_hz:x.sm4Hz,sm4_min_per_t:x.sm4MinPerT,planned_duration_min:x.plannedDurationMin,required_flow_g_min:x.requiredFlowGMin,required_flow_ml_min:x.requiredFlowMlMin,pump_hz:x.pumpHz,calibrated_flow_g_min:x.calibratedFlowGMin,calibrated_flow_ml_min:x.calibratedFlowMlMin,start_mass_g:x.startMassG,end_mass_g:x.endMassG,start_volume_ml:x.startVolumeMl,end_volume_ml:x.endVolumeMl,processed_tonnage:x.processedTonnage,checkpoints:x.checkpoints||[],paused_at:x.pausedAt||null,paused_duration_sec:x.pausedDurationSec||0,pause_reason:x.pauseReason||null,active_duration_sec:x.activeDurationSec,line_events:x.lineEvents||[],emergency_count:x.emergencyCount||0,started_at:x.startedAt,ended_at:x.endedAt,status:x.status,notes:x.notes||null,created_at:x.createdAt,updated_at:x.updatedAt,deleted_at:x.deletedAt||null};
}
function mapRemote(type,r){
  if(type==='batches')return{clientId:r.client_id,crop:r.crop,recipeName:r.recipe_name,recipeKey:r.recipe_key,measurementMode:r.measurement_mode||'mass',seedTonnage:Number(r.seed_tonnage),totalMassG:nullableNum(r.total_mass_g),totalVolumeMl:nullableNum(r.total_volume_ml),doseGPerT:nullableNum(r.dose_g_per_t),doseMlPerT:nullableNum(r.dose_ml_per_t),components:r.components||[],status:r.status,notes:r.notes||'',createdAt:r.created_at,updatedAt:r.updated_at,deletedAt:r.deleted_at};
  if(type==='calibrations')return{clientId:r.client_id,batchClientId:r.batch_client_id,recipeKey:r.recipe_key,crop:r.crop,measurementMode:r.measurement_mode||'mass',sm4Hz:nullableNum(r.sm4_hz),sm4MinPerT:nullableNum(r.sm4_min_per_t),requiredFlowGMin:nullableNum(r.required_flow_g_min),requiredFlowMlMin:nullableNum(r.required_flow_ml_min),pumpHz:Number(r.pump_hz),durationSec:Number(r.duration_sec),massBeforeG:nullableNum(r.mass_before_g),massAfterG:nullableNum(r.mass_after_g),testVolumeMl:nullableNum(r.test_volume_ml),actualFlowGMin:nullableNum(r.actual_flow_g_min),actualFlowMlMin:nullableNum(r.actual_flow_ml_min),errorPct:nullableNum(r.error_pct),accepted:!!r.accepted,occurredAt:r.occurred_at,notes:r.notes||'',createdAt:r.created_at,updatedAt:r.updated_at,deletedAt:r.deleted_at};
  if(type==='bags')return{clientId:r.client_id,runClientId:r.run_client_id,batchClientId:r.batch_client_id,crop:r.crop||'Соя',bagNo:Number(r.bag_no),targetKg:Number(r.target_kg),sm4Hz:Number(r.sm4_hz),modelMinPerT:Number(r.model_min_per_t),modelSource:r.model_source||'',modelConfidence:r.model_confidence||'',startedAt:r.started_at,endedAt:r.ended_at,pausedAt:r.paused_at,pausedDurationSec:Number(r.paused_duration_sec||0),activeDurationSec:nullableNum(r.active_duration_sec),estimatedKg:nullableNum(r.estimated_kg),actualNetKg:nullableNum(r.actual_net_kg),actualKgMin:nullableNum(r.actual_kg_min),actualMinPerT:nullableNum(r.actual_min_per_t),deviationPct:nullableNum(r.deviation_pct),weightRecordedAt:r.weight_recorded_at,learningStatus:r.learning_status||'pending_weight',status:r.status||'completed',notes:r.notes||'',createdAt:r.created_at,updatedAt:r.updated_at,deletedAt:r.deleted_at};
  return{clientId:r.client_id,batchClientId:r.batch_client_id,recipeKey:r.recipe_key,crop:r.crop,measurementMode:r.measurement_mode||'mass',seedTonnage:Number(r.seed_tonnage),sm4Hz:nullableNum(r.sm4_hz),sm4MinPerT:Number(r.sm4_min_per_t),plannedDurationMin:Number(r.planned_duration_min),requiredFlowGMin:nullableNum(r.required_flow_g_min),requiredFlowMlMin:nullableNum(r.required_flow_ml_min),pumpHz:nullableNum(r.pump_hz),calibratedFlowGMin:nullableNum(r.calibrated_flow_g_min),calibratedFlowMlMin:nullableNum(r.calibrated_flow_ml_min),startMassG:nullableNum(r.start_mass_g),endMassG:nullableNum(r.end_mass_g),startVolumeMl:nullableNum(r.start_volume_ml),endVolumeMl:nullableNum(r.end_volume_ml),processedTonnage:nullableNum(r.processed_tonnage),checkpoints:r.checkpoints||[],pausedAt:r.paused_at,pausedDurationSec:Number(r.paused_duration_sec||0),pauseReason:r.pause_reason||null,activeDurationSec:nullableNum(r.active_duration_sec),lineEvents:r.line_events||[],emergencyCount:Number(r.emergency_count||0),startedAt:r.started_at,endedAt:r.ended_at,status:r.status,notes:r.notes||'',createdAt:r.created_at,updatedAt:r.updated_at,deletedAt:r.deleted_at};
}
function queueRecord(type,x){pending=pending.filter(p=>!(p.type===type&&p.clientId===x.clientId));pending.push({type,clientId:x.clientId,row:rowFor(type,x)});savePending();}
async function flushPending(){const batch=pending.slice();for(const op of batch){try{await dataRequest(TABLES[op.type]+'?on_conflict=client_id',{method:'POST',headers:{Prefer:'resolution=merge-duplicates,missing=default,return=minimal'},body:JSON.stringify(op.row)});pending=pending.filter(current=>current!==op);savePending();}catch(e){op.last_error=String(e.message||e);savePending();}}}
function mergeByUpdated(local,remote){const m=new Map();[...local,...remote].forEach(x=>{if(!x||!x.clientId)return;const old=m.get(x.clientId);if(!old||String(x.updatedAt||'')>=String(old.updatedAt||''))m.set(x.clientId,x);});return Array.from(m.values());}
async function cloudSync(silent=false){
  if(DonskoeCore.inTransaction()){setTimeout(()=>cloudSync(silent),0);return false;}if(cloudBusy)return false;if(navigator.onLine===false){cloudText='Нет сети. '+pending.length+' изменений остаются в очереди на устройстве.';if(!silent)renderHistory();return false;}if(!cloudSession||!cloudSession.access_token){cloudText='Облако не подключено в этом браузере. Локальная работа полностью доступна; вход можно выполнить в модуле Сушки или Склада химии.';if(!silent)renderHistory();return false;}
  cloudBusy=true;$('syncNow').disabled=true;cloudText='Синхронизация…';if(!silent&&$('cloudStatus'))$('cloudStatus').textContent=cloudText;
  try{await flushPending();for(const type of ['batches','calibrations','bags','runs']){const rows=await dataRequest(TABLES[type]+'?select=*',{method:'GET'});const protectedIds=new Set(pending.filter(p=>p.type===type).map(p=>p.clientId));state[type]=mergeByUpdated(state[type],(Array.isArray(rows)?rows:[]).filter(r=>!protectedIds.has(r.client_id)).map(r=>mapRemote(type,r)));}saveState();cloudText=pending.length?'Есть изменения, ожидающие отправки.':'Синхронизировано с общей базой.';if(!silent&&$('cloudStatus'))$('cloudStatus').textContent=cloudText;return true;}catch(e){cloudText='Облако недоступно. Данные сохранены локально и будут отправлены позже.';if(!silent&&$('cloudStatus'))$('cloudStatus').textContent=cloudText;return false;}finally{cloudBusy=false;$('syncNow').disabled=false;if(routeStack[routeStack.length-1]==='history')renderHistory();}
}
$('syncNow').onclick=()=>cloudSync(false);

setInterval(()=>{updateCalTimer();updateWorkTimer();},1000);
setInterval(()=>{if(document.visibilityState==='visible'&&navigator.onLine!==false)cloudSync(true);},60000);

// Инициализация
renderComponents();setMixMode('mass');renderMixResult();ensureActiveBatch();renderCalibration();renderWork();renderHistory();
if(state.activeCal)renderCalState();
if(navigator.onLine!==false)setTimeout(()=>cloudSync(true),900);
// Донское 7: durable mix draft, history tools, direct routes.
const MIX_DRAFT_KEY='donskoe_connisseur_mix_draft_v1';
const mixFields=['mixCrop','mixName','mixTonnage','mixMassG','mixVolumeL','mixNote'];
function saveMixDraft(){
  const values={};mixFields.forEach(id=>{values[id]=$(id).value;});
  writeJSON(MIX_DRAFT_KEY,{values,components:draftComponents,mode:mixMode,savedAt:iso()});
  $('mixDraftStatus').textContent='Черновик сохранён на устройстве';
}
function restoreMixDraft(){
  const draft=readJSON(MIX_DRAFT_KEY,null);if(!draft)return;
  mixFields.forEach(id=>{if(draft.values&&typeof draft.values[id]==='string')$(id).value=draft.values[id];});
  if(Array.isArray(draft.components))draftComponents=draft.components.map(c=>({name:String(c.name||''),qty:String(c.qty??''),unit:['л','мл','кг','г'].includes(c.unit)?c.unit:'л'}));
  setMixMode(draft.mode==='volume'?'volume':'mass');renderComponents();renderMixResult();$('mixDraftStatus').textContent='Восстановлен черновик смеси';
}
function repeatRecipe(batch){
  if(currentRun())return alert('Сначала завершите текущую обработку. Её партия должна оставаться выбранной до сохранения итогов.');
  if(($('mixMassG').value||$('mixVolumeL').value||draftComponents.some(c=>c.name))&&!confirm('Заменить текущий черновик выбранным рецептом?'))return;
  $('mixCrop').value=batch.crop;$('mixName').value=batch.recipeName;$('mixTonnage').value=batch.seedTonnage;
  $('mixMassG').value='';$('mixVolumeL').value='';$('mixNote').value='Повтор рецепта от '+new Date(batch.createdAt).toLocaleDateString('ru-RU');
  draftComponents=(batch.components||[]).map(c=>({name:c.name,qty:c.qty,unit:c.unit}));setMixMode(modeOf(batch));renderComponents();renderMixResult();saveMixDraft();showPage('mix');
  DonskoeUI.toast('Рецепт перенесён. Взвесьте новую смесь и внесите её фактическую массу.',5000);
}
function updateProOverview(){
  const run=currentRun(),cal=state.activeCal,host=$('resumeWork');host.hidden=!run&&!cal;if(host.hidden)return;
  $('resumeTitle').textContent=run?(run.pausedAt?'Обработка на паузе':'Учёт обработки запущен'):'Калибровка не завершена';
  $('resumeText').textContent=run?(run.crop+' · '+fmt(run.sm4Hz,1)+' Гц · '+bagsForRun(run.clientId).length+' счётчиков биг-бэгов'):'Вернитесь к контрольному измерению';
  $('resumeOpen').onclick=()=>showPage(run?'work':'cal');
}
function exportHistoryCsv(){
  let headers=[],rows=[];
  const query=normalize($('historySearch').value);
  const data=state[historyTab].filter(x=>!x.deletedAt&&(!query||normalize(JSON.stringify(x)).includes(query)));
  if(historyTab==='batches'){
    headers=['Дата','Смесь','Культура','Семена, т','Масса состава, г','Объём, мл','Доза, г/т','Доза, мл/т','Режим','Статус'];
    rows=data.map(x=>[x.createdAt,x.recipeName,x.crop,x.seedTonnage,x.totalMassG,x.totalVolumeMl,x.doseGPerT,x.doseMlPerT,modeOf(x)==='volume'?'Объём':'Масса',statusRu(x.status)]);
  }else if(historyTab==='calibrations'){
    headers=['Дата','Культура','Насос, Гц','Интервал, с','Подача, г/мин','Подача, мл/мин','В обучении'];rows=data.map(x=>[x.occurredAt,x.crop,x.pumpHz,x.durationSec,x.actualFlowGMin,x.actualFlowMlMin,x.accepted?'Да':'Нет']);
  }else if(historyTab==='bags'){
    headers=['Дата','Биг-бэг №','Культура','СМ-4, Гц','Активное время, с','Расчётно, кг','Факт нетто, кг','Факт, мин/т','Статус обучения','Статус'];
    rows=data.map(x=>[x.startedAt,x.bagNo,x.crop,x.sm4Hz,x.activeDurationSec,x.estimatedKg,x.actualNetKg,x.actualMinPerT,x.learningStatus,statusRu(x.status)]);
  }else{
    headers=['Старт','Завершение','Культура','СМ-4, Гц','Насос, Гц','Обработано, т','Основание тоннажа','Активное время, с','Расход, г','Расход, мл','Статус'];
    rows=data.map(x=>{const bags=bagsForRun(x.clientId).filter(b=>b.status==='completed'),weighed=bags.length&&bags.every(b=>Number(b.actualNetKg)>0);return[x.startedAt,x.endedAt,x.crop,x.sm4Hz,x.pumpHz,x.processedTonnage,weighed?'Фактические веса биг-бэгов':'Содержит расчётные значения',x.activeDurationSec,x.endMassG==null?null:x.startMassG-x.endMassG,x.endVolumeMl==null?null:x.startVolumeMl-x.endVolumeMl,statusRu(x.status)];});
  }
  DonskoeCore.download(DonskoeCore.csv([headers,...rows]),'donskoe-connisseur-'+historyTab+'-'+DonskoeCore.stamp()+'.csv','text/csv;charset=utf-8');
  DonskoeUI.toast('Таблица сформирована: '+rows.length+' записей');
}
$('historySearch').oninput=renderHistory;$('historyCsv').onclick=exportHistoryCsv;
$('page-mix').addEventListener('input',saveMixDraft);$('page-mix').addEventListener('change',saveMixDraft);
$('page-mix').addEventListener('click',e=>{if(e.target.closest('#modeMass,#modeVolume,#addComponent,[data-cremove]'))saveMixDraft();});
window.addEventListener('pagehide',saveMixDraft);
restoreMixDraft();updateProOverview();
window.DonskoeModule={navigate:showPage,current:currentRoute};
const proParams=new URLSearchParams(location.search),proPage=proParams.get('page'),proTab=proParams.get('tab');
if(['batches','calibrations','bags','runs'].includes(proTab))historyTab=proTab;
if(titles[proPage])showPage(proPage);
document.dispatchEvent(new Event('donskoe-route'));

// Operational safeguards: existing state and cloud queue share one recoverable commit.
const WORK_DRAFT_KEY='donskoe_connisseur_work_draft_v1';
const workFields=['workSm4Hz','workPumpHz','workStartMeasure','workEndMeasure','workActualSeedsKg','workActualLiquid','checkpointMeasure','bagTargetKg','bagActualKg','calPumpHz','calBeforeMeasure','calAfterMeasure','calNote'];
let operationalBusy=false;
const tapTimes=new Map();
function workDraftSnapshot(){const values={};workFields.forEach(id=>{if($(id))values[id]=$(id).value;});return {values,runId:state.activeRunId,batchId:state.activeBatchId,weightBagId:state.weightBagId||null,pendingCalResult,savedAt:iso()};}
function saveWorkDraft(){writeJSON(WORK_DRAFT_KEY,workDraftSnapshot());}
function restoreWorkDraft(){const d=readJSON(WORK_DRAFT_KEY,null);if(!d||d.runId!==state.activeRunId||d.batchId!==state.activeBatchId)return;pendingCalResult=d.pendingCalResult||null;for(const [id,v] of Object.entries(d.values||{}))if($(id)&&typeof v==='string')$(id).value=v;workPumpManual=!!$('workPumpHz').value;workStartMeasureManual=!!$('workStartMeasure').value;}
function protectMutation(fn,key){
  return function(...args){
    if(DonskoeCore.inTransaction())return fn.apply(this,args);
    if(operationalBusy||Date.now()-(tapTimes.get(key)||0)<700)return;
    const saved=JSON.stringify(state),queued=JSON.stringify(pending),components=JSON.stringify(draftComponents),fields=Array.from(document.querySelectorAll('input,select,textarea')).filter(x=>x.type!=='file').map(x=>[x,x.value]);
    const beforeRoute=currentRoute();let result;
    operationalBusy=true;
    try{DonskoeCore.begin();
      for(const type of ['batches','calibrations','runs','bags']){const ids=new Set();for(const x of state[type]){if(!x.clientId||ids.has(x.clientId))throw new Error('В истории обнаружен конфликт идентификаторов. Сохранение остановлено; сохраните резервную копию.');ids.add(x.clientId);}}
      result=fn.apply(this,args);saveState();savePending();saveWorkDraft();saveMixDraft();DonskoeCore.commit();tapTimes.set(key,Date.now());
      updateProOverview();if(saved!==JSON.stringify(state)&&key!=='startWork'&&key!=='finishBag')DonskoeUI.toast('Сохранено на устройстве',1800);
      return result;
    }catch(error){
      DonskoeCore.abort();state=JSON.parse(saved);pending=JSON.parse(queued);draftComponents=JSON.parse(components);
      fields.forEach(([el,value])=>{el.value=value;});
      try{renderWork();renderHistory();renderComponents();showPage(beforeRoute,false);fields.forEach(([el,value])=>{el.value=value;});}catch(_){}
      DonskoeUI.toast(error.message||'Не удалось сохранить операцию. Данные не изменены. Повторите сохранение.',6500);
    }finally{operationalBusy=false;}
  };
}
for(const id of ['saveBatch','startWork','saveBagWeight','startBag','finishBag','pauseLine','normalStop','emergencyStop','resumeLine','stopLineHere','confirmNormalStop','cancelNormalStop','saveActualCheck','addCheckpoint','finishWork','startCal','stopCal','saveCal','acceptCal','rejectCal','cancelCal','calcCalResult']){
  const el=$(id);if(el&&el.onclick)el.onclick=protectMutation(el.onclick,id);
}
deleteCalibration=protectMutation(deleteCalibration,'deleteCalibration');
deleteBagRecord=protectMutation(deleteBagRecord,'deleteBagRecord');
setBagLearning=protectMutation(setBagLearning,'setBagLearning');
commitWorkBatchEdits=protectMutation(commitWorkBatchEdits,'commitWorkBatchEdits');
const originalWorkTimer=updateWorkTimer;
updateWorkTimer=function(){originalWorkTimer();const r=currentRun();if(r&&!(r.sm4MinPerT>0)){$('workRemain').textContent='Нет достоверной калибровки · по весам '+fmt(r.weighedTonnage*1000||0,1)+' кг';$('workProgress').querySelector('i').style.width='0%';$('bagKgCounter').textContent='Нет прогноза';$('processedSeedsSummary').textContent='Масса определяется взвешиванием. Время учитывается с исключением пауз.';}};
document.addEventListener('input',e=>{if(workFields.includes(e.target.id))saveWorkDraft();});
document.addEventListener('change',e=>{if(workFields.includes(e.target.id))saveWorkDraft();});
window.addEventListener('pagehide',saveWorkDraft);
document.addEventListener('visibilitychange',()=>{if(document.visibilityState==='hidden')saveWorkDraft();});
restoreWorkDraft();
if(integrityBoot.changed)saveState();
if(integrityBoot.multipleRuns)DonskoeUI.toast('В истории несколько незавершённых работ. Новая работа заблокирована до их проверки.',8000);
if(currentRun()){showPage('work');restoreWorkDraft();}

if('serviceWorker' in navigator)navigator.serviceWorker.register('./sw.js',{updateViaCache:'none'}).then(r=>r.update()).catch(()=>{});
})();
