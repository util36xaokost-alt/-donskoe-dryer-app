(function(){
'use strict';
const C=window.DonskoeCore,$=id=>document.getElementById(id);
const esc=s=>String(s??'').replace(/[&<>"']/g,x=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[x]));
function taskHtml(task){return '<a class="attentionPageItem'+(task.warn?' warn':'')+'" href="'+task.href+'"><div class="attentionPageIcon">'+(task.warn?'!':'•')+'</div><div class="attentionPageText"><b>'+esc(task.title)+'</b><small>'+esc(task.sub)+'</small></div><div class="attentionPageArrow">›</div></a>';}
function render(){
 const cache=C.read('donskoe_attention_items_v1',{})||{};
 const items=Array.isArray(cache.items)?cache.items:[];
 $('attentionActiveText').textContent=cache.workLabel||'Система готова';
 $('attentionSyncText').textContent=cache.syncLabel||'Синхронизировано';
 $('attentionCountText').textContent='Действий: '+(Number(cache.actionCount)||items.reduce((s,x)=>s+Math.max(1,Number(x.weight)||1),0));
 $('attentionTasks').innerHTML=items.map(taskHtml).join('');
 $('attentionEmpty').hidden=items.length>0;
 $('attentionTasks').hidden=items.length===0;
 }
 $('attentionBack').onclick=()=>{if(history.length>1)history.back();else location.href='index.html';};
 window.addEventListener('storage',render);
 window.addEventListener('pageshow',render);
 render();
})();
