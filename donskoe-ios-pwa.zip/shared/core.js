(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  else root.DonskoeCore = api;
})(typeof window !== 'undefined' ? window : globalThis, function () {
  'use strict';
  const VERSION = typeof DONSKOE_RELEASE !== 'undefined' ? DONSKOE_RELEASE.version : (typeof require === 'function' ? require('../release.json').version : 'версия не загружена');
  const blocked = new Set();
  const JOURNAL = 'donskoe_local_commit_v1';
  let staged = null;
  function recoverCommit(storage = localStorage) {
    const raw = storage.getItem(JOURNAL); if (!raw) return;
    try {
      const j = JSON.parse(raw);
      if (!Array.isArray(j.items) || !['prepared','committed'].includes(j.phase)) throw new Error('journal');
      for (const item of j.items) {
        if (!Array.isArray(item) || !/^donskoe_/.test(item[0]) || item[0] === JOURNAL) throw new Error('journal');
        const value = item[j.phase === 'committed' ? 2 : 1];
        if (value !== null && typeof value !== 'string') throw new Error('journal');
      }
      for (const item of j.items) { const value = item[j.phase === 'committed' ? 2 : 1]; value === null ? storage.removeItem(item[0]) : storage.setItem(item[0], value); }
      storage.removeItem(JOURNAL);
    } catch (error) { blocked.add(JOURNAL); throw storageError(JOURNAL, error); }
  }
  function begin() { if (staged) throw new Error('Операция уже сохраняется'); recoverCommit(); staged = new Map(); }
  function abort() { staged = null; }
  function inTransaction() { return staged !== null; }
  function commit(storage = localStorage) {
    if (!staged) return;
    const items = Array.from(staged, ([key, value]) => [key, storage.getItem(key), value]).filter(x => x[1] !== x[2]); staged = null;
    if (!items.length) return;
    let prepared = false;
    try {
      storage.setItem(JOURNAL, JSON.stringify({ phase:'prepared', items })); prepared = true;
      for (const [key,, value] of items) value === null ? storage.removeItem(key) : storage.setItem(key, value);
      storage.setItem(JOURNAL, JSON.stringify({ phase:'committed', items }));
    } catch (error) {
      let restored = true;
      if (prepared) for (const [key, value] of items) try { value === null ? storage.removeItem(key) : storage.setItem(key, value); } catch (_) { restored = false; }
      if (prepared && restored) storage.removeItem(JOURNAL);
      throw storageError(JOURNAL, error);
    }
    try { storage.removeItem(JOURNAL); } catch (_) { /* A committed journal is safe to replay. */ }
  }
  const chemStores = ['chem_operators','chem_devices','chem_products','chem_batches','chem_movements','chem_opened_units','chem_photo_sessions','chem_photos','chem_ai_audits','chem_ai_findings','chem_inventory_sessions','chem_inventory_counts','pending','photo_blobs','settings'];
  const DBS = {
    donskoe_dryer_photos_v1: { photos: 'local_id' },
    donskoe_chem_offline_v1: Object.fromEntries(chemStores.map(s => [s, s === 'settings' ? 'key' : 'id']))
  };
  function storageError(key, error) {
    const message = blocked.has(key)
      ? 'Повреждена локальная запись. Автоматическая перезапись остановлена. Сохраните резервную копию в разделе «Данные».'
      : 'Не удалось сохранить данные на устройстве. Возможно, память заполнена. Не закрывайте форму; сохраните акт или резервную копию.';
    if (typeof window !== 'undefined') {
      window.__donskoeStorageError = message;
      window.dispatchEvent(new CustomEvent('donskoe-storage-error', { detail: message }));
    }
    return new Error(message, { cause: error });
  }
  function read(key, fallback, storage = localStorage) {
    const raw = staged?.has(key) ? staged.get(key) : storage.getItem(key);
    if (raw === null) return fallback;
    try { return JSON.parse(raw); }
    catch (error) { blocked.add(key); storageError(key, error); return fallback; }
  }
  function write(key, value, storage = localStorage) {
    if (blocked.has(key) || blocked.has(JOURNAL)) throw storageError(key);
    if (staged) { staged.set(key, JSON.stringify(value)); return true; }
    try { storage.setItem(key, JSON.stringify(value)); return true; }
    catch (error) { throw storageError(key, error); }
  }
  function readRecoverable(key, backupKeys, fallback, valid) {
    const raw=localStorage.getItem(key);
    if(raw!==null)try{const value=JSON.parse(raw);if(valid(value))return value;}catch(_){}
    for(const backupKey of backupKeys){
      const candidate=localStorage.getItem(backupKey);if(candidate===null)continue;
      try{const value=JSON.parse(candidate);if(!valid(value))continue;
        if(raw!==null){const records=read('donskoe_damaged_records_v1',[]);records.push({key,raw,at:new Date().toISOString()});write('donskoe_damaged_records_v1',records);}
        localStorage.setItem(key,candidate);blocked.delete(key);
        if(typeof window!=='undefined')window.__donskoeStorageError='Восстановлена резервная запись на устройстве. Проверьте последние операции и сохраните резервную копию.';
        return value;
      }catch(error){if(error.message?.includes('сохранить'))throw error;}
    }
    if(raw===null)return fallback;
    blocked.add(key);throw storageError(key);
  }
  function remove(key) { if (staged) staged.set(key, null); else localStorage.removeItem(key); }
  function seedHistory(raw, seed) {
    // An existing empty history is deliberate. Never replace a record by cycle number.
    if (raw === null) return { rows: JSON.parse(JSON.stringify(seed)), fresh: true };
    const rows = JSON.parse(raw);
    if (!Array.isArray(rows)) throw new Error('История циклов имеет неверный формат');
    return { rows, fresh: false };
  }
  function mergeMissing(existing, incoming, key) {
    const ids = new Set(existing.map(x => String(x[key])));
    const added = [];
    for (const row of incoming) {
      if (!row || row[key] === null || row[key] === undefined) throw new Error('Запись без идентификатора');
      const id = String(row[key]);
      if (!ids.has(id)) { ids.add(id); added.push(row); }
    }
    return { rows: existing.concat(added), added: added.length, skipped: incoming.length - added.length };
  }
  function csvCell(value) {
    let s = value == null ? '' : String(value);
    if (/^[\s]*[=+@\-]/.test(s) && !(typeof value === 'number' && Number.isFinite(value))) s = "'" + s;
    return '"' + s.replace(/"/g, '""') + '"';
  }
  function csv(rows) { return '\ufeff' + rows.map(r => r.map(csvCell).join(';')).join('\r\n'); }
  function download(data, name, type = 'application/json;charset=utf-8') {
    const blob = data instanceof Blob ? data : new Blob([data], { type });
    const url = URL.createObjectURL(blob), a = document.createElement('a');
    a.href = url; a.download = name; document.body.append(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 60000);
    return blob;
  }
  function stamp() { return new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19); }
  function dataKey(key) {
    return /^donskoe_/.test(key) && key !== JOURNAL && !/session|password|token|cloud_config|email|ocr|booted/.test(key);
  }
  function openDb(name, create = false) {
    return new Promise((resolve, reject) => {
      if (!DBS[name]) return reject(new Error('Неизвестное хранилище'));
      let absent = false;
      const req = indexedDB.open(name);
      req.onupgradeneeded = () => {
        if (!create) { absent = true; req.transaction.abort(); return; }
        for (const [store, keyPath] of Object.entries(DBS[name])) if (!req.result.objectStoreNames.contains(store)) req.result.createObjectStore(store, { keyPath });
      };
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => absent ? resolve(null) : reject(req.error);
      req.onblocked = () => reject(new Error('Закройте другие вкладки приложения и повторите'));
    });
  }
  async function readDb(name) {
    const db = await openDb(name); if (!db) return {};
    try {
      const names = Array.from(db.objectStoreNames).filter(n => DBS[name][n]);
      if (!names.length) return {};
      return await new Promise((resolve, reject) => {
        const out = {}, tx = db.transaction(names, 'readonly');
        for (const n of names) { const r = tx.objectStore(n).getAll(); r.onsuccess = () => { out[n] = r.result; }; }
        tx.oncomplete = () => resolve(out); tx.onerror = tx.onabort = () => reject(tx.error || new Error('Чтение данных прервано'));
      });
    } finally { db.close(); }
  }
  async function pack(value) {
    if (value instanceof Blob) return new Promise((resolve, reject) => {
      const r = new FileReader(); r.onload = () => resolve({ __donskoeBlob: true, type: value.type, data: r.result.split(',')[1] }); r.onerror = () => reject(r.error); r.readAsDataURL(value);
    });
    if (value instanceof ArrayBuffer || ArrayBuffer.isView(value)) {
      const encoded = await pack(new Blob([value]));
      return { __donskoeBytes: true, data: encoded.data };
    }
    if (Array.isArray(value)) return Promise.all(value.map(pack));
    if (value && typeof value === 'object') {
      if (value instanceof Date) return value.toISOString();
      const out = {}; for (const [k, v] of Object.entries(value)) { if (k === '__proto__' || k === 'constructor' || k === 'prototype') continue; out[k] = await pack(v); } return out;
    }
    return value;
  }
  function unpack(value) {
    if (value && (value.__donskoeBlob === true || value.__donskoeBytes === true)) {
      if (typeof value.data !== 'string' || !/^[A-Za-z0-9+/]*={0,2}$/.test(value.data)) throw new Error('Повреждены данные фотографии');
      const bytes = Uint8Array.from(atob(value.data), c => c.charCodeAt(0));
      return value.__donskoeBytes ? bytes.buffer : new Blob([bytes], { type: value.type || 'application/octet-stream' });
    }
    if (Array.isArray(value)) return value.map(unpack);
    if (value && typeof value === 'object') {
      const out = {}; for (const [k, v] of Object.entries(value)) { if (['__proto__','constructor','prototype'].includes(k)) throw new Error('Недопустимое поле'); out[k] = unpack(v); } return out;
    }
    return value;
  }
  function owner(storage = localStorage) {
    for (const k of ['donskoe_cloud_session_shared_v1','donskoe_dryer_cloud_session_v1','donskoe_chem_cloud_session_v1']) {
      try { const s = JSON.parse(storage.getItem(k) || 'null'); if (s?.user?.id) return s.user.id; } catch (_) {}
    }
    return null;
  }
  async function snapshot() {
    const local = {}, databases = {};
    for (let i = 0; i < localStorage.length; i++) { const k = localStorage.key(i); if (dataKey(k)) local[k] = localStorage.getItem(k); }
    for (const name of Object.keys(DBS)) databases[name] = await pack(await readDb(name));
    return { format: 'DONSKOE-DEVICE-BACKUP', schema: 1, appVersion: VERSION, createdAt: new Date().toISOString(), ownerId: owner(), local, databases };
  }
  function validateBackup(value) {
    if (value?.format !== 'DONSKOE-DEVICE-BACKUP' || value.schema !== 1 || !value.local || !value.databases) throw new Error('Это не резервная копия Донское 7');
    if (Array.isArray(value.local) || Array.isArray(value.databases)) throw new Error('Неверная структура копии');
    for (const [k, raw] of Object.entries(value.local)) {
      if (!dataKey(k) || typeof raw !== 'string') throw new Error('Недопустимые настройки в копии');
      // Non-JSON profile/migration keys are intentional. Core records must parse.
      if (/history|draft|active_plan|connisseur_state|pending/.test(k)) {
        const data = JSON.parse(raw);
        if (/history|pending/.test(k) && !Array.isArray(data)) throw new Error('Повреждён журнал в копии');
        if (/connisseur_state/.test(k) && !['batches','calibrations','runs','bags'].every(n => Array.isArray(data?.[n]))) throw new Error('Повреждена история ConNiSseur');
      }
    }
    for (const [name, stores] of Object.entries(value.databases)) {
      if (!DBS[name] || !stores || Array.isArray(stores)) throw new Error('Неизвестная база в копии');
      for (const [store, rows] of Object.entries(stores)) {
        if (!DBS[name][store] || !Array.isArray(rows)) throw new Error('Неизвестная таблица в копии');
        const ids = new Set();
        for (const row of rows) {
          if (!row || typeof row !== 'object' || !['string','number'].includes(typeof row[DBS[name][store]])) throw new Error('Запись без идентификатора');
          const id = String(row[DBS[name][store]]);
          if (ids.has(id)) throw new Error('Повторный идентификатор в копии');
          ids.add(id);
        }
      }
    }
    return value;
  }
  async function restoreMissing(value) {
    validateBackup(value);
    const currentOwner = owner();
    if (currentOwner && value.ownerId && currentOwner !== value.ownerId) throw new Error('Копия относится к другой общей базе. Войдите под исходной учётной записью.');
    // Decode every photo before starting any writes.
    const databases = unpack(value.databases);
    let added = 0, skipped = 0;
    const writes = [], undo = [];
    for (const [k, raw] of Object.entries(value.local)) {
      const old = localStorage.getItem(k);
      if (old === null) { writes.push([k, raw]); added++; continue; }
      if (k === 'donskoe_dryer_history_v1') {
        const merge = mergeMissing(JSON.parse(old), JSON.parse(raw), 'no'); added += merge.added; skipped += merge.skipped;
        if (merge.added) writes.push([k, JSON.stringify(merge.rows)]);
      } else if (k === 'donskoe_connisseur_state_v1') {
        const local = JSON.parse(old), incoming = JSON.parse(raw);
        for (const type of ['batches','calibrations','runs','bags']) { const merge = mergeMissing(local[type] || [], incoming[type] || [], 'clientId'); local[type] = merge.rows; added += merge.added; skipped += merge.skipped; }
        writes.push([k, JSON.stringify(local)]);
      } else if (k === 'donskoe_dryer_cloud_pending_v1' || k === 'donskoe_connisseur_cloud_pending_v1' || k === 'donskoe_dryer_photo_deletes_v1') {
        const local = JSON.parse(old), incoming = JSON.parse(raw);
        const identify = row => k.includes('connisseur') ? row.type + ':' + row.clientId : k.includes('photo') ? row.local_id : String(row.no);
        const ids = new Set(local.map(identify));
        for (const row of incoming) { const id = identify(row); if (ids.has(id)) skipped++; else { ids.add(id); local.push(row); added++; } }
        writes.push([k, JSON.stringify(local)]);
      } else { skipped++; }
    }
    try { for (const [k, raw] of writes) { undo.push([k, localStorage.getItem(k)]); localStorage.setItem(k, raw); } }
    catch (error) { for (const [k, raw] of undo.reverse()) try { raw === null ? localStorage.removeItem(k) : localStorage.setItem(k, raw); } catch (_) {} throw storageError('backup', error); }
    for (const [name, stores] of Object.entries(databases)) {
      const names = Object.keys(stores); if (!names.length) continue;
      const db = await openDb(name, true);
      try {
        const counts = await new Promise((resolve, reject) => {
          const tx = db.transaction(names, 'readwrite'); let count = 0, ignore = 0;
          for (const n of names) for (const row of stores[n]) {
            const store = tx.objectStore(n), req = store.get(row[DBS[name][n]]);
            req.onsuccess = () => { if (req.result === undefined) { store.add(row); count++; } else ignore++; };
          }
          tx.oncomplete = () => resolve([count, ignore]);
          tx.onerror = tx.onabort = () => reject(tx.error || new Error('Восстановление этой базы прервано'));
        });
        added += counts[0]; skipped += counts[1];
      } catch (error) { throw new Error('Восстановление выполнено частично. Уже добавленные записи сохранены; существующие не заменялись. Повторите импорт. ' + error.message); }
      finally { db.close(); }
    }
    return { added, skipped };
  }
  function activeWork() {
    try {
      const s = read('donskoe_connisseur_state_v1', {});
      return !!(read('donskoe_dryer_active_plan_v1', null) || s?.activeCal || s?.runs?.some(r => r.clientId === s.activeRunId && r.status === 'running' && !r.deletedAt));
    } catch (_) { return true; }
  }
  if (typeof localStorage !== 'undefined') try { recoverCommit(); } catch (_) {}
  return { VERSION, DBS, read, readRecoverable, write, remove, begin, commit, abort, inTransaction, recoverCommit, storageError, seedHistory, mergeMissing, csvCell, csv, download, stamp, dataKey, readDb, pack, unpack, snapshot, validateBackup, restoreMissing, activeWork, owner };
});
