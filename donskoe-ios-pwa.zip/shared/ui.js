(function () {
  'use strict';
  const Core = window.DonskoeCore;
  const paths = {
    home:'M3 10 12 3l9 7v10H3z M9 20v-7h6v7',
    calc:'M6 3h12v18H6z M9 7h6 M9 11h1 M14 11h1 M9 15h1 M14 15h1 M9 18h1 M14 18h1',
    work:'M4 7h16 M4 12h16 M4 17h16 M8 4v6 M16 9v6 M10 14v6',
    history:'M4 5v5h5 M4 10a8 8 0 1 1 0 5 M12 7v6l3 2',
    camera:'M3 7h4l2-3h6l2 3h4v13H3z M16 13a4 4 0 1 1-8 0 4 4 0 0 1 8 0',
    mix:'M8 3h8 M9 3v6l-5 9v3h16v-3l-5-9V3 M7 15h10',
    plus:'M12 4v16 M4 12h16', minus:'M4 12h16',
    stock:'M3 7 12 3l9 4v13H3z M3 7l9 4 9-4 M12 11v9',
    report:'M6 3h9l4 4v14H6z M15 3v5h4 M9 12h7 M9 16h7',
    data:'M4 4h16v16H4z M8 4v6h8V4 M8 20v-6h8v6',
    arrow:'M5 12h14 M13 6l6 6-6 6', settings:'M4 7h16 M4 17h16 M8 4v6 M16 14v6'
  };
  function icon(name) { return '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="' + (paths[name] || paths.work) + '"/></svg>'; }
  function toast(message, ms = 3600) {
    let el = document.getElementById('proToast'); if (!el) { el = document.createElement('div'); el.id = 'proToast'; el.className = 'proToast'; el.setAttribute('role','status'); document.body.append(el); }
    el.textContent = message; el.hidden = false; clearTimeout(toast.timer); toast.timer = setTimeout(() => { el.hidden = true; }, ms);
  }
  function showError(message) {
    let el = document.getElementById('proError'); if (!el) { el = document.createElement('div'); el.id = 'proError'; el.className = 'proError'; el.setAttribute('role','alert'); document.body.append(el); } el.textContent = message;
  }
  const modules = {
    dryer:[['home','Обзор','home'],['calc','Расчёт','calc'],['dry','Цикл','work'],['history','История','history'],['photos','Фото','camera']],
    connisseur:[['home','Обзор','home'],['mix','Смесь','mix'],['cal','Калибровка','calc'],['work','Работа','work'],['history','История','history']],
    chem:[['home','Обзор','home'],['receipt','Приход','plus'],['issue','Выдача','minus'],['stocks','Остатки','stock'],['reports','Отчёты','report']]
  };
  function highlight() {
    const current = window.DonskoeModule?.current?.() || 'home';
    document.querySelectorAll('.proNav [data-page]').forEach(b => { if (b.dataset.page === current) b.setAttribute('aria-current','page'); else b.removeAttribute('aria-current'); });
  }
  function mount() {
    const module = document.body.dataset.module;
    if (modules[module]) {
      const nav = document.createElement('nav'); nav.className = 'proNav'; nav.setAttribute('aria-label','Разделы модуля');
      nav.innerHTML = modules[module].map(([route, name, ico]) => '<button type="button" data-page="'+route+'">'+icon(ico)+'<span>'+name+'</span></button>').join('');
      nav.addEventListener('click', e => { const b = e.target.closest('[data-page]'); if (b && window.DonskoeModule) { window.DonskoeModule.navigate(b.dataset.page); highlight(); } });
      document.body.append(nav);
      function toolbar() {
        if (document.querySelector('.proToolbar')) return;
        const header = document.querySelector('.topbar') || document.querySelector('.brandCard') || document.querySelector('header') || document.querySelector('.brand') || document.querySelector('.header');
        if (header) header.insertAdjacentHTML('afterend','<div class="proToolbar"><a href="../index.html">'+icon('home')+' Все модули</a><a href="../index.html#data">'+icon('data')+' Данные</a></div>');
      }
      toolbar(); highlight();
      document.addEventListener('donskoe-route', () => { toolbar(); highlight(); labelFields(); });
    }
    labelFields(); if (window.__donskoeStorageError) showError(window.__donskoeStorageError);
    document.addEventListener('keydown', e => {
      if (e.key !== 'Escape') return;
      const open = document.querySelector('.modalShade:not(.hidden) .closeBtn,.modalBack:not(.hidden) [id$="Cancel"],.modalBack:not(.hidden) [id$="Close"]'); if (open) open.click();
    });
    installUpdates();
  }
  // Android APK compatibility: expose one bridge name to legacy module code.
  if(window.DonskoeNative && !window.AndroidBridge) window.AndroidBridge=window.DonskoeNative;

  function labelFields() {
    document.querySelectorAll('[data-app-version]').forEach(el=>el.textContent=Core.VERSION);
    document.querySelectorAll('.field').forEach(field => {
      const label = field.querySelector('label'), control = field.querySelector('input:not([type="hidden"]),select,textarea');
      if (label && control?.id && !label.contains(control) && !label.htmlFor) label.htmlFor = control.id;
    });
  }
  async function installUpdates() {
    if (window.DonskoeNative || window.__DONSKOE_ANDROID__===true) return;
    if (!('serviceWorker' in navigator)) return;
    const module=document.body.dataset.module;
    const rootBase=new URL(['dryer','chem','connisseur'].includes(module)?'../':'./',location.href);
    const rootScope=rootBase.href,scriptUrl=new URL('sw.js',rootBase).href;
    try{
      const regs=await navigator.serviceWorker.getRegistrations();
      await Promise.all(regs.filter(r=>r.scope!==rootScope&&['dryer/','chem/','connisseur/'].some(x=>r.scope.endsWith(x))).map(r=>r.unregister().catch(()=>false)));
      const active=(await navigator.serviceWorker.getRegistrations()).find(r=>r.scope===rootScope);
      if(!active)await navigator.serviceWorker.register(scriptUrl,{scope:rootScope,updateViaCache:'none'});
    }catch(_){/* Offline use continues from the existing controller/cache. */}
  }


  // Shared verified network state for every module. navigator.onLine is only a hint on iOS.
  (function installVerifiedNetwork(){
    if(window.DonskoeNet)return;
    let reachable=null, failures=0, busy=false, timer=null;
    const listeners=new Set();
    function rootUrl(){const inModule=/\/(dryer|chem|connisseur)\//.test(location.pathname);return new URL(inModule?'../release.json':'release.json',location.href).href;}
    function emit(next){
      if(reachable===next)return;
      reachable=next;
      const detail={online:reachable===true,checking:reachable===null};
      listeners.forEach(fn=>{try{fn(detail)}catch(_){}});
      window.dispatchEvent(new CustomEvent('donskoe-network',{detail}));
    }
    async function probe(){
      if(busy)return reachable===true; busy=true;
      // In the APK release.json is a local file, so HTTP ping to it cannot describe Internet access.
      // Android reports the actual active network directly through the native bridge.
      try{
        if(window.DonskoeNative&&typeof window.DonskoeNative.isOnline==='function'){
          const online=!!window.DonskoeNative.isOnline();failures=online?0:failures+1;emit(online);return online;
        }
      }catch(_native){}
      const ctrl=new AbortController(), kill=setTimeout(()=>ctrl.abort(),3500);
      try{
        const u=new URL(rootUrl());u.searchParams.set('net_ping',Date.now());
        const r=await fetch(u.href,{method:'HEAD',cache:'no-store',credentials:'same-origin',signal:ctrl.signal});
        if(!r.ok)throw new Error('HTTP '+r.status);
        failures=0;emit(true);return true;
      }catch(_){
        failures++;
        if(navigator.onLine===false||failures>=2)emit(false);
        return false;
      }finally{clearTimeout(kill);busy=false;}
    }
    function schedule(ms=100){clearTimeout(timer);timer=setTimeout(()=>{if(document.visibilityState==='visible')probe();},ms);}
    window.DonskoeNet={isOnline:()=>reachable===true,state:()=>reachable,probe,subscribe(fn){listeners.add(fn);try{fn({online:reachable===true,checking:reachable===null})}catch(_){}return()=>listeners.delete(fn);}};
    window.addEventListener('online',()=>schedule(50));
    window.addEventListener('offline',()=>schedule(50));
    document.addEventListener('visibilitychange',()=>{if(document.visibilityState==='visible')schedule(50)});
    setInterval(()=>{if(document.visibilityState==='visible')probe()},5000);
    schedule(0);
  })();

  window.DonskoeUI={icon,toast,highlight,labelFields};
  window.addEventListener('donskoe-storage-error', e=>showError(e.detail));
  document.addEventListener('DOMContentLoaded',mount);
})();
