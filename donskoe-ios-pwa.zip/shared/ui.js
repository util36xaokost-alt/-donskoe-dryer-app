(function () {
  'use strict';
  const Core = window.DonskoeCore;
  const paths = {
    home:'M3 10 12 3l9 7v10H3z M9 20v-7h6v7',
    calc:'M6 3h12v18H6z M9 7h6 M9 11h1 M14 11h1 M9 15h1 M14 15h1 M9 18h1 M14 18h1',
    work:'M4 7h16 M4 12h16 M4 17h16 M8 4v6 M16 9v6 M10 14v6',
    history:'M4 5v5h5 M4 10a8 8 0 1 1 0 5 M12 7v6l3 2',
    camera:'M3 7h4l2-3h6l2 3h4v13H3z M16 13a4 4 0 1 1-8 0 4 4 0 0 1 8 0',
    mix:'M8 3h8 M9 3v6l-5 9v3h16v-3l-5-9V3 M7 15h10',
    plus:'M12 4v16 M4 12h16', minus:'M4 12h16',
    stock:'M3 7 12 3l9 4v13H3z M3 7l9 4 9-4 M12 11v9',
    report:'M6 3h9l4 4v14H6z M15 3v5h4 M9 12h7 M9 16h7',
    data:'M4 4h16v16H4z M8 4v6h8V4 M8 20v-6h8v6',
    arrow:'M5 12h14 M13 6l6 6-6 6', settings:'M4 7h16 M4 17h16 M8 4v6 M16 14v6'
  };
  function icon(name) { return '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="' + (paths[name] || paths.work) + '"/></svg>'; }
  function toast(message, ms = 3600) {
    let el = document.getElementById('proToast'); if (!el) { el = document.createElement('div'); el.id = 'proToast'; el.className = 'proToast'; el.setAttribute('role','status'); document.body.append(el); }
    el.textContent = message; el.hidden = false; clearTimeout(toast.timer); toast.timer = setTimeout(() => { el.hidden = true; }, ms);
  }
  function showError(message) {
    let el = document.getElementById('proError'); if (!el) { el = document.createElement('div'); el.id = 'proError'; el.className = 'proError'; el.setAttribute('role','alert'); document.body.append(el); } el.textContent = message;
  }
  const modules = {
    dryer:[['home','Обзор','home'],['calc','Расчёт','calc'],['dry','Цикл','work'],['history','История','history'],['photos','Фото','camera']],
    connisseur:[['home','Обзор','home'],['mix','Смесь','mix'],['cal','Калибровка','calc'],['work','Работа','work'],['history','История','history']],
    chem:[['home','Обзор','home'],['receipt','Приход','plus'],['issue','Выдача','minus'],['stocks','Остатки','stock'],['reports','Отчёты','report']]
  };
  function highlight() {
    const current = window.DonskoeModule?.current?.() || 'home';
    document.querySelectorAll('.proNav [data-page]').forEach(b => { if (b.dataset.page === current) b.setAttribute('aria-current','page'); else b.removeAttribute('aria-current'); });
  }
  function mount() {
    const module = document.body.dataset.module;
    if (modules[module]) {
      const nav = document.createElement('nav'); nav.className = 'proNav'; nav.setAttribute('aria-label','Разделы модуля');
      nav.innerHTML = modules[module].map(([route, name, ico]) => '<button type="button" data-page="'+route+'">'+icon(ico)+'<span>'+name+'</span></button>').join('');
      nav.addEventListener('click', e => { const b = e.target.closest('[data-page]'); if (b && window.DonskoeModule) { window.DonskoeModule.navigate(b.dataset.page); highlight(); } });
      document.body.append(nav);
      function toolbar() {
        if (document.querySelector('.proToolbar')) return;
        const header = document.querySelector('.topbar') || document.querySelector('.brandCard') || document.querySelector('header') || document.querySelector('.brand') || document.querySelector('.header');
        if (header) header.insertAdjacentHTML('afterend','<div class="proToolbar"><a href="../index.html">'+icon('home')+' Все модули</a><span class="moduleVersion" data-app-version></span><a href="../index.html#data">'+icon('data')+' Данные и копия</a></div>');
      }
      toolbar(); highlight();
      document.addEventListener('donskoe-route', () => { toolbar(); highlight(); labelFields(); });
    }
    labelFields(); if (window.__donskoeStorageError) showError(window.__donskoeStorageError);
    document.addEventListener('keydown', e => {
      if (e.key !== 'Escape') return;
      const open = document.querySelector('.modalShade:not(.hidden) .closeBtn,.modalBack:not(.hidden) [id$="Cancel"],.modalBack:not(.hidden) [id$="Close"]'); if (open) open.click();
    });
    installUpdates();
  }
  function labelFields() {
    document.querySelectorAll('[data-app-version]').forEach(el=>el.textContent=Core.VERSION);
    document.querySelectorAll('.field').forEach(field => {
      const label = field.querySelector('label'), control = field.querySelector('input:not([type="hidden"]),select,textarea');
      if (label && control?.id && !label.contains(control) && !label.htmlFor) label.htmlFor = control.id;
    });
  }
  async function installUpdates() {
    if (!('serviceWorker' in navigator)) return;
    function offer(reg) {
      if (!reg.waiting || document.getElementById('proUpdate')) return;
      const panel = document.createElement('div'); panel.id='proUpdate'; panel.className='proUpdate';
      panel.innerHTML='<span>Подготовлена новая версия приложения. Обновите после завершения работы.</span><button type="button">Обновить</button><button type="button" aria-label="Позже">×</button>';
      const buttons = panel.querySelectorAll('button'); buttons[1].onclick=()=>panel.remove();
      buttons[0].onclick=async()=>{
        if (Core.activeWork()) return toast('Сначала завершите текущий цикл, работу или калибровку. Данные продолжают сохраняться.', 5500);
        buttons[0].disabled=true;
        const workers=await navigator.serviceWorker.getRegistrations(); let changed=false;
        navigator.serviceWorker.addEventListener('controllerchange',()=>{ if(!changed){changed=true;location.reload();} },{once:true});
        workers.forEach(r=>r.waiting?.postMessage({type:'ACTIVATE_UPDATE'}));
        setTimeout(()=>{if(!changed){buttons[0].disabled=false;toast('Обновление подготовлено. Закройте и снова откройте приложение.');}},6000);
      };
      document.body.append(panel);
    }
    for (const r of await navigator.serviceWorker.getRegistrations()) {
      offer(r); r.addEventListener('updatefound',()=>{const worker=r.installing;worker?.addEventListener('statechange',()=>{if(worker.state==='installed')offer(r);});});
    }
  }
  window.DonskoeUI={icon,toast,highlight,labelFields};
  window.addEventListener('donskoe-storage-error', e=>showError(e.detail));
  document.addEventListener('DOMContentLoaded',mount);
})();
