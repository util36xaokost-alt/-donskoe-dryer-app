// Generated from release.json. Edit release.json, then run scripts/build-release.py.
globalThis.DONSKOE_RELEASE={"version": "7.2.3", "previousVersion": "7.2.2", "stage": "hybrid-ui", "build": "20260911-hybrid", "date": "2026-09-11"};
