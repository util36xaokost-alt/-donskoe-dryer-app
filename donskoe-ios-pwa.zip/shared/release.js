// Generated from release.json. Edit release.json, then run scripts/build-release.py.
globalThis.DONSKOE_RELEASE={"version": "4.15", "previousVersion": "4.14", "stage": "web-release-four-modules-15", "build": "20260919-web-4.15", "date": "2026-09-19"};
