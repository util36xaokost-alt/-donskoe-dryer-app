// Generated from release.json. Edit release.json, then run scripts/build-release.py.
globalThis.DONSKOE_RELEASE={"version": "4.17", "previousVersion": "4.16", "stage": "web-release-four-modules-17", "build": "20260927-web-4.17", "date": "2026-09-27"};
