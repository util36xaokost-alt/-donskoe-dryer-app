// Generated from release.json. Edit release.json, then run scripts/build-release.py.
globalThis.DONSKOE_RELEASE={"version": "7.4.8", "previousVersion": "7.4.7", "stage": "fields-split-cleanup", "build": "20260913-fields-split-cleanup", "date": "2026-09-13"};
