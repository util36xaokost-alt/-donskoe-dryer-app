// Generated from release.json. Edit release.json, then run scripts/build-release.py.
globalThis.DONSKOE_RELEASE={"version": "7.2.7", "previousVersion": "7.2.6", "stage": "content-online-topmenu", "build": "20260912-contentonline", "date": "2026-09-12"};
