// Generated from release.json. Edit release.json, then run scripts/build-release.py.
globalThis.DONSKOE_RELEASE={"version": "7.4.12", "previousVersion": "7.4.11", "stage": "fields-independent-map-package", "build": "20260914-fields-independent-map-package", "date": "2026-09-14"};
