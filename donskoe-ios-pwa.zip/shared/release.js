// Generated from release.json. Edit release.json, then run scripts/build-release.py.
globalThis.DONSKOE_RELEASE={"version": "7.2.8", "previousVersion": "7.2.7", "stage": "unified-refresh-offline", "build": "20260912-unifiedrefresh", "date": "2026-09-12"};
