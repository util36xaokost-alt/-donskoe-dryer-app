// Generated from release.json. Edit release.json, then run scripts/build-release.py.
globalThis.DONSKOE_RELEASE={"version": "7.4.2", "previousVersion": "7.4.1", "stage": "fields-angle-control", "build": "20260913-fields-angle-control-v2", "date": "2026-09-13"};
