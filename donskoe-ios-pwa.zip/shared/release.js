// Generated from release.json. Edit release.json, then run scripts/build-release.py.
globalThis.DONSKOE_RELEASE={"version": "7.4.10", "previousVersion": "7.4.9", "stage": "fields-nspd-photo-basemap", "build": "20260914-fields-nspd-photo-basemap", "date": "2026-09-14"};
