// Generated from release.json. Edit release.json, then run scripts/build-release.py.
globalThis.DONSKOE_RELEASE={"version": "4.16", "previousVersion": "4.15", "stage": "web-release-four-modules-16", "build": "20260920-web-4.16", "date": "2026-09-20"};
