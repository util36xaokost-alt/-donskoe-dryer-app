// Generated from release.json. Edit release.json, then run scripts/build-release.py.
globalThis.DONSKOE_RELEASE={"version": "7.2.4", "previousVersion": "7.2.3", "stage": "hybrid-home-fit", "build": "20260911-homefit", "date": "2026-09-11"};
