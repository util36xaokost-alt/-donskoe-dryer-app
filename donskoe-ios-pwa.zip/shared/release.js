// Generated from release.json. Edit release.json, then run scripts/build-release.py.
globalThis.DONSKOE_RELEASE={"version": "4.14", "previousVersion": "7.4.13", "stage": "web-release-four-modules-14", "build": "20260918-web-4.14", "date": "2026-09-18"};
