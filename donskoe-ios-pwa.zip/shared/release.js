// Generated from release.json. Edit release.json, then run scripts/build-release.py.
globalThis.DONSKOE_RELEASE={"version": "7.4.6", "previousVersion": "7.4.5", "stage": "fields-measure-fixes", "build": "20260913-fields-measure-fixes", "date": "2026-09-13"};
