// Generated from release.json. Edit release.json, then run scripts/build-release.py.
globalThis.DONSKOE_RELEASE={"version": "7.2.5", "previousVersion": "7.2.4", "stage": "mockup-match-home", "build": "20260912-mockupmatch", "date": "2026-09-12"};
