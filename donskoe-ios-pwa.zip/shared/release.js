// Generated from release.json. Edit release.json, then run scripts/build-release.py.
globalThis.DONSKOE_RELEASE={"version": "7.4.11", "previousVersion": "7.4.10", "stage": "fields-local-orthophoto-build", "build": "20260914-fields-local-orthophoto-build", "date": "2026-09-14"};
