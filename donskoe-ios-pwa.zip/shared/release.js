// Generated from release.json. Edit release.json, then run scripts/build-release.py.
globalThis.DONSKOE_RELEASE={"version": "7.2.9", "previousVersion": "7.2.8", "stage": "network-status-header-hotfix", "build": "20260912-networkfix", "date": "2026-09-12"};
