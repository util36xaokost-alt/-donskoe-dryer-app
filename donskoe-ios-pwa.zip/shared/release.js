// Generated from release.json. Edit release.json, then run scripts/build-release.py.
globalThis.DONSKOE_RELEASE={"version": "4.18", "previousVersion": "4.17", "stage": "web-release-four-modules-18", "build": "20260928-web-4.18", "date": "2026-09-28"};
