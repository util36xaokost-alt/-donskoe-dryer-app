// Generated from release.json. Edit release.json, then run scripts/build-release.py.
globalThis.DONSKOE_RELEASE={"version": "7.4.4", "previousVersion": "7.4.3", "stage": "fields-label-deconflict", "build": "20260913-fields-label-deconflict", "date": "2026-09-13"};
