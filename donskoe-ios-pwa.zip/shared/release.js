// Generated from release.json. Edit release.json, then run scripts/build-release.py.
globalThis.DONSKOE_RELEASE={"version": "7.4.1", "previousVersion": "7.4.0", "stage": "fields-quick-plan", "build": "20260913-fields-quick-plan-v1", "date": "2026-09-13"};
