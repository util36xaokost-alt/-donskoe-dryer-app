// Generated from release.json. Edit release.json, then run scripts/build-release.py.
globalThis.DONSKOE_RELEASE={"version": "7.4.0", "previousVersion": "7.3.2", "stage": "fields-foundation", "build": "20260912-fields-foundation-1", "date": "2026-09-12"};
