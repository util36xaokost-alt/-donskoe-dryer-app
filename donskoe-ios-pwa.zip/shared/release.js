// Generated from release.json. Edit release.json, then run scripts/build-release.py.
globalThis.DONSKOE_RELEASE={"version": "7.3.0", "previousVersion": "7.2.9", "stage": "stable-network-update-final", "build": "20260912-stable-online-update", "date": "2026-09-12"};
