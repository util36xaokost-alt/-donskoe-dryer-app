// Generated from release.json. Edit release.json, then run scripts/build-release.py.
globalThis.DONSKOE_RELEASE={"version": "7.2.1", "previousVersion": "7.1.0", "stage": 1, "build": "20260909-stage1", "date": "2026-09-09"};
