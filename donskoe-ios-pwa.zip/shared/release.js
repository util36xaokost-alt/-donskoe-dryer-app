// Generated from release.json. Edit release.json, then run scripts/build-release.py.
globalThis.DONSKOE_RELEASE={"version": "7.4.13", "previousVersion": "7.4.12", "stage": "fields-map-label-controls", "build": "20260914-fields-map-label-controls", "date": "2026-09-14"};
