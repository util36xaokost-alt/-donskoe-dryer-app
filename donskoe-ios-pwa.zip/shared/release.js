// Generated from release.json. Edit release.json, then run scripts/build-release.py.
globalThis.DONSKOE_RELEASE={"version": "7.2.2", "previousVersion": "7.2.1", "stage": "1.1", "build": "20260911-hotfix", "date": "2026-09-11"};
