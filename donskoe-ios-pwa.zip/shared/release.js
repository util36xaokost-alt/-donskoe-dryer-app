// Generated from release.json. Edit release.json, then run scripts/build-release.py.
globalThis.DONSKOE_RELEASE={"version": "7.3.1", "previousVersion": "7.3.0", "stage": "stable-network-attention-header", "build": "20260912-ping-header-attention", "date": "2026-09-12"};
