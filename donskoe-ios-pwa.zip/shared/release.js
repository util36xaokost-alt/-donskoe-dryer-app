// Generated from release.json. Edit release.json, then run scripts/build-release.py.
globalThis.DONSKOE_RELEASE={"version": "7.4.5", "previousVersion": "7.4.4", "stage": "fields-quick-plan-split", "build": "20260913-fields-quick-plan-split", "date": "2026-09-13"};
