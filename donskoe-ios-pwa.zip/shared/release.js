// Generated from release.json. Edit release.json, then run scripts/build-release.py.
globalThis.DONSKOE_RELEASE={"version": "7.4.7", "previousVersion": "7.4.6", "stage": "fields-measure-polygon-intersection", "build": "20260913-fields-measure-polygon-intersection", "date": "2026-09-13"};
