// Generated from release.json. Edit release.json, then run scripts/build-release.py.
globalThis.DONSKOE_RELEASE={"version": "7.2.6", "previousVersion": "7.2.5", "stage": "header-exact-mockup", "build": "20260912-headerexact", "date": "2026-09-12"};
