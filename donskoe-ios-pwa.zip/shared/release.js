// Generated from release.json. Edit release.json, then run scripts/build-release.py.
globalThis.DONSKOE_RELEASE={"version": "7.4.3", "previousVersion": "7.4.2", "stage": "fields-compact-angle-all-labels", "build": "20260913-fields-compact-angle-all-labels", "date": "2026-09-13"};
