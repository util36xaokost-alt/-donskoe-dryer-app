const CACHE='donskoe-dryer-ios-v5-9-20260823';
const APP_SHELL=['./','./index.html','./manifest.webmanifest','./logo.png','./apple-touch-icon.png','./icon-192.png','./icon-512.png'];
self.addEventListener('install',event=>{event.waitUntil(caches.open(CACHE).then(cache=>cache.addAll(APP_SHELL)).then(()=>self.skipWaiting()));});
self.addEventListener('activate',event=>{event.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k.startsWith('donskoe-dryer-')&&k!==CACHE).map(k=>caches.delete(k)))).then(()=>self.clients.claim()));});
self.addEventListener('fetch',event=>{
  if(event.request.method!=='GET') return;
  const url=new URL(event.request.url);
  if(url.origin!==self.location.origin) return;
  if(event.request.mode==='navigate'){
    event.respondWith((async()=>{
      const cache=await caches.open(CACHE);
      const cached=await cache.match('./index.html');
      if(cached){
        event.waitUntil(fetch(event.request).then(r=>{if(r&&r.ok)return cache.put('./index.html',r.clone());}).catch(()=>{}));
        return cached;
      }
      try{const r=await fetch(event.request);if(r&&r.ok)await cache.put('./index.html',r.clone());return r;}catch(e){return new Response('<!doctype html><meta charset="utf-8"><h2>Нет связи</h2><p>Открой приложение один раз при наличии интернета, чтобы сохранить его для офлайн-работы.</p>',{headers:{'Content-Type':'text/html; charset=utf-8'}});}
    })());
    return;
  }
  event.respondWith((async()=>{
    const cached=await caches.match(event.request);
    if(cached)return cached;
    try{const r=await fetch(event.request);if(r&&r.ok){const cache=await caches.open(CACHE);event.waitUntil(cache.put(event.request,r.clone()));}return r;}catch(e){return new Response('',{status:504,statusText:'Offline'});}
  })());
});

