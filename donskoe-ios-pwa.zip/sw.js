const CACHE='donskoe-master-v6-8-0-connisseur-workcontrol-20260829';
const ROOT_CORE=[
  './index.html','./styles.css','./app.js','./manifest.webmanifest','./logo.png','./apple-touch-icon.png','./icon-192.png','./icon-512.png','./dryer-module.png','./warehouse-module.png','./connisseur-module.png'
];
const MODULE_CORE=[
  './dryer/index.html','./dryer/manifest.webmanifest','./dryer/logo.png','./dryer/apple-touch-icon.png','./dryer/icon-192.png','./dryer/icon-512.png','./dryer/sw.js',
  './chem/index.html','./chem/styles.css','./chem/app.js','./chem/manifest.webmanifest','./chem/logo.png','./chem/apple-touch-icon.png','./chem/icon-192.png','./chem/icon-512.png','./chem/sw.js',
  './connisseur/index.html','./connisseur/styles.css','./connisseur/app.js','./connisseur/manifest.webmanifest','./connisseur/logo.png','./connisseur/connisseur-logo.png','./connisseur/icon-192.png','./connisseur/icon-512.png'
];
const OFFLINE_HTML='<!doctype html><html lang="ru"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><style>body{font-family:-apple-system,BlinkMacSystemFont,Segoe UI,Arial,sans-serif;background:#f4f7f8;color:#162333;padding:28px}main{max-width:520px;margin:auto;background:#fff;border:1px solid #d7e0e6;border-radius:18px;padding:22px}h2{margin-top:0}</style><main><h2>Донское</h2><p>Нет связи и локальная копия этой страницы ещё не сохранена.</p><p>Открой приложение один раз при наличии интернета.</p></main></html>';

function scopeInfo(){
  const scope=new URL(self.registration.scope);
  return {scope,base:scope.pathname};
}
function relativePath(url){
  const {base}=scopeInfo();
  let rel=url.pathname.startsWith(base)?url.pathname.slice(base.length):'';
  try{rel=decodeURIComponent(rel);}catch(e){}
  return rel.replace(/^\/+/, '');
}
function navKey(url){
  const rel=relativePath(url).replace(/\/+$/,'');
  if(!rel||rel==='index.html')return './index.html';
  if(rel==='dryer'||rel==='dryer/index.html'||rel.startsWith('dryer/'))return './dryer/index.html';
  if(rel==='chem'||rel==='chem/index.html'||rel.startsWith('chem/'))return './chem/index.html';
  if(rel==='connisseur'||rel==='connisseur/index.html'||rel.startsWith('connisseur/'))return './connisseur/index.html';
  return './index.html';
}
async function fetchAndCache(request,key){
  const r=await fetch(request,{cache:'no-store'});
  if(r&&r.ok){const c=await caches.open(CACHE);await c.put(key||request,r.clone());}
  return r;
}

self.addEventListener('install',event=>{
  event.waitUntil((async()=>{
    const c=await caches.open(CACHE);
    // Корневой экран обязан сохраниться целиком. Если это не удалось, новый SW не активируем.
    await c.addAll(ROOT_CORE);
    // Модули кэшируем по возможности: при обычном деплое они уже доступны, но их отсутствие не ломает корень.
    await Promise.allSettled(MODULE_CORE.map(async u=>{
      const r=await fetch(u,{cache:'reload'});
      if(r&&r.ok)await c.put(u,r.clone());
    }));
    await self.skipWaiting();
  })());
});

self.addEventListener('activate',event=>{
  event.waitUntil((async()=>{
    const keys=await caches.keys();
    // Удаляем только старые кэши материнского приложения. Кэши модулей не трогаем — это резерв офлайн-работы.
    await Promise.all(keys.filter(k=>k.startsWith('donskoe-master-')&&k!==CACHE).map(k=>caches.delete(k)));
    await self.clients.claim();
  })());
});

self.addEventListener('fetch',event=>{
  if(event.request.method!=='GET')return;
  const url=new URL(event.request.url);
  if(url.origin!==self.location.origin)return;

  if(event.request.mode==='navigate'){
    event.respondWith((async()=>{
      const c=await caches.open(CACHE);
      const key=navKey(url);
      // Критично для iPhone: сначала локальная страница, сеть только обновляет кэш в фоне.
      const cached=(await c.match(key))||(await caches.match(key));
      if(cached){
        event.waitUntil(fetchAndCache(event.request,key).catch(()=>{}));
        return cached;
      }
      try{return await fetchAndCache(event.request,key);}catch(e){
        return new Response(OFFLINE_HTML,{status:200,headers:{'Content-Type':'text/html; charset=utf-8','Cache-Control':'no-store'}});
      }
    })());
    return;
  }

  event.respondWith((async()=>{
    const cached=await caches.match(event.request,{ignoreSearch:true});
    if(cached){
      event.waitUntil(fetchAndCache(event.request,event.request).catch(()=>{}));
      return cached;
    }
    try{return await fetchAndCache(event.request,event.request);}catch(e){
      return new Response('',{status:504,statusText:'Offline'});
    }
  })());
});
