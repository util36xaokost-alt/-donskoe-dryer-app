const CACHE='donskoe-dryer-ios-v3';
const APP_SHELL=['./','./index.html','./manifest.webmanifest','./logo.png','./apple-touch-icon.png','./icon-192.png','./icon-512.png'];
self.addEventListener('install',event=>{event.waitUntil(caches.open(CACHE).then(cache=>cache.addAll(APP_SHELL)).then(()=>self.skipWaiting()));});
self.addEventListener('activate',event=>{event.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k!==CACHE).map(k=>caches.delete(k)))).then(()=>self.clients.claim()));});
self.addEventListener('fetch',event=>{
  if(event.request.method!=='GET') return;
  const url=new URL(event.request.url);
  if(url.origin!==self.location.origin) return;
  if(event.request.mode==='navigate'){
    event.respondWith((async()=>{
      const cache=await caches.open(CACHE);
      const cached=await cache.match('./index.html');
      const network=fetch(event.request).then(async r=>{if(r&&r.ok)await cache.put('./index.html',r.clone());return r;}).catch(()=>null);
      if(cached){event.waitUntil(network);return cached;}
      const r=await network;
      return r||new Response('<h1>Приложение ещё не было сохранено для офлайн-работы</h1>',{headers:{'Content-Type':'text/html; charset=utf-8'}});
    })());
    return;
  }
  event.respondWith((async()=>{
    const cached=await caches.match(event.request);
    if(cached)return cached;
    try{const r=await fetch(event.request);if(r&&r.ok){const cache=await caches.open(CACHE);cache.put(event.request,r.clone());}return r;}catch(e){return new Response('',{status:504,statusText:'Offline'});}
  })());
});
