const CACHE='donskoe-master-v6-1-2-web-20260823a';
const ROOT=['./','./index.html','./styles.css','./app.js','./manifest.webmanifest','./logo.png','./apple-touch-icon.png','./icon-192.png','./icon-512.png','./dryer-module.png','./warehouse-module.png'];
const MODULES=[
  './dryer/','./dryer/index.html','./dryer/manifest.webmanifest','./dryer/logo.png','./dryer/apple-touch-icon.png','./dryer/icon-192.png','./dryer/icon-512.png','./dryer/sw.js',
  './chem/','./chem/index.html','./chem/styles.css','./chem/app.js','./chem/manifest.webmanifest','./chem/logo.png','./chem/apple-touch-icon.png','./chem/icon-192.png','./chem/icon-512.png','./chem/sw.js'
];
self.addEventListener('install',event=>{event.waitUntil((async()=>{const c=await caches.open(CACHE);await c.addAll(ROOT);for(const u of MODULES){try{await c.add(u);}catch(e){}}await self.skipWaiting();})());});
self.addEventListener('activate',event=>{event.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>(k.startsWith('donskoe-master-')&&k!==CACHE)||k.startsWith('donskoe-dryer-ios-v')).map(k=>caches.delete(k)))).then(()=>self.clients.claim()));});
self.addEventListener('fetch',event=>{
  if(event.request.method!=='GET')return;
  const url=new URL(event.request.url);if(url.origin!==self.location.origin)return;
  const scopePath=new URL(self.registration.scope).pathname;const rel=url.pathname.startsWith(scopePath)?url.pathname.slice(scopePath.length):'';
  const isModule=rel.startsWith('dryer/')||rel.startsWith('chem/');
  if(event.request.mode==='navigate'){
    event.respondWith((async()=>{
      try{const r=await fetch(event.request);if(r&&r.ok){const c=await caches.open(CACHE);event.waitUntil(c.put(event.request,r.clone()));}return r;}catch(e){const c=await caches.open(CACHE);if(isModule){return (await c.match(event.request))||(await c.match('./'+rel))||(await c.match('./'+rel.replace(/\?.*$/,'')))||Response.error();}return (await c.match('./index.html'))||Response.error();}
    })());return;
  }
  event.respondWith((async()=>{const c=await caches.open(CACHE);const cached=await c.match(event.request);if(cached)return cached;try{const r=await fetch(event.request);if(r&&r.ok)event.waitUntil(c.put(event.request,r.clone()));return r;}catch(e){return new Response('',{status:504,statusText:'Offline'});}})());
});
