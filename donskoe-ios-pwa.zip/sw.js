
// Immutable shell cache for one release. User journals and photos live separately.
const CACHE="donskoe-master-7.4.10-20260914-fields-nspd-photo-basemap", PREFIX="donskoe-master-", CORE=["./index.html", "./attention.html", "./styles.css", "./app.js", "./attention.js", "./manifest.webmanifest", "./logo.png", "./apple-touch-icon.png", "./icon-192.png", "./icon-512.png", "./header-hero.png", "./dryer-module.png", "./warehouse-module.png", "./connisseur-module.png", "./fields-module.png", "./shared/release.js", "./shared/core.js", "./shared/theme.css", "./shared/ui.js", "./dryer/index.html", "./dryer/manifest.webmanifest", "./dryer/logo.png", "./dryer/icon-192.png", "./dryer/icon-512.png", "./dryer/apple-touch-icon.png", "./chem/index.html", "./chem/manifest.webmanifest", "./chem/logo.png", "./chem/icon-192.png", "./chem/icon-512.png", "./chem/app.js", "./chem/styles.css", "./chem/apple-touch-icon.png", "./connisseur/index.html", "./connisseur/manifest.webmanifest", "./connisseur/logo.png", "./connisseur/icon-192.png", "./connisseur/icon-512.png", "./connisseur/app.js", "./connisseur/styles.css", "./connisseur/connisseur-logo.png", "./fields/index.html", "./fields/manifest.webmanifest", "./fields/logo.png", "./fields/icon-192.png", "./fields/icon-512.png", "./fields/app.js", "./fields/styles.css", "./fields/data.js", "./fields/basemap.js", "./fields/apple-touch-icon.png"], OPTIONAL=[], PERSIST=[], BASEMAP=false;
const OFFLINE='<!doctype html><html lang="ru"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><style>body{font:16px/1.6 system-ui;background:#f1f3f2;color:#182f2c;padding:30px}main{max-width:480px;margin:40px auto}a{color:#126a51}</style><main><h1>Донское</h1><p>Не удалось открыть страницу из локального кэша.</p><p>Вернитесь на главный экран и нажмите Refresh при наличии интернета.</p><a href="./index.html">На главный экран</a></main></html>';
self.addEventListener('install',event=>event.waitUntil((async()=>{
 const cache=await caches.open(CACHE);
 try{await cache.addAll(CORE);}catch(e){await caches.delete(CACHE);throw e;}
 await Promise.allSettled(OPTIONAL.map(group=>cache.addAll(group)));
 // Existing workers continue until windows close or the operator accepts the update.
})()));
self.addEventListener('message',event=>{if(event.data?.type==='ACTIVATE_UPDATE')self.skipWaiting();});
self.addEventListener('activate',event=>event.waitUntil((async()=>{
 const names=await caches.keys();
 await Promise.all(names.filter(n=>n.startsWith(PREFIX)&&n!==CACHE&&!PERSIST.includes(n)).map(n=>caches.delete(n)));
 await self.clients.claim();
})()));
self.addEventListener('fetch',event=>{
 if(event.request.method!=='GET')return;
 const url=new URL(event.request.url),scope=new URL(self.registration.scope);
 if(BASEMAP&&url.origin==='https://nspd.gov.ru'&&url.pathname.includes('/api/aeggis/v2/36344/wmts/')){
  event.respondWith((async()=>{const cache=await caches.open('donskoe-fields-basemap-nspd-v1'),cached=await cache.match(event.request.url);if(cached)return cached;try{const response=await fetch(event.request);if(response&&(response.ok||response.type==='opaque'))await cache.put(event.request.url,response.clone());return response;}catch(e){return new Response('',{status:504});}})());return;
 }
 if(url.origin!==scope.origin)return;
 // Never cache authenticated API calls or arbitrary same-origin responses.
 const pathname=url.pathname;
 let key;
 if(event.request.mode==='navigate'){
  let relative=pathname.startsWith(scope.pathname)?pathname.slice(scope.pathname.length):'';
  if(!relative||relative==='index.html')relative='index.html';
  else if(true){const mod=relative.split('/')[0];if(['dryer','chem','connisseur','fields'].includes(mod))relative=mod+'/index.html';}
  key=new URL(relative,scope).href;
 }else{
  const clean=new URL(url);clean.search='';clean.hash='';key=clean.href;
 }
 const known=[...CORE,...OPTIONAL.flat()].some(p=>new URL(p,scope).href===key);
 if(!known)return;
 event.respondWith((async()=>{
  const cache=await caches.open(CACHE),cached=await cache.match(key);
  if(cached)return cached;
  try{
   const ctrl=new AbortController(),timer=setTimeout(()=>ctrl.abort(),10000);
   try{const response=await fetch(event.request,{signal:ctrl.signal,cache:'no-store'});if(!response.ok)throw new Error('HTTP '+response.status);return response;}finally{clearTimeout(timer);}
  }catch(e){return event.request.mode==='navigate'?new Response(OFFLINE,{status:503,headers:{'Content-Type':'text/html;charset=utf-8'}}):new Response('',{status:504});}
 })());
});
