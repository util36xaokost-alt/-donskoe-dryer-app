(function(){
  const $=id=>document.getElementById(id);
  function setNetwork(){
    const online=navigator.onLine;
    const pill=$('networkPill');
    pill.classList.toggle('online',online);pill.classList.toggle('offline',!online);
    $('networkText').textContent=online?'Online':'Offline';
  }
  function getDeviceLabel(){
    const ua=navigator.userAgent||'';
    if(/iPhone/i.test(ua))return 'iPhone';
    if(/iPad/i.test(ua))return 'iPad';
    if(/Android/i.test(ua))return 'Android';
    if(/Macintosh/i.test(ua))return 'Mac';
    if(/Windows/i.test(ua))return 'Windows';
    return 'Устройство';
  }
  function getDeviceId(){
    let id=localStorage.getItem('donskoe_device_id');
    if(!id){
      const raw=(crypto&&crypto.randomUUID)?crypto.randomUUID():(''+Date.now()+Math.random()).replace(/\D/g,'');
      id='D-'+raw.replace(/-/g,'').slice(0,8).toUpperCase();
      localStorage.setItem('donskoe_device_id',id);
    }
    return id;
  }
  function openId(){
    $('deviceName').textContent=getDeviceLabel();$('deviceId').textContent=getDeviceId();$('idShade').classList.remove('hidden');
  }
  function closeId(){$('idShade').classList.add('hidden');}
  $('idBtn').addEventListener('click',openId);$('closeId').addEventListener('click',closeId);$('idShade').addEventListener('click',e=>{if(e.target===$('idShade'))closeId();});$('brandHome').addEventListener('click',()=>window.scrollTo({top:0,behavior:'smooth'}));
  window.addEventListener('online',setNetwork);window.addEventListener('offline',setNetwork);setNetwork();

  const params=new URLSearchParams(location.search);const skip=params.get('skipSplash')==='1'||sessionStorage.getItem('donskoe_booted')==='1';
  const splash=$('splash');
  if(skip){splash.classList.add('hide');}
  else{sessionStorage.setItem('donskoe_booted','1');setTimeout(()=>splash.classList.add('hide'),1950);}
  if(params.get('skipSplash')==='1'&&history.replaceState){history.replaceState({},'',location.pathname+location.hash);}

  if('serviceWorker' in navigator){window.addEventListener('load',()=>navigator.serviceWorker.register('./sw.js',{scope:'./'}).catch(()=>{}));}
})();
