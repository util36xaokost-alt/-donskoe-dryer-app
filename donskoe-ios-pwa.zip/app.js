(function () {
'use strict';
const C=window.DonskoeCore,U=window.DonskoeUI,$=id=>document.getElementById(id);
const esc=s=>String(s??'').replace(/[&<>"']/g,x=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[x]));
document.querySelectorAll('[data-icon]').forEach(el=>{el.innerHTML=U.icon(el.dataset.icon);});
let profile=C.read('donskoe_profile_v1',{})||{},restoreFile=null,installPrompt=null;

const splash=$('splash');
if(splash){
 const params=new URLSearchParams(location.search),skip=params.get('skipSplash')==='1'||sessionStorage.getItem('donskoe_booted')==='1';
 if(skip)splash.classList.add('hide');else{sessionStorage.setItem('donskoe_booted','1');setTimeout(()=>splash.classList.add('hide'),1450);}
 if(params.get('skipSplash')==='1'&&history.replaceState)history.replaceState({},'',location.pathname+location.hash);
}
const brandHome=$('brandHome');if(brandHome)brandHome.onclick=()=>window.scrollTo({top:0,behavior:'smooth'});

function online(){const connected=navigator.onLine!==false;$('networkPill').className='networkPill '+(connected?'online':'offline');$('networkText').textContent=connected?'Online':'Offline';}
function profileCaption(){$('deviceCaption').textContent=(profile.deviceName||'Это устройство')+' · локальные данные';}
function backupCaption(){const t=C.read('donskoe_last_backup_v1',null),text=t?'Последняя выгрузка копии: '+new Date(t).toLocaleString('ru-RU',{day:'numeric',month:'long',hour:'2-digit',minute:'2-digit'}):'Резервная копия ещё не создавалась на этом устройстве.';const a=$('backupCaption'),b=$('backupCaptionVisible');if(a)a.textContent=text;if(b)b.textContent=text;}
function attention(title,sub,href,warn=false){return '<a class="attentionItem'+(warn?' warn':'')+'" href="'+href+'">'+U.icon(warn?'report':'work')+'<div class="attentionText"><b>'+esc(title)+'</b><small>'+esc(sub)+'</small></div>'+U.icon('arrow')+'</a>';}
async function refresh(){
 profileCaption();backupCaption();online();
 $('todayLabel').textContent=new Date().toLocaleDateString('ru-RU',{weekday:'long',day:'numeric',month:'long',year:'numeric'});
 const dryer=C.read('donskoe_dryer_history_v1',[]),plan=C.read('donskoe_dryer_active_plan_v1',null),con=C.read('donskoe_connisseur_state_v1',{})||{};
 const hist=Array.isArray(dryer)?dryer:[],runs=Array.isArray(con.runs)?con.runs:[],bags=Array.isArray(con.bags)?con.bags:[];
 const run=runs.find(x=>x.clientId===con.activeRunId&&x.status==='running'&&!x.deletedAt);
 const pendingDry=C.read('donskoe_dryer_cloud_pending_v1',[]),pendingCon=C.read('donskoe_connisseur_cloud_pending_v1',[]);
 let pending=(pendingDry?.length||0)+(pendingCon?.length||0),active=Number(!!plan)+Number(!!run)+Number(!!con.activeCal),tasks=[];
 $('activeCount').textContent=active;$('cyclesCount').textContent=hist.length;const strip=document.querySelector('.systemStrip');if(strip)strip.classList.toggle('hasWork',active>0);const workText=$('workStatusText');if(workText)workText.textContent=active>0?(active===1?'Есть активная работа':'Активных процессов: '+active):'Система готова';
 $('dryerSummary').textContent=plan?'Цикл №'+plan.cycleNo+' · открыт':hist.length?hist.length+' циклов в истории':'Начните с расчёта или ввода цикла';
 const completed=runs.filter(x=>x.status==='completed'&&!x.deletedAt).length;
 $('connSummary').textContent=run?(run.pausedAt?'Работа на паузе':'Учёт обработки запущен'):completed?completed+' работ завершено':'Подготовьте первую смесь';
 if(plan)tasks.push(attention('Продолжить цикл сушки №'+plan.cycleNo,'Текущий режим и контроль проб','dryer/index.html?page=dry'));
 if(run)tasks.push(attention(run.pausedAt?'ConNiSseur: работа на паузе':'ConNiSseur: идёт учёт обработки','Открыть счётчики и контроль расхода','connisseur/index.html?page=work'));
 if(con.activeCal)tasks.push(attention('Калибровка насоса не завершена','Продолжить контроль фактической подачи','connisseur/index.html?page=cal'));
 const waiting=bags.filter(x=>!x.deletedAt&&x.status==='completed'&&!(Number(x.actualNetKg)>0)).length;
 if(waiting)tasks.push(attention('Внести вес биг-бэгов: '+waiting,'Уточнить тоннаж и производительность СМ‑4','connisseur/index.html?page=history&tab=bags',true));
 if(pendingDry?.length)tasks.push(attention('Сушка: '+pendingDry.length+' изменений ждут облака','Откройте модуль для отправки записей','dryer/index.html',true));
 if(pendingCon?.length)tasks.push(attention('ConNiSseur: '+pendingCon.length+' изменений ждут облака','Проверить синхронизацию истории','connisseur/index.html?page=history',true));
 const attentionTitle=$('attentionTitle'),attentionHint=$('attentionHint');if(attentionTitle)attentionTitle.textContent=active>0?'Продолжить работу':'Требует внимания';if(attentionHint)attentionHint.textContent=active>0?'Незавершённые процессы и важные действия':'Проверьте данные и синхронизацию';
 const dbs=await Promise.allSettled([C.readDb('donskoe_chem_offline_v1'),C.readDb('donskoe_dryer_photos_v1')]);
 if(dbs[0].status==='fulfilled'){
  const db=dbs[0].value,moves=(db.chem_movements||[]).filter(x=>!x.deleted_at),balances=new Map();
  moves.forEach(x=>balances.set(x.batch_id,(balances.get(x.batch_id)||0)+Number(x.quantity_delta||0)));
  const batches=(db.chem_batches||[]).filter(x=>!x.deleted_at&&(balances.get(x.id)||0)>0),products=new Set(batches.map(x=>(x.product_id||x.temporary_name)+'|'+x.base_unit));
  const queue=db.pending||[];pending+=queue.length;
  $('chemSummary').textContent=products.size?products.size+' позиций в наличии':moves.length?'По учёту положительных остатков нет':'Приход и выдача химии';
  const needs=batches.filter(x=>x.completeness==='needs_details').length;
  const expiry=batches.filter(x=>x.expires_on&&new Date(x.expires_on+'T23:59:59').getTime()-Date.now()<=90*86400000).length;
  if(queue.length)tasks.push(attention('Склад: '+queue.length+' изменений ждут облака','Открыть очередь и состояние отправки','chem/index.html?page=settings',true));
  if(needs)tasks.push(attention('Дополнить сведения о партиях: '+needs,'Указать партии, сроки и документы','chem/index.html?page=needsDetails',true));
  if(expiry)tasks.push(attention('Проверить сроки годности: '+expiry+' партий','Просрочены или истекают в ближайшие 90 дней','chem/index.html?page=stocks',true));
 }else $('chemSummary').textContent='Локальный склад не прочитан — откройте модуль';
 if(dbs[1].status==='fulfilled'){
  const photos=dbs[1].value.photos||[],waitingPhotos=photos.filter(x=>!x.deleted&&!x.deleted_at&&!x.uploaded_at&&!x.storage_path).length;
  pending+=waitingPhotos;
  if(waitingPhotos)tasks.push(attention('Фото сушки: '+waitingPhotos+' без облачной копии','Проверить фотофиксацию','dryer/index.html?page=photos',true));
 }
 $('pendingCount').textContent=dbs.every(x=>x.status==='fulfilled')?pending:pending+'+';if(strip)strip.classList.toggle('hasPending',pending>0);const syncText=$('syncStatusText');if(syncText)syncText.textContent=pending>0?'Ожидает отправки':'Синхронизировано';
 $('attentionSection').hidden=!tasks.length;$('attentionList').innerHTML=tasks.join('');
}
async function offlineStatus(){
 if(!('caches' in window)){$('offlineStatus').textContent='Офлайн-хранилище недоступно в этом браузере.';return;}
 const required=['index.html','shared/core.js','shared/ui.js','shared/theme.css','dryer/index.html','chem/index.html','chem/app.js','connisseur/index.html','connisseur/app.js'];
 const statuses=await Promise.all(required.map(p=>caches.match(new URL(p,location.href.split('#')[0]))));
 $('offlineStatus').textContent=statuses.every(Boolean)?'Страницы трёх модулей доступны в локальном кэше. Фото доступны без сети, если сохранены на этом устройстве.':'Локальная версия ещё подготавливается. Откройте все три модуля при наличии сети перед работой в поле.';
}
function openData(){$('deviceName').value=profile.deviceName||'';$('operatorName').value=profile.operatorName||'';if(!$('dataDialog').open)$('dataDialog').showModal();offlineStatus().catch(()=>{$('offlineStatus').textContent='Не удалось проверить локальную версию.';});}
$('settingsOpen').onclick=openData;
$('dataClose').onclick=()=>{$('dataDialog').close();if(location.hash==='#data')history.replaceState(null,'',location.pathname+location.search);};
$('profileForm').onsubmit=e=>{e.preventDefault();profile={deviceName:$('deviceName').value.trim(),operatorName:$('operatorName').value.trim(),updatedAt:new Date().toISOString()};C.write('donskoe_profile_v1',profile);profileCaption();U.toast('Настройки сохранены на этом устройстве');};
$('backupCreate').onclick=async()=>{
 const button=$('backupCreate');button.disabled=true;$('backupStatus').textContent='Собираем журналы и локальные фотографии…';
 try{const snap=await C.snapshot();C.download(JSON.stringify(snap),'donskoe-backup-'+C.stamp()+'.json');C.write('donskoe_last_backup_v1',Date.now());backupCaption();$('backupStatus').textContent='Копия сформирована. Сохраните скачанный файл в «Файлы» или на другое устройство.';}
 catch(error){$('backupStatus').textContent='Копия не создана: '+error.message;}finally{button.disabled=false;}
};
$('backupSelect').onclick=()=>{$('backupFile').value='';$('backupFile').click();};
$('backupFile').onchange=async()=>{
 const file=$('backupFile').files[0];if(!file)return;restoreFile=null;$('restorePreview').hidden=true;
 try{
  if(file.size>300*1024*1024)throw new Error('Копия больше 300 МБ. Для её восстановления потребуется отдельная проверка на компьютере.');
  const parsed=C.validateBackup(JSON.parse(await file.text()));
  if(C.owner()&&parsed.ownerId&&C.owner()!==parsed.ownerId)throw new Error('Копия другой учётной записи. Войдите под исходной учётной записью.');
  restoreFile=parsed;
  const records=Object.values(parsed.databases).reduce((n,db)=>n+Object.values(db).reduce((m,arr)=>m+arr.length,0),0);
  $('restoreInfo').textContent='Дата: '+new Date(parsed.createdAt).toLocaleString('ru-RU')+'. Настроек и журналов: '+Object.keys(parsed.local).length+'. Записей в хранилищах: '+records+'. Размер: '+(file.size/1024/1024).toFixed(1)+' МБ.';
  $('restorePreview').hidden=false;$('backupStatus').textContent='Файл проверен. До нажатия кнопки ниже данные не меняются.';
 }catch(error){$('backupStatus').textContent='Импорт не начат: '+error.message;}
};
$('restoreCancel').onclick=()=>{restoreFile=null;$('restorePreview').hidden=true;};
$('restoreConfirm').onclick=async()=>{
 if(!restoreFile)return;
 if(C.activeWork()){$('backupStatus').textContent='Сначала завершите текущий цикл, обработку и калибровку. Во время активной работы восстановление недоступно.';return;}
 $('restoreConfirm').disabled=true;
 try{const result=await C.restoreMissing(restoreFile);$('backupStatus').textContent='Добавлено: '+result.added+'. Уже существовало: '+result.skipped+'. Откройте модули и проверьте журналы.';restoreFile=null;$('restorePreview').hidden=true;await refresh();}
 catch(error){$('backupStatus').textContent=error.message;}finally{$('restoreConfirm').disabled=false;}
};
$('updateCheck').onclick=async()=>{
 if(!navigator.onLine){$('offlineStatus').textContent='Для проверки обновления нужен интернет. Локальная версия продолжает работать.';return;}
 $('updateCheck').disabled=true;
 try{if(!navigator.serviceWorker)throw new Error('Браузер не поддерживает установку');const regs=await navigator.serviceWorker.getRegistrations();const results=await Promise.allSettled(regs.map(r=>r.update()));if(!regs.length||results.some(x=>x.status==='rejected'))throw new Error('Не удалось связаться с сервером');await offlineStatus();U.toast('Проверка запущена. После загрузки новой версии появится предложение обновить приложение.');}
 catch(error){$('offlineStatus').textContent='Проверка не выполнена: '+error.message;}finally{$('updateCheck').disabled=false;}
};
function info(title,html){$('infoTitle').textContent=title;$('infoBody').innerHTML=html;$('infoDialog').showModal();}
$('infoClose').onclick=()=>$('infoDialog').close();
$('changesOpen').onclick=()=>info('Донское '+DonskoeCore.VERSION,'<p>Гибридная эксплуатационная версия: знакомый главный экран сохранён, а логика 7.2 остаётся внутри.</p><ul><li>Возвращены крупные визуальные карточки AGRONEZH, склада и ConNiSseur.</li><li>Статус сети, активной работы и очереди синхронизации остаётся на главном экране.</li><li>Резервные копии, обновления и технические функции перенесены в ID / настройки.</li><li>Сохранены исправления навигации, истории, черновиков, транзакций и восстановления данных из 7.2.2.</li></ul>');
window.addEventListener('beforeinstallprompt',e=>{e.preventDefault();installPrompt=e;});
$('installOpen').onclick=async()=>{
 if(installPrompt){await installPrompt.prompt();installPrompt=null;return;}
 info('Установить приложение','<p><b>iPhone / iPad:</b> откройте этот адрес в Safari → «Поделиться» → «На экран Домой» → «Добавить».</p><p><b>Android:</b> откройте адрес в Chrome → меню ⋮ → «Установить приложение» или «Добавить на главный экран».</p><p>Откройте каждый модуль при наличии интернета. Для сохранения записей продолжайте пользоваться тем же адресом и браузером.</p>');
};
window.addEventListener('online',online);window.addEventListener('offline',online);window.addEventListener('storage',()=>refresh().catch(console.error));window.addEventListener('pageshow',()=>refresh().catch(console.error));
if('serviceWorker' in navigator)window.addEventListener('load',()=>navigator.serviceWorker.register('./sw.js',{updateViaCache:'none'}).then(r=>r.update()).catch(()=>{}));
if(location.hash==='#data')openData();
refresh().catch(error=>U.toast('Не удалось прочитать сводку: '+error.message,6000));
})();
