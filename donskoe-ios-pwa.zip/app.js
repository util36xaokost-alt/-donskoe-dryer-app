(function () {
'use strict';
const C=window.DonskoeCore,U=window.DonskoeUI,$=id=>document.getElementById(id);
const esc=s=>String(s??'').replace(/[&<>"']/g,x=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[x]));
document.querySelectorAll('[data-icon]').forEach(el=>{el.innerHTML=U.icon(el.dataset.icon);});
let profile=C.read('donskoe_profile_v1',{})||{},restoreFile=null,installPrompt=null;
let networkReachable=navigator.onLine===false?false:null,refreshBusy=false,remoteRelease=null,networkTimer=null;
const moduleSyncTargets=[
 {name:'dryer',url:'dryer/index.html'},
 {name:'chem',url:'chem/index.html'},
 {name:'connisseur',url:'connisseur/index.html'}
];
document.querySelectorAll('[data-app-version]').forEach(el=>el.textContent=C.VERSION);

const splash=$('splash');
if(splash){
 const params=new URLSearchParams(location.search),skip=params.get('skipSplash')==='1'||sessionStorage.getItem('donskoe_booted')==='1';
 if(skip)splash.classList.add('hide');else{sessionStorage.setItem('donskoe_booted','1');setTimeout(()=>splash.classList.add('hide'),1450);}
 if(params.get('skipSplash')==='1'&&history.replaceState)history.replaceState({},'',location.pathname+location.hash);
}
const brandHome=$('brandHome');if(brandHome)brandHome.onclick=()=>window.scrollTo({top:0,behavior:'smooth'});

function setBadge(el,count){
 if(!el)return;
 const n=Number(count)||0;
 el.textContent=n;
 el.hidden=n<=0;
}
function versionParts(v){return String(v||'').split('.').map(x=>Number.parseInt(x,10)||0);}
function newerVersion(a,b){const A=versionParts(a),B=versionParts(b),n=Math.max(A.length,B.length);for(let i=0;i<n;i++){if((A[i]||0)!==(B[i]||0))return (A[i]||0)>(B[i]||0);}return false;}
function showUpdateNotice(release){
 const box=$('updateNotice'),label=$('updateVersion');if(!box||!label)return;
 if(release?.version&&newerVersion(release.version,C.VERSION)){remoteRelease=release;label.textContent='v'+release.version;box.hidden=false;}
 else{remoteRelease=release||remoteRelease;box.hidden=true;}
}
function renderNetworkUi(){
 const connected=networkReachable===true,checking=networkReachable===null;
 document.body.classList.toggle('isOffline',!connected);
 const heroOnline=$('heroOnline');
 if(heroOnline){
  heroOnline.textContent='Online';
  heroOnline.classList.toggle('isOffline',!connected&&!checking);
  heroOnline.classList.toggle('isChecking',checking);
  heroOnline.setAttribute('aria-label',connected?'Online — интернет доступен':checking?'Проверяем соединение':'Online — интернет недоступен');
 }
 const refreshButton=$('globalRefresh');
 if(refreshButton){refreshButton.classList.toggle('isOffline',!connected);refreshButton.setAttribute('aria-label',connected?'Синхронизировать данные и проверить обновления':'Проверить соединение');}
}
async function probeNetwork(showChecking=false){
 // Do not trust navigator.onLine in iOS standalone mode: it can report false even
 // while Wi‑Fi/data are usable. A completed same-origin HTTP response is enough
 // to prove reachability; release.json itself may legitimately be absent/stale.
 if(showChecking&&networkReachable!==true){networkReachable=null;renderNetworkUi();}
 const ctrl=new AbortController(),timer=setTimeout(()=>ctrl.abort(),6500);
 try{
  const r=await fetch('release.json?connect='+Date.now(),{cache:'no-store',headers:{'Cache-Control':'no-cache'},signal:ctrl.signal});
  networkReachable=true;renderNetworkUi();
  if(r.ok){
   try{showUpdateNotice(await r.json());}catch(_){/* Connectivity is still valid even if release metadata is malformed. */}
  }
  return true;
 }catch(_){networkReachable=false;renderNetworkUi();return false;}
 finally{clearTimeout(timer);}
}
function scheduleNetworkProbe(){clearTimeout(networkTimer);networkTimer=setTimeout(()=>{if(document.visibilityState==='visible')probeNetwork(false).catch(()=>{});},250);}
function profileCaption(){const el=$('deviceCaption');if(el)el.textContent=(profile.deviceName||'Это устройство')+' · локальные данные';}
function backupCaption(){const t=C.read('donskoe_last_backup_v1',null),text=t?'Последняя выгрузка копии: '+new Date(t).toLocaleString('ru-RU',{day:'numeric',month:'long',hour:'2-digit',minute:'2-digit'}):'Резервная копия ещё не создавалась на этом устройстве.';const a=$('backupCaption'),b=$('backupCaptionVisible');if(a)a.textContent=text;if(b)b.textContent=text;}
function makeTask(title,sub,href,warn=false){return {title,sub,href,warn};}
function taskHtml(task){return '<a class="attentionPageItem'+(task.warn?' warn':'')+'" href="'+task.href+'"><div class="attentionPageIcon">'+(task.warn?'!':'•')+'</div><div class="attentionPageText"><b>'+esc(task.title)+'</b><small>'+esc(task.sub)+'</small></div><div class="attentionPageArrow">›</div></a>';}

async function refresh(){
 profileCaption();backupCaption();renderNetworkUi();
 $('todayLabel').textContent=new Date().toLocaleDateString('ru-RU',{weekday:'long',day:'numeric',month:'long',year:'numeric'});
 const dryer=C.read('donskoe_dryer_history_v1',[]),plan=C.read('donskoe_dryer_active_plan_v1',null),con=C.read('donskoe_connisseur_state_v1',{})||{};
 const hist=Array.isArray(dryer)?dryer:[],runs=Array.isArray(con.runs)?con.runs:[],bags=Array.isArray(con.bags)?con.bags:[];
 const run=runs.find(x=>x.clientId===con.activeRunId&&x.status==='running'&&!x.deletedAt);
 const pendingDry=C.read('donskoe_dryer_cloud_pending_v1',[]),pendingCon=C.read('donskoe_connisseur_cloud_pending_v1',[]);
 let pending=(pendingDry?.length||0)+(pendingCon?.length||0),active=Number(!!plan)+Number(!!run)+Number(!!con.activeCal),tasks=[];

 const workText=$('workStatusText');
 if(workText)workText.textContent=active>0?'Активная работа':'Система готова';
 setBadge($('activeCount'),active);
 $('cyclesCount').textContent=hist.length;
 $('dryerSummary').textContent=plan?'Цикл №'+plan.cycleNo+' · открыт':hist.length?hist.length+' циклов в истории':'Начните с расчёта или ввода цикла';
 const completed=runs.filter(x=>x.status==='completed'&&!x.deletedAt).length;
 $('connSummary').textContent=run?(run.pausedAt?'Работа на паузе':'Учёт обработки запущен'):completed?completed+' работ завершено':'Подготовьте первую смесь';

 if(plan)tasks.push(makeTask('Продолжить цикл сушки №'+plan.cycleNo,'Текущий режим и контроль проб','dryer/index.html?page=dry'));
 if(run)tasks.push(makeTask(run.pausedAt?'ConNiSseur: работа на паузе':'ConNiSseur: идёт учёт обработки','Открыть счётчики и контроль расхода','connisseur/index.html?page=work'));
 if(con.activeCal)tasks.push(makeTask('Калибровка насоса не завершена','Продолжить контроль фактической подачи','connisseur/index.html?page=cal'));
 const waiting=bags.filter(x=>!x.deletedAt&&x.status==='completed'&&!(Number(x.actualNetKg)>0)).length;
 if(waiting)tasks.push(makeTask('Внести вес биг-бэгов: '+waiting,'Уточнить тоннаж и производительность СМ‑4','connisseur/index.html?page=history&tab=bags',true));
 if(pendingDry?.length)tasks.push(makeTask('Сушка: '+pendingDry.length+' изменений ждут облака','Откройте модуль для отправки записей','dryer/index.html',true));
 if(pendingCon?.length)tasks.push(makeTask('ConNiSseur: '+pendingCon.length+' изменений ждут облака','Проверить синхронизацию истории','connisseur/index.html?page=history',true));

 const dbs=await Promise.allSettled([C.readDb('donskoe_chem_offline_v1'),C.readDb('donskoe_dryer_photos_v1')]);
 if(dbs[0].status==='fulfilled'){
  const db=dbs[0].value,moves=(db.chem_movements||[]).filter(x=>!x.deleted_at),balances=new Map();
  moves.forEach(x=>balances.set(x.batch_id,(balances.get(x.batch_id)||0)+Number(x.quantity_delta||0)));
  const batches=(db.chem_batches||[]).filter(x=>!x.deleted_at&&(balances.get(x.id)||0)>0),products=new Set(batches.map(x=>(x.product_id||x.temporary_name)+'|'+x.base_unit));
  const queue=db.pending||[];pending+=queue.length;
  $('chemSummary').textContent=products.size?products.size+' позиций в наличии':moves.length?'По учёту положительных остатков нет':'Приход и выдача химии';
  const needs=batches.filter(x=>x.completeness==='needs_details').length;
  const expiry=batches.filter(x=>x.expires_on&&new Date(x.expires_on+'T23:59:59').getTime()-Date.now()<=90*86400000).length;
  if(queue.length)tasks.push(makeTask('Склад: '+queue.length+' изменений ждут облака','Открыть очередь и состояние отправки','chem/index.html?page=settings',true));
  if(needs)tasks.push(makeTask('Дополнить сведения о партиях: '+needs,'Указать партии, сроки и документы','chem/index.html?page=needsDetails',true));
  if(expiry)tasks.push(makeTask('Проверить сроки годности: '+expiry+' партий','Просрочены или истекают в ближайшие 90 дней','chem/index.html?page=stocks',true));
 }else $('chemSummary').textContent='Локальный склад не прочитан — откройте модуль';
 if(dbs[1].status==='fulfilled'){
  const photos=dbs[1].value.photos||[],waitingPhotos=photos.filter(x=>!x.deleted&&!x.deleted_at&&!x.uploaded_at&&!x.storage_path).length;
  pending+=waitingPhotos;
  if(waitingPhotos)tasks.push(makeTask('Фото сушки: '+waitingPhotos+' без облачной копии','Проверить фотофиксацию','dryer/index.html?page=photos',true));
 }

 const syncText=$('syncStatusText');
 if(syncText)syncText.textContent=pending>0?'Ждёт отправки':'Синхронизировано';
 setBadge($('pendingCount'),pending);
 const attentionCount=tasks.length;
 const attentionLink=$('attentionLink'),attentionIcon=$('attentionIcon');
 if(attentionLink){
  attentionLink.classList.toggle('hasAttention',attentionCount>0);
  attentionLink.classList.toggle('allClear',attentionCount===0);
  attentionLink.setAttribute('aria-disabled',attentionCount===0?'true':'false');
  attentionLink.setAttribute('aria-label',attentionCount>0?'Открыть список действий':'Всё в порядке — действий не требуется');
 }
 if(attentionIcon)attentionIcon.textContent=attentionCount>0?'▣':'✓';
 setBadge($('attentionCount'),attentionCount);
 $('attentionStatusText').textContent=attentionCount>0?'Требует внимания':'Всё в порядке';

 C.write('donskoe_attention_items_v1',{
  updatedAt:new Date().toISOString(),
  active,
  pending,
  online:networkReachable===true,
  workLabel:workText?workText.textContent:'Система готова',
  syncLabel:syncText?syncText.textContent:'Синхронизировано',
  items:tasks
 });
}
async function offlineStatus(){
 if(!('caches' in window)){$('offlineStatus').textContent='Офлайн-хранилище недоступно в этом браузере.';return;}
 const required=['index.html','attention.html','styles.css','app.js','header-hero.png','dryer-module.png','warehouse-module.png','connisseur-module.png','shared/release.js','shared/core.js','shared/ui.js','shared/theme.css','dryer/index.html','dryer/logo.png','chem/index.html','chem/app.js','chem/styles.css','chem/logo.png','connisseur/index.html','connisseur/app.js','connisseur/styles.css','connisseur/connisseur-logo.png'];
 const release=globalThis.DONSKOE_RELEASE||{},cacheName='donskoe-master-'+C.VERSION+'-'+String(release.build||'');
 const names=await caches.keys(),current=names.includes(cacheName)?await caches.open(cacheName):null,base=new URL('./',location.href);
 const statuses=current?await Promise.all(required.map(p=>current.match(new URL(p,base)))):[];
 $('offlineStatus').textContent=current&&statuses.every(Boolean)?'Главный экран, все три модуля и их логотипы сохранены для запуска без интернета. Фото доступны без сети, если сохранены на этом устройстве.':'Локальная версия '+C.VERSION+' ещё подготавливается. Нажмите Refresh при стабильном интернете и дождитесь завершения.';
}
function openData(){$('deviceName').value=profile.deviceName||'';$('operatorName').value=profile.operatorName||'';if(!$('dataDialog').open)$('dataDialog').showModal();offlineStatus().catch(()=>{$('offlineStatus').textContent='Не удалось проверить локальную версию.';});}
['settingsOpen','settingsOpenTop'].forEach(id=>{const el=$(id);if(el)el.onclick=openData;});
const heroOnlineBtn=$('heroOnline');if(heroOnlineBtn)heroOnlineBtn.onclick=()=>probeNetwork(true).catch(()=>{});
const attentionLinkEl=$('attentionLink');if(attentionLinkEl)attentionLinkEl.addEventListener('click',e=>{if(attentionLinkEl.classList.contains('allClear'))e.preventDefault();});
$('dataClose').onclick=()=>{$('dataDialog').close();if(location.hash==='#data')history.replaceState(null,'',location.pathname+location.search);};
$('profileForm').onsubmit=e=>{e.preventDefault();profile={deviceName:$('deviceName').value.trim(),operatorName:$('operatorName').value.trim(),updatedAt:new Date().toISOString()};C.write('donskoe_profile_v1',profile);profileCaption();U.toast('Настройки сохранены на этом устройстве');};
$('backupCreate').onclick=async()=>{
 const button=$('backupCreate');button.disabled=true;$('backupStatus').textContent='Собираем журналы и локальные фотографии…';
 try{const snap=await C.snapshot();C.download(JSON.stringify(snap),'donskoe-backup-'+C.stamp()+'.json');C.write('donskoe_last_backup_v1',Date.now());backupCaption();$('backupStatus').textContent='Копия сформирована. Сохраните скачанный файл в «Файлы» или на другое устройство.';}
 catch(error){$('backupStatus').textContent='Копия не создана: '+error.message;}finally{button.disabled=false;}
};
$('backupSelect').onclick=()=>{$('backupFile').value='';$('backupFile').click();};
$('backupFile').onchange=async()=>{
 const file=$('backupFile').files[0];if(!file)return;restoreFile=null;$('restorePreview').hidden=true;
 try{
  if(file.size>300*1024*1024)throw new Error('Копия больше 300 МБ. Для её восстановления потребуется отдельная проверка на компьютере.');
  const parsed=C.validateBackup(JSON.parse(await file.text()));
  if(C.owner()&&parsed.ownerId&&C.owner()!==parsed.ownerId)throw new Error('Копия другой учётной записи. Войдите под исходной учётной записью.');
  restoreFile=parsed;
  const records=Object.values(parsed.databases).reduce((n,db)=>n+Object.values(db).reduce((m,arr)=>m+arr.length,0),0);
  $('restoreInfo').textContent='Дата: '+new Date(parsed.createdAt).toLocaleString('ru-RU')+'. Настроек и журналов: '+Object.keys(parsed.local).length+'. Записей в хранилищах: '+records+'. Размер: '+(file.size/1024/1024).toFixed(1)+' МБ.';
  $('restorePreview').hidden=false;$('backupStatus').textContent='Файл проверен. До нажатия кнопки ниже данные не меняются.';
 }catch(error){$('backupStatus').textContent='Импорт не начат: '+error.message;}
};
$('restoreCancel').onclick=()=>{restoreFile=null;$('restorePreview').hidden=true;};
$('restoreConfirm').onclick=async()=>{
 if(!restoreFile)return;
 if(C.activeWork()){$('backupStatus').textContent='Сначала завершите текущий цикл, обработку и калибровку. Во время активной работы восстановление недоступно.';return;}
 $('restoreConfirm').disabled=true;
 try{const result=await C.restoreMissing(restoreFile);$('backupStatus').textContent='Добавлено: '+result.added+'. Уже существовало: '+result.skipped+'. Откройте модули и проверьте журналы.';restoreFile=null;$('restorePreview').hidden=true;await refresh();}
 catch(error){$('backupStatus').textContent=error.message;}finally{$('restoreConfirm').disabled=false;}
};
$('updateCheck').onclick=async()=>{
 $('updateCheck').disabled=true;
 try{await runGlobalRefresh();await offlineStatus();}
 catch(error){$('offlineStatus').textContent='Проверка не выполнена: '+error.message;}
 finally{$('updateCheck').disabled=false;}
};
function info(title,html){$('infoTitle').textContent=title;$('infoBody').innerHTML=html;$('infoDialog').showModal();}
$('infoClose').onclick=()=>$('infoDialog').close();
$('changesOpen').onclick=()=>info('Донское '+DonskoeCore.VERSION,'<p>Версия с единым обновлением и усиленным офлайн-режимом.</p><ul><li>Refresh на главной странице запускает синхронизацию всех трёх модулей и проверку обновления.</li><li>При новой версии на главной появляется сообщение с её номером; обновление активируется через Refresh.</li><li>Вложенные service worker модулей больше не создают отдельные запросы обновления.</li><li>Главный экран и логотипы модулей входят в обязательный офлайн-кэш.</li><li>Online определяется проверкой реального доступа к серверу, а не только флагом браузера.</li><li>При отсутствии задач блок внимания показывает «Всё в порядке».</li></ul>');
window.addEventListener('beforeinstallprompt',e=>{e.preventDefault();installPrompt=e;});
$('installOpen').onclick=async()=>{
 if(installPrompt){await installPrompt.prompt();installPrompt=null;return;}
 info('Установить приложение','<p><b>iPhone / iPad:</b> откройте этот адрес в Safari → «Поделиться» → «На экран Домой» → «Добавить».</p><p><b>Android:</b> откройте адрес в Chrome → меню ⋮ → «Установить приложение» или «Добавить на главный экран».</p><p>После первого успешного Refresh главный экран и все три модуля сохраняются для запуска без сети. Для сохранения записей продолжайте пользоваться тем же адресом и браузером.</p>');
};
async function masterWorker(){
 if(!('serviceWorker' in navigator))return null;
 const rootScope=new URL('./',location.href).href;
 const regs=await navigator.serviceWorker.getRegistrations();
 await Promise.all(regs.filter(r=>r.scope!==rootScope&&['dryer/','chem/','connisseur/'].some(x=>r.scope.endsWith(x))).map(r=>r.unregister().catch(()=>false)));
 let reg=(await navigator.serviceWorker.getRegistrations()).find(r=>r.scope===rootScope)||null;
 if(!reg)reg=await navigator.serviceWorker.register('./sw.js',{scope:'./',updateViaCache:'none'});
 return reg;
}
function waitForWorker(reg,timeout=9000){return new Promise(resolve=>{
 if(reg.waiting)return resolve(reg.waiting);
 const started=Date.now();let timer=null;
 const done=()=>{if(timer)clearInterval(timer);resolve(reg.waiting||null);};
 timer=setInterval(()=>{if(reg.waiting||Date.now()-started>=timeout)done();},180);
 if(reg.installing)reg.installing.addEventListener('statechange',()=>{if(reg.waiting)done();});
 reg.addEventListener('updatefound',()=>{reg.installing?.addEventListener('statechange',()=>{if(reg.waiting)done();});},{once:true});
 });}
async function activateWaiting(reg){
 if(!reg?.waiting)return false;
 if(C.activeWork()){U.toast('Новая версия готова. Сначала завершите текущую работу, затем нажмите Refresh.',5500);return false;}
 return new Promise(resolve=>{
  let finished=false;const finish=v=>{if(finished)return;finished=true;resolve(v);};
  navigator.serviceWorker.addEventListener('controllerchange',()=>{finish(true);location.reload();},{once:true});
  reg.waiting.postMessage({type:'ACTIVATE_UPDATE'});
  setTimeout(()=>finish(false),6000);
 });
}
function backgroundSync(target,timeout=22000){return new Promise(resolve=>{
 const token=target.name+'-'+Date.now()+'-'+Math.random().toString(16).slice(2),frame=document.createElement('iframe');
 frame.className='syncFrame';frame.setAttribute('aria-hidden','true');
 let done=false,timer;
 const finish=result=>{if(done)return;done=true;clearTimeout(timer);window.removeEventListener('message',onMessage);frame.remove();resolve(result);};
 const onMessage=e=>{if(e.origin!==location.origin||e.source!==frame.contentWindow)return;const d=e.data||{};if(d.type==='DONSKOE_BACKGROUND_SYNC_DONE'&&d.module===target.name&&d.token===token)finish({module:target.name,ok:d.ok!==false});};
 window.addEventListener('message',onMessage);timer=setTimeout(()=>finish({module:target.name,ok:false,timeout:true}),timeout);
 frame.src=target.url+'?backgroundSync=1&syncToken='+encodeURIComponent(token)+'&skipSplash=1';document.body.append(frame);
 });}
async function runAllModuleSync(){const out=[];for(const target of moduleSyncTargets)out.push(await backgroundSync(target));return out;}
async function runGlobalRefresh(){
 if(refreshBusy)return;refreshBusy=true;const btn=$('globalRefresh');btn?.classList.add('isBusy');
 try{
  const connected=await probeNetwork(true);if(!connected){U.toast('Интернета нет. Локальные данные и модули доступны офлайн.',4200);return;}
  const reg=await masterWorker();
  if(reg){try{await reg.update();}catch(_){}await waitForWorker(reg,9000);}
  const syncResults=await runAllModuleSync();
  await refresh();await probeNetwork(false);
  if(reg?.waiting){const activated=await activateWaiting(reg);if(activated)return;}
  const pending=Number($('pendingCount')?.textContent||0),failed=syncResults.filter(x=>x.timeout).length;
  if(remoteRelease?.version&&newerVersion(remoteRelease.version,C.VERSION))U.toast('Новая версия v'+remoteRelease.version+' найдена. Если обновление ещё загружается, нажмите Refresh ещё раз.',5200);
  else if(pending>0||failed)U.toast('Refresh завершён. Часть изменений пока осталась в очереди и будет повторена при стабильной сети.',5200);
  else U.toast('Синхронизация завершена. Обновлений нет.',3200);
 }finally{refreshBusy=false;btn?.classList.remove('isBusy');renderNetworkUi();}
}
const globalRefresh=$('globalRefresh');if(globalRefresh)globalRefresh.onclick=()=>runGlobalRefresh().catch(e=>U.toast('Refresh: '+e.message,5200));
window.addEventListener('online',()=>{scheduleNetworkProbe();refresh().catch(console.error);});
window.addEventListener('offline',()=>{networkReachable=false;renderNetworkUi();refresh().catch(console.error);});
window.addEventListener('storage',()=>refresh().catch(console.error));
window.addEventListener('pageshow',()=>{refresh().catch(console.error);scheduleNetworkProbe();});
document.addEventListener('visibilitychange',()=>{if(document.visibilityState==='visible')scheduleNetworkProbe();});
if('serviceWorker' in navigator)window.addEventListener('load',()=>masterWorker().then(()=>probeNetwork(true)).catch(()=>{networkReachable=false;renderNetworkUi();}));
setInterval(()=>{if(document.visibilityState==='visible')probeNetwork(false).catch(()=>{});},60000);
if(location.hash==='#data')openData();
renderNetworkUi();
refresh().catch(error=>U.toast('Не удалось прочитать сводку: '+error.message,6000));
scheduleNetworkProbe();
})();
