(function () {
'use strict';
const C=window.DonskoeCore,U=window.DonskoeUI,$=id=>document.getElementById(id);
const esc=s=>String(s??'').replace(/[&<>"']/g,x=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[x]));
document.querySelectorAll('[data-icon]').forEach(el=>{el.innerHTML=U.icon(el.dataset.icon);});
let profile=C.read('donskoe_profile_v1',{})||{},restoreFile=null,installPrompt=null;
let networkReachable=null,networkFailures=0,lastNetworkSuccess=0,refreshBusy=false,remoteRelease=null,networkTimer=null,networkProbeBusy=false;
const moduleSyncTargets=[
 {name:'dryer',url:'dryer/index.html'},
 {name:'chem',url:'chem/index.html'},
 {name:'connisseur',url:'connisseur/index.html'}
];
document.querySelectorAll('[data-app-version]').forEach(el=>el.textContent=C.VERSION);

const splash=$('splash');
if(splash){
 const params=new URLSearchParams(location.search),skip=params.get('skipSplash')==='1'||sessionStorage.getItem('donskoe_booted')==='1';
 if(skip)splash.classList.add('hide');else{sessionStorage.setItem('donskoe_booted','1');setTimeout(()=>splash.classList.add('hide'),1450);}
 if(params.get('skipSplash')==='1'&&history.replaceState)history.replaceState({},'',location.pathname+location.hash);
}
const brandHome=$('brandHome');if(brandHome)brandHome.onclick=()=>window.scrollTo({top:0,behavior:'smooth'});

function setBadge(el,count){
 if(!el)return;
 const n=Number(count)||0;
 el.textContent=n;
 el.hidden=n<=0;
}
function versionParts(v){return String(v||'').split('.').map(x=>Number.parseInt(x,10)||0);}
function newerVersion(a,b){const A=versionParts(a),B=versionParts(b),n=Math.max(A.length,B.length);for(let i=0;i<n;i++){if((A[i]||0)!==(B[i]||0))return (A[i]||0)>(B[i]||0);}return false;}
function showUpdateNotice(release){
 const box=$('updateNotice'),label=$('updateVersion');if(!box||!label)return;
 if(release?.version&&newerVersion(release.version,C.VERSION)){remoteRelease=release;label.textContent='v'+release.version;box.hidden=false;}
 else{remoteRelease=release||remoteRelease;box.hidden=true;}
}
function renderNetworkUi(){
 const connected=networkReachable===true,checking=networkReachable===null;
 document.body.classList.toggle('isOffline',!connected);
 const heroOnline=$('heroOnline');
 if(heroOnline){
  heroOnline.textContent='Online';
  heroOnline.classList.toggle('isOffline',!connected&&!checking);
  heroOnline.classList.toggle('isChecking',checking);
  heroOnline.setAttribute('aria-label',connected?'Online — интернет доступен':checking?'Проверяем соединение':'Online — интернет недоступен');
 }
 const refreshButton=$('globalRefresh');
 if(refreshButton){refreshButton.classList.toggle('isOffline',!connected);refreshButton.setAttribute('aria-label',connected?'Синхронизировать данные и проверить обновления':'Проверить соединение');}
}
async function probeNetwork(showChecking=false){
 // Do not trust navigator.onLine by itself: iOS standalone may report false states.
 // The visible status is driven by a real uncached request to the server.
 if(networkProbeBusy)return networkReachable===true;
 networkProbeBusy=true;
 if(showChecking&&networkReachable!==true){networkReachable=null;renderNetworkUi();}
 const ctrl=new AbortController(),timer=setTimeout(()=>ctrl.abort(),3500);
 try{
  // HEAD is not handled by our service worker (it handles GET only), so a cached app shell
  // can never masquerade as a live Internet connection.
  const url='release.json?ping='+Date.now();
  let r=await fetch(url,{method:'HEAD',cache:'no-store',credentials:'same-origin',signal:ctrl.signal});
  if(!r.ok)throw new Error('HTTP '+r.status);
  networkFailures=0;lastNetworkSuccess=Date.now();networkReachable=true;renderNetworkUi();
  // Version JSON is fetched separately only while the server is confirmed reachable.
  fetch('release.json?release='+Date.now(),{cache:'no-store',credentials:'same-origin'})
   .then(x=>x.ok?x.json():null).then(x=>{if(x)showUpdateNotice(x);}).catch(()=>{});
  return true;
 }catch(_){
  networkFailures+=1;
  // Airplane mode / explicit OS offline + failed real ping is enough to go offline immediately.
  // Otherwise require two consecutive failed pings to avoid a transient mobile/Wi-Fi hiccup.
  const hardOffline=(navigator.onLine===false);
  if(hardOffline||networkFailures>=2){networkReachable=false;renderNetworkUi();}
  else{scheduleNetworkProbe(900);}
  return false;
 }finally{clearTimeout(timer);networkProbeBusy=false;}
}
function scheduleNetworkProbe(delay=200){
 clearTimeout(networkTimer);
 networkTimer=setTimeout(()=>{if(document.visibilityState==='visible')probeNetwork(false).catch(()=>{});},delay);
}
async function offlineStatus(){
 if(!('caches' in window)){$('offlineStatus').textContent='Офлайн-хранилище недоступно в этом браузере.';return;}
 const required=['index.html','attention.html','styles.css','app.js','header-hero.png','dryer-module.png','warehouse-module.png','connisseur-module.png','shared/release.js','shared/core.js','shared/ui.js','shared/theme.css','dryer/index.html','dryer/logo.png','chem/index.html','chem/app.js','chem/styles.css','chem/logo.png','connisseur/index.html','connisseur/app.js','connisseur/styles.css','connisseur/connisseur-logo.png','fields/index.html','fields/app.js','fields/styles.css','fields/fields-data.js','fields/logo.png'];
 const release=globalThis.DONSKOE_RELEASE||{},cacheName='donskoe-master-'+C.VERSION+'-'+String(release.build||'');
 const names=await caches.keys(),current=names.includes(cacheName)?await caches.open(cacheName):null,base=new URL('./',location.href);
 const statuses=current?await Promise.all(required.map(p=>current.match(new URL(p,base)))):[];
 $('offlineStatus').textContent=current&&statuses.every(Boolean)?'Главный экран, все четыре модуля и их основные данные сохранены для запуска без интернета. Фото доступны без сети, если сохранены на этом устройстве.':'Локальная версия '+C.VERSION+' ещё подготавливается. Нажмите Refresh при стабильном интернете и дождитесь завершения.';
}
function openData(){$('deviceName').value=profile.deviceName||'';$('operatorName').value=profile.operatorName||'';if(!$('dataDialog').open)$('dataDialog').showModal();offlineStatus().catch(()=>{$('offlineStatus').textContent='Не удалось проверить локальную версию.';});}
['settingsOpen','settingsOpenTop'].forEach(id=>{const el=$(id);if(el)el.onclick=openData;});
const heroOnlineBtn=$('heroOnline');if(heroOnlineBtn)heroOnlineBtn.onclick=()=>probeNetwork(true).catch(()=>{});
const attentionLinkEl=$('attentionLink');if(attentionLinkEl)attentionLinkEl.addEventListener('click',e=>{if(attentionLinkEl.classList.contains('allClear'))e.preventDefault();});
$('dataClose').onclick=()=>{$('dataDialog').close();if(location.hash==='#data')history.replaceState(null,'',location.pathname+location.search);};
$('profileForm').onsubmit=e=>{e.preventDefault();profile={deviceName:$('deviceName').value.trim(),operatorName:$('operatorName').value.trim(),updatedAt:new Date().toISOString()};C.write('donskoe_profile_v1',profile);profileCaption();U.toast('Настройки сохранены на этом устройстве');};
$('backupCreate').onclick=async()=>{
 const button=$('backupCreate');button.disabled=true;$('backupStatus').textContent='Собираем журналы и локальные фотографии…';
 try{const snap=await C.snapshot();C.download(JSON.stringify(snap),'donskoe-backup-'+C.stamp()+'.json');C.write('donskoe_last_backup_v1',Date.now());backupCaption();$('backupStatus').textContent='Копия сформирована. Сохраните скачанный файл в «Файлы» или на другое устройство.';}
 catch(error){$('backupStatus').textContent='Копия не создана: '+error.message;}finally{button.disabled=false;}
};
$('backupSelect').onclick=()=>{$('backupFile').value='';$('backupFile').click();};
$('backupFile').onchange=async()=>{
 const file=$('backupFile').files[0];if(!file)return;restoreFile=null;$('restorePreview').hidden=true;
 try{
  if(file.size>300*1024*1024)throw new Error('Копия больше 300 МБ. Для её восстановления потребуется отдельная проверка на компьютере.');
  const parsed=C.validateBackup(JSON.parse(await file.text()));
  if(C.owner()&&parsed.ownerId&&C.owner()!==parsed.ownerId)throw new Error('Копия другой учётной записи. Войдите под исходной учётной записью.');
  restoreFile=parsed;
  const records=Object.values(parsed.databases).reduce((n,db)=>n+Object.values(db).reduce((m,arr)=>m+arr.length,0),0);
  $('restoreInfo').textContent='Дата: '+new Date(parsed.createdAt).toLocaleString('ru-RU')+'. Настроек и журналов: '+Object.keys(parsed.local).length+'. Записей в хранилищах: '+records+'. Размер: '+(file.size/1024/1024).toFixed(1)+' МБ.';
  $('restorePreview').hidden=false;$('backupStatus').textContent='Файл проверен. До нажатия кнопки ниже данные не меняются.';
 }catch(error){$('backupStatus').textContent='Импорт не начат: '+error.message;}
};
$('restoreCancel').onclick=()=>{restoreFile=null;$('restorePreview').hidden=true;};
$('restoreConfirm').onclick=async()=>{
 if(!restoreFile)return;
 if(C.activeWork()){$('backupStatus').textContent='Сначала завершите текущий цикл, обработку и калибровку. Во время активной работы восстановление недоступно.';return;}
 $('restoreConfirm').disabled=true;
 try{const result=await C.restoreMissing(restoreFile);$('backupStatus').textContent='Добавлено: '+result.added+'. Уже существовало: '+result.skipped+'. Откройте модули и проверьте журналы.';restoreFile=null;$('restorePreview').hidden=true;await refresh();}
 catch(error){$('backupStatus').textContent=error.message;}finally{$('restoreConfirm').disabled=false;}
};
$('updateCheck').onclick=async()=>{
 $('updateCheck').disabled=true;
 try{await runGlobalRefresh();await offlineStatus();}
 catch(error){$('offlineStatus').textContent='Проверка не выполнена: '+error.message;}
 finally{$('updateCheck').disabled=false;}
};
function info(title,html){$('infoTitle').textContent=title;$('infoBody').innerHTML=html;$('infoDialog').showModal();}
$('infoClose').onclick=()=>$('infoDialog').close();
$('changesOpen').onclick=()=>info('Донское '+DonskoeCore.VERSION,'<p>Стабильная версия общего обновления и офлайн-режима.</p><ul><li>Online проверяется реальным ping к серверу каждые 5 секунд и не может получить ложный ответ из офлайн-кэша.</li><li>Режим самолёта переводит Online и Refresh в серый после неудачного реального ping.</li><li>Refresh синхронизирует все три модуля и проверяет новую версию одним действием.</li><li>Регистрация service worker принудительно проверяется без браузерного кэша.</li><li>Главный экран, модули и логотипы входят в единый офлайн-кэш.</li></ul>');
window.addEventListener('beforeinstallprompt',e=>{e.preventDefault();installPrompt=e;});
$('installOpen').onclick=async()=>{
 if(installPrompt){await installPrompt.prompt();installPrompt=null;return;}
 info('Установить приложение','<p><b>iPhone / iPad:</b> откройте этот адрес в Safari → «Поделиться» → «На экран Домой» → «Добавить».</p><p><b>Android:</b> откройте адрес в Chrome → меню ⋮ → «Установить приложение» или «Добавить на главный экран».</p><p>После первого успешного Refresh главный экран и все три модуля сохраняются для запуска без сети. Для сохранения записей продолжайте пользоваться тем же адресом и браузером.</p>');
};
async function masterWorker(){
 if(!('serviceWorker' in navigator))return null;
 const rootScope=new URL('./',location.href).href;
 const regs=await navigator.serviceWorker.getRegistrations();
 await Promise.all(regs.filter(r=>r.scope!==rootScope&&['dryer/','chem/','connisseur/'].some(x=>r.scope.endsWith(x))).map(r=>r.unregister().catch(()=>false)));
 let reg=(await navigator.serviceWorker.getRegistrations()).find(r=>r.scope===rootScope)||null;
 // Register on every check. Besides creating the worker, this refreshes the script
 // and guarantees updateViaCache='none' even for installations made by older builds.
 try{reg=await navigator.serviceWorker.register('./sw.js',{scope:'./',updateViaCache:'none'});}catch(error){if(!reg)throw error;}
 return reg;
}
function waitForWorker(reg,timeout=9000){return new Promise(resolve=>{
 if(reg.waiting)return resolve(reg.waiting);
 const started=Date.now();let timer=null;
 const done=()=>{if(timer)clearInterval(timer);resolve(reg.waiting||null);};
 timer=setInterval(()=>{if(reg.waiting||Date.now()-started>=timeout)done();},180);
 if(reg.installing)reg.installing.addEventListener('statechange',()=>{if(reg.waiting)done();});
 reg.addEventListener('updatefound',()=>{reg.installing?.addEventListener('statechange',()=>{if(reg.waiting)done();});},{once:true});
 });}
async function activateWaiting(reg){
 if(!reg?.waiting)return false;
 if(C.activeWork()){U.toast('Новая версия готова. Сначала завершите текущую работу, затем нажмите Refresh.',5500);return false;}
 return new Promise(resolve=>{
  let finished=false;const finish=v=>{if(finished)return;finished=true;resolve(v);};
  navigator.serviceWorker.addEventListener('controllerchange',()=>{finish(true);location.reload();},{once:true});
  reg.waiting.postMessage({type:'ACTIVATE_UPDATE'});
  setTimeout(()=>finish(false),6000);
 });
}
function backgroundSync(target,timeout=22000){return new Promise(resolve=>{
 const token=target.name+'-'+Date.now()+'-'+Math.random().toString(16).slice(2),frame=document.createElement('iframe');
 frame.className='syncFrame';frame.setAttribute('aria-hidden','true');
 let done=false,timer;
 const finish=result=>{if(done)return;done=true;clearTimeout(timer);window.removeEventListener('message',onMessage);frame.remove();resolve(result);};
 const onMessage=e=>{if(e.origin!==location.origin||e.source!==frame.contentWindow)return;const d=e.data||{};if(d.type==='DONSKOE_BACKGROUND_SYNC_DONE'&&d.module===target.name&&d.token===token)finish({module:target.name,ok:d.ok!==false});};
 window.addEventListener('message',onMessage);timer=setTimeout(()=>finish({module:target.name,ok:false,timeout:true}),timeout);
 frame.src=target.url+'?backgroundSync=1&syncToken='+encodeURIComponent(token)+'&skipSplash=1';document.body.append(frame);
 });}
async function runAllModuleSync(){const out=[];for(const target of moduleSyncTargets)out.push(await backgroundSync(target));return out;}
async function runGlobalRefresh(){
 if(refreshBusy)return;refreshBusy=true;const btn=$('globalRefresh');btn?.classList.add('isBusy');
 try{
  const connected=await probeNetwork(true);if(!connected){U.toast('Интернета нет. Локальные данные и модули доступны офлайн.',4200);return;}
  const reg=await masterWorker();
  if(reg){try{await reg.update();}catch(_){}await waitForWorker(reg,9000);}
  const syncResults=await runAllModuleSync();
  await refresh();await probeNetwork(false);
  if(reg?.waiting){const activated=await activateWaiting(reg);if(activated)return;}
  const pending=Number($('pendingCount')?.textContent||0),failed=syncResults.filter(x=>x.timeout).length;
  if(remoteRelease?.version&&newerVersion(remoteRelease.version,C.VERSION))U.toast('Новая версия v'+remoteRelease.version+' найдена. Если обновление ещё загружается, нажмите Refresh ещё раз.',5200);
  else if(pending>0||failed)U.toast('Refresh завершён. Часть изменений пока осталась в очереди и будет повторена при стабильной сети.',5200);
  else U.toast('Синхронизация завершена. Обновлений нет.',3200);
 }finally{refreshBusy=false;btn?.classList.remove('isBusy');renderNetworkUi();}
}
const globalRefresh=$('globalRefresh');if(globalRefresh)globalRefresh.onclick=()=>runGlobalRefresh().catch(e=>U.toast('Refresh: '+e.message,5200));
window.addEventListener('online',()=>{scheduleNetworkProbe(0);refresh().catch(console.error);});
window.addEventListener('offline',()=>{
 // Safari/iOS standalone can report this incorrectly. Verify against the server
 // before changing Online/Refresh to gray.
 scheduleNetworkProbe(0);refresh().catch(console.error);
});
window.addEventListener('storage',()=>refresh().catch(console.error));
window.addEventListener('pageshow',()=>{refresh().catch(console.error);scheduleNetworkProbe();});
document.addEventListener('visibilitychange',()=>{if(document.visibilityState==='visible')scheduleNetworkProbe();});
if('serviceWorker' in navigator)window.addEventListener('load',()=>masterWorker().then(()=>probeNetwork(true)).catch(()=>probeNetwork(true).catch(()=>{})));
setInterval(()=>{if(document.visibilityState==='visible')probeNetwork(false).catch(()=>{});},5000);
if(location.hash==='#data')openData();
renderNetworkUi();
refresh().catch(error=>U.toast('Не удалось прочитать сводку: '+error.message,6000));
scheduleNetworkProbe();
})();
