(function(){
  const $=id=>document.getElementById(id);
  function setNetwork(){
    const online=navigator.onLine;
    const pill=$('networkPill');
    pill.classList.toggle('online',online);pill.classList.toggle('offline',!online);
    $('networkText').textContent=online?'Online':'Offline';
  }
  function getDeviceLabel(){
    const ua=navigator.userAgent||'';
    if(/iPhone/i.test(ua))return 'iPhone';
    if(/iPad/i.test(ua))return 'iPad';
    if(/Android/i.test(ua))return 'Android';
    if(/Macintosh/i.test(ua))return 'Mac';
    if(/Windows/i.test(ua))return 'Windows';
    return 'Устройство';
  }
  function getDeviceId(){
    let id=localStorage.getItem('donskoe_device_id');
    if(!id){
      const raw=(crypto&&crypto.randomUUID)?crypto.randomUUID():(''+Date.now()+Math.random()).replace(/\D/g,'');
      id='D-'+raw.replace(/-/g,'').slice(0,8).toUpperCase();
      localStorage.setItem('donskoe_device_id',id);
    }
    return id;
  }
  function safeJson(key,fallback){try{const v=JSON.parse(localStorage.getItem(key)||'null');return v===null?fallback:v;}catch(e){return fallback;}}
  function connState(){return safeJson('donskoe_connisseur_state_v1',{});}
  function dryerDraft(){return safeJson('donskoe_dryer_draft_v2',null);}
  function dryerPlan(){return safeJson('donskoe_dryer_active_plan_v1',null);}
  function pendingOverview(){const conn=safeJson('donskoe_connisseur_cloud_pending_v1',[]),dry=safeJson('donskoe_dryer_cloud_pending_v1',[]),del=safeJson('donskoe_dryer_photo_deletes_v1',[]);return (Array.isArray(conn)?conn.length:0)+(Array.isArray(dry)?dry.length:0)+(Array.isArray(del)?del.length:0);}
  function activeOverview(){const cs=connState(),run=(cs.runs||[]).find(r=>r&&r.status==='running'&&!r.deletedAt);const draft=dryerDraft(),plan=dryerPlan();if(run)return{kind:'conn',title:'ConNiSseur · работа не завершена',text:run.pausedAt?'Линия на паузе · открыть рабочий экран':'Линия отмечена как работающая · открыть рабочий экран'};if(plan)return{kind:'dryer',title:'Зерносушилка · активный расчёт',text:'Есть текущий план цикла · продолжить контроль'};if(draft&&draft._savedAt&&Date.now()-Number(draft._savedAt)<14*86400000)return{kind:'dryer',title:'Зерносушилка · черновик',text:'Есть несохранённые данные цикла · продолжить ввод'};return null;}
  function refreshOps(){setNetwork();const active=activeOverview(),pending=pendingOverview(),online=navigator.onLine!==false;const overall=$('opsOverall');if(overall){overall.className='opsBadge '+(!online?'warn':pending?'warn':'ok');overall.textContent=!online?'OFFLINE':pending?('ОЧЕРЕДЬ '+pending):'ГОТОВО';}
    if($('resumeWorkTitle')){$('resumeWorkTitle').textContent=active?active.title:'Незавершённых работ нет';$('resumeWorkText').textContent=active?active.text:'Можно начинать новый производственный цикл';}
    if($('syncOverviewText'))$('syncOverviewText').textContent=!online?(pending?pending+' изменений ждут сети':'Локальный режим · очередь пуста'):(pending?pending+' изменений ожидают отправки':'Локальная очередь пуста');
    const cs=connState(),r=(cs.runs||[]).some(x=>x&&x.status==='running'&&!x.deletedAt);$('connBadge')?.classList.toggle('active',r);if($('connBadge'))$('connBadge').textContent=r?'РАБОТА':'ГОТОВО';
    const dp=!!dryerPlan();$('dryerBadge')?.classList.toggle('active',dp);if($('dryerBadge'))$('dryerBadge').textContent=dp?'ЦИКЛ':'ГОТОВО';
    const cb=$('chemBadge');if(cb){cb.classList.toggle('pending',pending>0);cb.textContent=pending?'ОЧЕРЕДЬ':'ГОТОВО';}
  }
  function openId(){const active=activeOverview(),pending=pendingOverview();$('deviceName').textContent=getDeviceLabel();$('deviceId').textContent=getDeviceId();$('deviceNetwork').textContent=navigator.onLine!==false?'Online':'Offline';$('deviceActive').textContent=active?active.title:'нет';$('devicePending').textContent=pending?String(pending):'0';$('idShade').classList.remove('hidden');}

  function closeId(){$('idShade').classList.add('hidden');}
  $('idBtn').addEventListener('click',openId);$('resumeWorkBtn')?.addEventListener('click',()=>{const a=activeOverview();if(a?.kind==='conn')location.href='connisseur/index.html#work';else if(a?.kind==='dryer')location.href='dryer/index.html';else location.href='connisseur/index.html';});$('syncOverviewBtn')?.addEventListener('click',openId);$('closeId').addEventListener('click',closeId);$('idShade').addEventListener('click',e=>{if(e.target===$('idShade'))closeId();});$('brandHome').addEventListener('click',()=>window.scrollTo({top:0,behavior:'smooth'}));
  window.addEventListener('online',refreshOps);window.addEventListener('offline',refreshOps);refreshOps();setInterval(refreshOps,5000);document.addEventListener('visibilitychange',()=>{if(document.visibilityState==='visible')refreshOps();});

  const params=new URLSearchParams(location.search);const skip=params.get('skipSplash')==='1'||sessionStorage.getItem('donskoe_booted')==='1';
  const splash=$('splash');
  if(skip){splash.classList.add('hide');}
  else{sessionStorage.setItem('donskoe_booted','1');setTimeout(()=>splash.classList.add('hide'),1950);}
  if(params.get('skipSplash')==='1'&&history.replaceState){history.replaceState({},'',location.pathname+location.hash);}

  if('serviceWorker' in navigator){window.addEventListener('load',()=>navigator.serviceWorker.register('./sw.js',{scope:'./',updateViaCache:'none'}).then(r=>r.update().catch(()=>{})).catch(()=>{}));}
})();
